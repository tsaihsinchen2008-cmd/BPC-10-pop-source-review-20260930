"""Observation-only lead guidance with cascaded attitude/rate PID control."""

from __future__ import annotations

import math

import numpy as np

from BalloonPoppingGymEnv.agents.base_agent import BaseAgent


def _as_vector(value, size, name):
    vector = np.asarray(value, dtype=float)
    if vector.shape == ():
        vector = np.full(size, float(vector))
    if vector.shape != (size,):
        raise ValueError(f"{name} must be a scalar or a {size}-element vector")
    return vector


def _quat_multiply(left, right):
    w1, x1, y1, z1 = left
    w2, x2, y2, z2 = right
    return np.array(
        [
            w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
            w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
            w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
            w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2,
        ]
    )


def _initial_attitude(inclination_deg, heading_deg):
    """Match the environment's documented 3-1-3 launch attitude convention."""
    theta = math.radians(inclination_deg - 90.0)
    psi = math.radians(-heading_deg)
    return np.array(
        [
            math.cos(theta / 2.0) * math.cos(psi / 2.0),
            math.sin(theta / 2.0) * math.cos(psi / 2.0),
            math.sin(theta / 2.0) * math.sin(psi / 2.0),
            math.cos(theta / 2.0) * math.sin(psi / 2.0),
        ]
    )


def _rotate_inertial_to_body(quaternion, vector):
    """Rotate a launch-frame vector into body axes for a body-to-launch q."""
    q_vector = quaternion[1:]
    return (
        vector
        - 2.0 * quaternion[0] * np.cross(q_vector, vector)
        + 2.0 * np.cross(q_vector, np.cross(q_vector, vector))
    )


def _rotate_body_to_inertial(quaternion, vector):
    """Rotate a body-axis vector into launch-frame axes."""
    q_vector = quaternion[1:]
    return (
        vector
        + 2.0 * quaternion[0] * np.cross(q_vector, vector)
        + 2.0 * np.cross(q_vector, np.cross(q_vector, vector))
    )


class GuidedPidAgent(BaseAgent):
    """Lead-intercept guidance and cascaded attitude/rate PID baseline.

    Every flight-state input comes from ``observation``.  The constructor uses
    only the competition-provided ``given_parameters`` plus explicit tuning
    kwargs.  ``telemetry`` is a list of dictionaries suitable for plotting.
    """

    def __init__(self, given_parameters, **kwargs):
        super().__init__(given_parameters)

        self.launch_time = float(kwargs.get("launch_time", 1.0))
        launch_release_fraction = kwargs.get("launch_release_fraction", 0.75)
        self.launch_release_fraction = (
            None
            if launch_release_fraction is None
            else float(launch_release_fraction)
        )
        self.max_launch_time = float(kwargs.get("max_launch_time", 60.0))
        self.min_launch_inclination = float(
            kwargs.get("min_launch_inclination", 70.0)
        )
        self.max_launch_inclination = float(
            kwargs.get("max_launch_inclination", 85.0)
        )
        if self.launch_release_fraction is not None and not (
            0.0 <= self.launch_release_fraction <= 1.0
        ):
            raise ValueError("launch_release_fraction must be between 0 and 1")
        self.inclination = float(kwargs.get("inclination", 90.0))
        self.heading = float(kwargs.get("heading", 0.0))
        self.launch_attitude = np.array([self.inclination, self.heading])

        self.target_switch_period = float(kwargs.get("target_switch_period", 0.25))
        self.max_planned_turn = math.radians(
            float(kwargs.get("max_planned_turn", 8.0))
        )
        self.max_lead_time = float(kwargs.get("max_lead_time", 4.0))
        self.min_intercept_speed = float(kwargs.get("min_intercept_speed", 20.0))
        self.lead_speed_margin = float(kwargs.get("lead_speed_margin", 5.0))
        self.distance_weight = float(kwargs.get("distance_weight", 1.0))
        self.turn_weight = float(kwargs.get("turn_weight", 35.0))
        self.closing_weight = float(kwargs.get("closing_weight", 2.0))
        self.altitude_weight = float(kwargs.get("altitude_weight", 1.5))
        self.density_weight = float(kwargs.get("density_weight", 12.0))
        self.density_radius = float(kwargs.get("density_radius", 80.0))
        self.corridor_capture_bonus = float(
            kwargs.get("corridor_capture_bonus", 0.0)
        )
        self.corridor_capture_radius = float(
            kwargs.get(
                "corridor_capture_radius",
                given_parameters["balloon"]["radius"],
            )
        )
        self.turn_acceleration_weight = float(
            kwargs.get("turn_acceleration_weight", 20.0)
        )
        self.infeasible_turn_acceleration_weight = float(
            kwargs.get("infeasible_turn_acceleration_weight", 200.0)
        )
        self.tvc_authority_margin = float(kwargs.get("tvc_authority_margin", 0.8))
        self.path_authority_margin = float(
            kwargs.get("path_authority_margin", 0.8)
        )
        self.guidance_response_time = float(
            kwargs.get("guidance_response_time", 0.5)
        )
        self.turn_lookahead_time = float(kwargs.get("turn_lookahead_time", 1.5))
        self.turn_lookahead_min = float(kwargs.get("turn_lookahead_min", 20.0))
        self.turn_lookahead_max = float(kwargs.get("turn_lookahead_max", 100.0))
        self.turn_speed_floor = float(kwargs.get("turn_speed_floor", 10.0))
        self.route_speed_estimation_acceleration = float(
            kwargs.get("route_speed_estimation_acceleration", 3.0)
        )
        self.fallback_lateral_acceleration = float(
            kwargs.get("fallback_lateral_acceleration", 3.0)
        )
        self.launch_turn_distance = float(kwargs.get("launch_turn_distance", 20.0))
        self.launch_clearance_time = float(kwargs.get("launch_clearance_time", 0.0))
        self.launch_clearance_altitude = float(
            kwargs.get("launch_clearance_altitude", 0.0)
        )
        self.launch_clearance_max_time = float(
            kwargs.get("launch_clearance_max_time", 0.0)
        )
        self.target_commit_time = float(kwargs.get("target_commit_time", 12.0))
        self.target_approach_lock_time = float(
            kwargs.get("target_approach_lock_time", 0.0)
        )
        self.route_dead_end_penalty = float(
            kwargs.get("route_dead_end_penalty", 400.0)
        )
        self.route_distance_weight = float(
            kwargs.get("route_distance_weight", 0.5)
        )
        self.route_successor_bonus = float(
            kwargs.get("route_successor_bonus", 40.0)
        )
        if not 0.0 < self.tvc_authority_margin <= 1.0:
            raise ValueError("tvc_authority_margin must be in (0, 1]")
        if not 0.0 < self.path_authority_margin <= 1.0:
            raise ValueError("path_authority_margin must be in (0, 1]")
        if self.guidance_response_time <= 0.0:
            raise ValueError("guidance_response_time must be positive")
        if self.turn_lookahead_time <= 0.0:
            raise ValueError("turn_lookahead_time must be positive")
        if not 0.0 < self.turn_lookahead_min <= self.turn_lookahead_max:
            raise ValueError("turn lookahead bounds must be positive and ordered")
        if self.turn_speed_floor <= 0.0:
            raise ValueError("turn_speed_floor must be positive")
        if self.route_speed_estimation_acceleration < 0.0:
            raise ValueError("route_speed_estimation_acceleration must be non-negative")
        if self.fallback_lateral_acceleration <= 0.0:
            raise ValueError("fallback_lateral_acceleration must be positive")
        if self.corridor_capture_bonus < 0.0:
            raise ValueError("corridor_capture_bonus must be non-negative")
        if self.corridor_capture_radius <= 0.0:
            raise ValueError("corridor_capture_radius must be positive")
        if self.launch_turn_distance <= 0.0:
            raise ValueError("launch_turn_distance must be positive")
        if self.launch_clearance_time < 0.0 or self.launch_clearance_altitude < 0.0:
            raise ValueError("launch clearance time/altitude must be non-negative")
        if self.launch_clearance_max_time < self.launch_clearance_time:
            raise ValueError("launch_clearance_max_time must not be shorter")
        if self.target_approach_lock_time < 0.0:
            raise ValueError("target_approach_lock_time must be non-negative")
        if not 0.0 < self.max_planned_turn <= math.pi:
            raise ValueError("max_planned_turn must be in (0, 180] degrees")

        self.attitude_kp = _as_vector(
            kwargs.get("attitude_kp", [2.0, 2.0, 1.0]), 3, "attitude_kp"
        )
        self.max_desired_rate = _as_vector(
            kwargs.get("max_desired_rate", [0.8, 0.8, 0.5]),
            3,
            "max_desired_rate",
        )
        self.rate_kp = _as_vector(
            kwargs.get("rate_kp", [12.0, 12.0, 2.0]), 3, "rate_kp"
        )
        self.rate_ki = _as_vector(
            kwargs.get("rate_ki", [0.0, 0.0, 0.0]), 3, "rate_ki"
        )
        self.rate_kd = _as_vector(
            kwargs.get("rate_kd", [0.02, 0.02, 0.0]), 3, "rate_kd"
        )
        self.integral_limit = _as_vector(
            kwargs.get("integral_limit", [1.0, 1.0, 1.0]),
            3,
            "integral_limit",
        )
        self.acceleration_filter_tau = float(
            kwargs.get("acceleration_filter_tau", 0.15)
        )
        self.throttle_command = float(kwargs.get("throttle", 1.0))
        fixed_waypoint = kwargs.get("fixed_waypoint")
        fixed_waypoints = kwargs.get("fixed_waypoints")
        if fixed_waypoint is not None and fixed_waypoints is not None:
            raise ValueError("use fixed_waypoint or fixed_waypoints, not both")
        if fixed_waypoints is not None:
            waypoint_array = np.asarray(fixed_waypoints, dtype=float)
            if waypoint_array.ndim != 2 or waypoint_array.shape[1] != 3:
                raise ValueError("fixed_waypoints must have shape (N, 3)")
            if waypoint_array.shape[0] == 0:
                raise ValueError("fixed_waypoints must contain at least one point")
            self.fixed_waypoints = waypoint_array.copy()
        elif fixed_waypoint is not None:
            self.fixed_waypoints = _as_vector(
                fixed_waypoint, 3, "fixed_waypoint"
            ).reshape(1, 3)
        else:
            self.fixed_waypoints = None
        self.waypoint_radius = float(
            kwargs.get("waypoint_radius", given_parameters["balloon"]["radius"])
        )
        self.line_position_gain = float(kwargs.get("line_position_gain", 0.08))
        self.line_velocity_gain = float(kwargs.get("line_velocity_gain", 0.8))
        self.line_forward_acceleration = float(
            kwargs.get("line_forward_acceleration", 3.0)
        )
        self.navigation_constant = float(kwargs.get("navigation_constant", 3.0))
        self.target_navigation_constant = float(
            kwargs.get("target_navigation_constant", 1.0)
        )
        self.zero_effort_miss_gain = float(
            kwargs.get("zero_effort_miss_gain", 0.0)
        )
        self.minimum_zem_time = float(kwargs.get("minimum_zem_time", 0.5))
        self.max_lateral_acceleration = float(
            kwargs.get("max_lateral_acceleration", 8.0)
        )
        self.target_forward_acceleration = float(
            kwargs.get("target_forward_acceleration", 6.0)
        )
        self.target_gravity_compensation = float(
            kwargs.get("target_gravity_compensation", 0.0)
        )
        if self.waypoint_radius <= 0.0:
            raise ValueError("waypoint_radius must be positive")
        if self.line_position_gain < 0.0 or self.line_velocity_gain < 0.0:
            raise ValueError("line guidance gains must be non-negative")
        if self.line_forward_acceleration <= 0.0:
            raise ValueError("line_forward_acceleration must be positive")
        if (
            self.navigation_constant < 0.0
            or self.target_navigation_constant < 0.0
            or self.zero_effort_miss_gain < 0.0
            or self.max_lateral_acceleration <= 0.0
        ):
            raise ValueError("terminal guidance gains must be non-negative")
        if self.minimum_zem_time <= 0.0:
            raise ValueError("minimum_zem_time must be positive")
        if self.target_forward_acceleration <= 0.0:
            raise ValueError("target_forward_acceleration must be positive")
        if self.target_gravity_compensation < 0.0:
            raise ValueError("target_gravity_compensation must be non-negative")
        self.waypoint_start = np.array(
            [0.0, 0.0, float(given_parameters["environment"]["elevation"])]
        )
        self.current_waypoint_index = 0 if self.fixed_waypoints is not None else -1
        self.fixed_waypoint = (
            self.fixed_waypoints[0].copy()
            if self.fixed_waypoints is not None
            else None
        )
        self.waypoint_line_direction = None
        if self.fixed_waypoints is not None:
            previous = self.waypoint_start
            for index, waypoint in enumerate(self.fixed_waypoints):
                if np.linalg.norm(waypoint - previous) <= 1e-9:
                    raise ValueError(
                        f"waypoint {index} must differ from its segment start"
                    )
                previous = waypoint
            self._activate_waypoint(0)

        control = given_parameters["rocket"]["control"]
        self.max_gimbal = float(control["max_gimbal_angle"])
        self.gimbal_rate_limit = max(float(control["gimbal_rate_limit"]), 0.0)
        self.max_roll = float(control["max_roll_torque"])
        self.roll_rate_limit = max(float(control["torque_rate_limit"]), 0.0)
        self.throttle_min, self.throttle_max = map(float, control["throttle_range"])

        rocket = given_parameters["rocket"]
        tank = rocket["tank"]
        motor = rocket["motor"]
        dry_mass = float(rocket["rocket_body"]["mass"]) + float(motor["dry_mass"])
        liquid_mass = float(tank["initial_liquid_mass"])
        self.schedule_dry_mass = dry_mass
        self.schedule_liquid_mass = liquid_mass
        self.schedule_wet_mass = max(dry_mass + liquid_mass, 1e-9)
        self.liquid_flow_rate = max(float(tank["liquid_mass_flow_rate_out"]), 0.0)
        self.burn_time = max(float(motor["burn_time"]), 0.0)
        thrust_source = kwargs.get("nominal_thrust", motor.get("thrust_source"))
        try:
            self.nominal_thrust = max(float(thrust_source), 0.0)
        except (TypeError, ValueError):
            self.nominal_thrust = 0.0

        self.attitude = _initial_attitude(self.inclination, self.heading)
        self.rate_integral = np.zeros(3)
        self.previous_gyro = np.zeros(3)
        self.previous_control_command = np.zeros(3)
        self.previous_velocity = None
        self.previous_guidance_position = None
        self.filtered_acceleration = np.zeros(3)
        self.previous_time = None
        self.selected_target = None
        self.selected_target_time = -np.inf
        self.selected_target_turn_angle = np.nan
        self.launch_target_raw_inclination = np.nan
        self.launch_target_turn_angle = np.nan
        self.launch_required_lateral_acceleration = np.nan
        self.launch_available_lateral_acceleration = np.nan
        self.launch_successor_count = 0
        self.launch_corridor_count = 0
        self.corridor_target = None
        self.selected_target_successor_count = 0
        self.current_available_lateral_acceleration = min(
            self.max_lateral_acceleration,
            self.fallback_lateral_acceleration,
        )
        self.current_launch_turn_acceleration = min(
            self.max_lateral_acceleration,
            self.fallback_lateral_acceleration,
        )
        self.current_thrust_acceleration = self.fallback_lateral_acceleration
        self.selected_target_required_lateral_acceleration = np.nan
        self.selected_target_relative_position = np.full(3, np.nan)
        self.selected_target_relative_velocity = np.full(3, np.nan)
        self.raw_guidance_turn_angle = np.nan
        self.planned_guidance_turn_angle = np.nan
        self.planned_curvature = 0.0
        self.planned_lateral_acceleration = 0.0
        self.virtual_waypoint = np.full(3, np.nan)
        self.path_virtual_waypoint = np.full(3, np.nan)
        self.launch_direction = _rotate_body_to_inertial(
            self.attitude, np.array([0.0, 0.0, 1.0])
        )
        self.target_history = []
        self.target_approach_locked = False
        self.selected_target_passed = False
        self.last_target_selection_time = -np.inf
        self.launch_decided = False
        self.actual_launch_time = np.nan
        self.waypoint_reached = False
        waypoint_count = 0 if self.fixed_waypoints is None else len(self.fixed_waypoints)
        self.waypoints_passed = np.zeros(waypoint_count, dtype=bool)
        self.waypoint_pass_times = np.full(waypoint_count, np.nan)
        self.waypoint_pass_speeds = np.full(waypoint_count, np.nan)
        self.closest_waypoint_distances = np.full(waypoint_count, np.inf)
        self.closest_waypoint_times = np.full(waypoint_count, np.nan)
        self.closest_waypoint_speeds = np.full(waypoint_count, np.nan)
        self.telemetry = []

    def _prepare_balloon_launch(self, observation, simulation_time):
        status = np.asarray(observation["balloon_status"]).reshape(-1)
        available = np.flatnonzero(status == 1)
        if available.size == 0:
            return

        states = np.asarray(observation["balloon_states"], dtype=float)
        positions = states[available, :3]
        relative = positions - self.waypoint_start
        distances = np.linalg.norm(relative, axis=1)
        vertical_cost = np.abs(relative[:, 2])
        pairwise = positions[:, None, :] - positions[None, :, :]
        pairwise_distance = np.linalg.norm(pairwise, axis=2)
        density = np.sum(
            np.exp(-np.square(pairwise_distance / max(self.density_radius, 1e-9))),
            axis=1,
        )
        base_scores = (
            self.distance_weight * distances
            + self.altitude_weight * vertical_cost
            - self.density_weight * density
        )
        corridor_counts = []
        all_relative = positions - self.waypoint_start
        for row, distance in enumerate(distances):
            direction = all_relative[row] / max(float(distance), 1e-9)
            along = all_relative @ direction
            perpendicular = all_relative - along[:, None] * direction
            perpendicular_distance = np.linalg.norm(perpendicular, axis=1)
            on_segment = (along >= 0.0) & (along <= distance)
            corridor_counts.append(
                int(
                    np.count_nonzero(
                        on_segment
                        & (perpendicular_distance <= self.corridor_capture_radius)
                    )
                )
            )
        corridor_counts = np.asarray(corridor_counts, dtype=int)
        base_scores -= self.corridor_capture_bonus * np.maximum(
            corridor_counts - 1, 0
        )

        launch_directions = []
        raw_inclinations = []
        launch_turns = []
        launch_required_accelerations = []
        commanded_directions = []
        for index in available:
            target_position = states[index, :3]
            target_velocity = states[index, 3:6]
            launch_direction = (
                self._moving_target_guidance_point(
                    target_position,
                    target_velocity,
                    self.waypoint_start,
                    np.zeros(3),
                )
                - self.waypoint_start
            )
            horizontal_distance = float(np.linalg.norm(launch_direction[:2]))
            raw_inclination = math.atan2(
                max(float(launch_direction[2]), 0.0), horizontal_distance
            )
            commanded_inclination = np.clip(
                raw_inclination,
                math.radians(self.min_launch_inclination),
                math.radians(self.max_launch_inclination),
            )
            heading = math.atan2(
                float(launch_direction[0]), float(launch_direction[1])
            )
            commanded_direction = np.array(
                [
                    math.cos(commanded_inclination) * math.sin(heading),
                    math.cos(commanded_inclination) * math.cos(heading),
                    math.sin(commanded_inclination),
                ]
            )
            turn_metrics = self._turn_acceleration_metrics(
                commanded_direction,
                launch_direction,
                min(
                    distances[len(launch_directions)],
                    self.launch_turn_distance,
                ),
                self.turn_speed_floor,
            )
            launch_directions.append(launch_direction)
            commanded_directions.append(commanded_direction)
            raw_inclinations.append(raw_inclination)
            launch_turns.append(turn_metrics[0])
            launch_required_accelerations.append(turn_metrics[1])

        raw_inclinations = np.asarray(raw_inclinations)
        launch_turns = np.asarray(launch_turns)
        launch_required_accelerations = np.asarray(launch_required_accelerations)
        route_metrics = []
        for row, index in enumerate(available):
            arrival_speed, prediction_time = self._arrival_estimate(
                0.0, distances[row]
            )
            route_metrics.append(
                self._route_continuation_metrics(
                    int(index),
                    states,
                    available,
                    launch_directions[row],
                    arrival_speed,
                    prediction_time,
                )
            )
        route_costs = np.asarray([metric[0] for metric in route_metrics])
        feasible = launch_turns <= self.max_planned_turn
        candidate_rows = np.flatnonzero(feasible) if np.any(feasible) else np.arange(len(available))
        scores = (
            base_scores
            + route_costs
            + self.turn_weight * launch_turns
        )
        selected_row = int(candidate_rows[np.argmin(scores[candidate_rows])])
        self.selected_target = int(available[selected_row])
        self.selected_target_time = simulation_time
        self.last_target_selection_time = simulation_time
        self.target_history.append(self.selected_target)

        launch_direction = launch_directions[selected_row]
        horizontal_distance = float(np.linalg.norm(launch_direction[:2]))
        inclination = math.degrees(raw_inclinations[selected_row])
        heading = math.degrees(
            math.atan2(float(launch_direction[0]), float(launch_direction[1]))
        ) % 360.0
        self.inclination = float(
            np.clip(
                inclination,
                self.min_launch_inclination,
                self.max_launch_inclination,
            )
        )
        self.launch_target_raw_inclination = inclination
        self.launch_target_turn_angle = float(launch_turns[selected_row])
        self.launch_required_lateral_acceleration = float(
            launch_required_accelerations[selected_row]
        )
        self.launch_available_lateral_acceleration = float(
            self.current_launch_turn_acceleration
        )
        self.launch_successor_count = int(route_metrics[selected_row][1])
        self.launch_corridor_count = int(corridor_counts[selected_row])
        self.corridor_target = (
            self.selected_target
            if self.corridor_capture_bonus > 0.0 and self.launch_corridor_count > 1
            else None
        )
        self.selected_target_successor_count = self.launch_successor_count
        self.heading = heading
        self.launch_attitude = np.array([self.inclination, self.heading])
        self.attitude = _initial_attitude(self.inclination, self.heading)
        self.launch_direction = commanded_directions[selected_row].copy()
        self.previous_gyro = np.zeros(3)

    def _activate_waypoint(self, index):
        self.current_waypoint_index = index
        self.fixed_waypoint = self.fixed_waypoints[index].copy()
        segment_start = (
            self.waypoint_start
            if index == 0
            else self.fixed_waypoints[index - 1]
        )
        waypoint_delta = self.fixed_waypoint - segment_start
        self.waypoint_line_direction = waypoint_delta / np.linalg.norm(waypoint_delta)
        self.active_segment_start = np.asarray(segment_start, dtype=float).copy()

    def _scheduled_mass(self, simulation_time):
        schedule_start = (
            self.actual_launch_time
            if np.isfinite(self.actual_launch_time)
            else simulation_time
        )
        flight_time = np.clip(
            simulation_time - schedule_start, 0.0, self.burn_time
        )
        # Competition model consumes mass with time, independent of throttle.
        liquid = max(
            self.schedule_liquid_mass - self.liquid_flow_rate * flight_time, 0.0
        )
        return self.schedule_dry_mass + liquid

    def _mass_gain_scale(self, simulation_time):
        scheduled_mass = self._scheduled_mass(simulation_time)
        return float(np.clip(scheduled_mass / self.schedule_wet_mass, 0.5, 1.0))

    def _available_lateral_acceleration(self, simulation_time):
        thrust_acceleration = self._thrust_acceleration(simulation_time)
        if thrust_acceleration > 0.0:
            # Once attitude follows the path tangent, the whole thrust vector can
            # provide normal acceleration.  max_lateral_acceleration is the
            # conservative flight-path envelope; thrust/mass is its physical cap.
            path_authority = thrust_acceleration * self.path_authority_margin
        else:
            path_authority = self.fallback_lateral_acceleration
        return float(min(self.max_lateral_acceleration, path_authority))

    def _thrust_acceleration(self, simulation_time):
        if self.nominal_thrust <= 0.0:
            return 0.0
        mass = max(self._scheduled_mass(simulation_time), 1e-9)
        throttle = float(
            np.clip(self.throttle_command, self.throttle_min, self.throttle_max)
        )
        return self.nominal_thrust * throttle / mass

    def _available_launch_turn_acceleration(self, simulation_time):
        if self.nominal_thrust > 0.0:
            mass = max(self._scheduled_mass(simulation_time), 1e-9)
            # Before the body has rotated, only the gimballed component produces
            # immediate lateral acceleration relative to the launch direction.
            launch_authority = (
                self.nominal_thrust
                / mass
                * math.sin(math.radians(self.max_gimbal))
                * self.tvc_authority_margin
            )
        else:
            launch_authority = self.fallback_lateral_acceleration
        return float(min(self.max_lateral_acceleration, launch_authority))

    def _motion_direction(self, velocity):
        speed = float(np.linalg.norm(velocity))
        if speed >= self.turn_speed_floor:
            return velocity / speed, speed
        nose = _rotate_body_to_inertial(
            self.attitude, np.array([0.0, 0.0, 1.0])
        )
        nose /= max(float(np.linalg.norm(nose)), 1e-9)
        return nose, max(speed, self.turn_speed_floor)

    @staticmethod
    def _turn_acceleration_metrics(incoming, outgoing, distance, speed):
        incoming = np.asarray(incoming, dtype=float)
        outgoing = np.asarray(outgoing, dtype=float)
        incoming /= max(float(np.linalg.norm(incoming)), 1e-9)
        outgoing /= max(float(np.linalg.norm(outgoing)), 1e-9)
        angle = math.acos(float(np.clip(np.dot(incoming, outgoing), -1.0, 1.0)))
        distance = max(float(distance), 1e-9)
        speed = max(float(speed), 0.0)
        circle_curvature = 2.0 * math.sin(angle) / distance
        horizon_curvature = angle / distance
        required_curvature = max(circle_curvature, horizon_curvature)
        required_acceleration = speed**2 * required_curvature
        return angle, required_acceleration, required_curvature

    @staticmethod
    def _rotate_direction_toward(incoming, outgoing, maximum_angle):
        incoming = np.asarray(incoming, dtype=float)
        outgoing = np.asarray(outgoing, dtype=float)
        incoming /= max(float(np.linalg.norm(incoming)), 1e-9)
        outgoing /= max(float(np.linalg.norm(outgoing)), 1e-9)
        angle = math.acos(float(np.clip(np.dot(incoming, outgoing), -1.0, 1.0)))
        if angle <= maximum_angle or angle <= 1e-12:
            return outgoing
        axis = np.cross(incoming, outgoing)
        axis_norm = float(np.linalg.norm(axis))
        if axis_norm <= 1e-12:
            reference = np.array([1.0, 0.0, 0.0])
            if abs(float(np.dot(incoming, reference))) > 0.9:
                reference = np.array([0.0, 1.0, 0.0])
            axis = np.cross(incoming, reference)
            axis_norm = float(np.linalg.norm(axis))
        axis /= axis_norm
        turn = max(float(maximum_angle), 0.0)
        return (
            incoming * math.cos(turn)
            + np.cross(axis, incoming) * math.sin(turn)
            + axis * float(np.dot(axis, incoming)) * (1.0 - math.cos(turn))
        )

    def _curvature_limited_guidance_point(
        self, raw_guidance_point, position, velocity
    ):
        raw_direction = np.asarray(raw_guidance_point, dtype=float) - position
        raw_norm = float(np.linalg.norm(raw_direction))
        if raw_norm <= 1e-9:
            return raw_guidance_point
        raw_direction /= raw_norm
        incoming, planning_speed = self._motion_direction(velocity)
        raw_angle = math.acos(
            float(np.clip(np.dot(incoming, raw_direction), -1.0, 1.0))
        )
        lookahead = float(
            np.clip(
                planning_speed * self.turn_lookahead_time,
                self.turn_lookahead_min,
                self.turn_lookahead_max,
            )
        )
        maximum_curvature = (
            self.current_available_lateral_acceleration / planning_speed**2
        )
        maximum_angle = math.asin(
            float(np.clip(0.5 * maximum_curvature * lookahead, 0.0, 1.0))
        )
        # Curvature alone becomes permissive at low speed.  The outer attitude
        # loop supplies a second physical limit: how far the commanded tangent
        # can rotate during one guidance response interval.
        attitude_response_angle = (
            float(np.max(np.abs(self.max_desired_rate[:2])))
            * self.guidance_response_time
        )
        maximum_angle = min(maximum_angle, attitude_response_angle)
        planned_direction = self._rotate_direction_toward(
            incoming, raw_direction, maximum_angle
        )
        self.raw_guidance_turn_angle = raw_angle
        self.planned_guidance_turn_angle = math.acos(
            float(np.clip(np.dot(incoming, planned_direction), -1.0, 1.0))
        )
        self.planned_curvature = (
            2.0
            * math.sin(self.planned_guidance_turn_angle)
            / max(lookahead, 1e-9)
        )
        self.path_virtual_waypoint = position + lookahead * planned_direction
        lateral_vector = planned_direction - np.dot(
            planned_direction, incoming
        ) * incoming
        lateral_norm = float(np.linalg.norm(lateral_vector))
        lateral_direction = (
            lateral_vector / lateral_norm
            if lateral_norm > 1e-9
            else np.zeros(3)
        )
        requested_lateral_acceleration = min(
            planning_speed**2 * self.planned_curvature,
            self.current_available_lateral_acceleration,
        )
        desired_thrust, used_lateral_acceleration = self._path_thrust_direction(
            incoming,
            lateral_direction,
            requested_lateral_acceleration,
        )
        self.planned_lateral_acceleration = used_lateral_acceleration
        desired_thrust /= max(float(np.linalg.norm(desired_thrust)), 1e-9)
        self.virtual_waypoint = position + lookahead * desired_thrust
        return self.virtual_waypoint.copy()

    def _path_thrust_direction(
        self, path_tangent, lateral_direction, lateral_acceleration
    ):
        """Convert ``v^2 * curvature`` into a feasible full-thrust direction."""
        tangent = np.asarray(path_tangent, dtype=float)
        tangent /= max(float(np.linalg.norm(tangent)), 1e-9)
        normal = np.asarray(lateral_direction, dtype=float)
        normal_norm = float(np.linalg.norm(normal))
        normal = normal / normal_norm if normal_norm > 1e-9 else np.zeros(3)

        gravity_vector = np.array(
            [0.0, 0.0, 9.81 * self.target_gravity_compensation]
        )
        thrust_acceleration = self.current_thrust_acceleration
        requested = max(float(lateral_acceleration), 0.0)
        if thrust_acceleration <= 0.0:
            fallback = (
                self.target_forward_acceleration * tangent
                + requested * normal
                + gravity_vector
            )
            return fallback, requested

        def forward_discriminant(scale):
            transverse = gravity_vector + scale * requested * normal
            tangent_projection = float(np.dot(tangent, transverse))
            discriminant = (
                tangent_projection**2
                + thrust_acceleration**2
                - float(np.dot(transverse, transverse))
            )
            return discriminant, transverse, tangent_projection

        scale = 1.0
        discriminant, transverse, tangent_projection = forward_discriminant(scale)
        if discriminant < 0.0:
            low, high = 0.0, 1.0
            for _ in range(24):
                middle = 0.5 * (low + high)
                if forward_discriminant(middle)[0] >= 0.0:
                    low = middle
                else:
                    high = middle
            scale = low
            discriminant, transverse, tangent_projection = forward_discriminant(
                scale
            )

        forward_acceleration = (
            -tangent_projection + math.sqrt(max(discriminant, 0.0))
        )
        thrust_vector = forward_acceleration * tangent + transverse
        return thrust_vector, scale * requested

    def _integrate_attitude(self, gyro, dt):
        if dt <= 0.0:
            return
        mean_rate = 0.5 * (self.previous_gyro + gyro)
        rotation = mean_rate * dt
        angle = np.linalg.norm(rotation)
        if angle > 1e-12:
            delta = np.r_[math.cos(angle / 2.0), rotation / angle * math.sin(angle / 2.0)]
            self.attitude = _quat_multiply(self.attitude, delta)
            self.attitude /= np.linalg.norm(self.attitude)

    @staticmethod
    def _lead_time(relative_position, relative_velocity, intercept_speed):
        a = float(np.dot(relative_velocity, relative_velocity) - intercept_speed**2)
        b = float(2.0 * np.dot(relative_position, relative_velocity))
        c = float(np.dot(relative_position, relative_position))
        roots = []
        if abs(a) < 1e-9:
            if abs(b) > 1e-9:
                roots = [-c / b]
        else:
            discriminant = b * b - 4.0 * a * c
            if discriminant >= 0.0:
                root = math.sqrt(discriminant)
                roots = [(-b - root) / (2.0 * a), (-b + root) / (2.0 * a)]
        positive = [value for value in roots if value >= 0.0 and np.isfinite(value)]
        return min(positive) if positive else 0.0

    def _moving_target_guidance_point(
        self, target_position, target_velocity, position, velocity
    ):
        relative_position = target_position - position
        distance = max(float(np.linalg.norm(relative_position)), 1e-9)
        los = relative_position / distance
        relative_velocity = target_velocity - velocity
        intercept_speed = max(
            float(np.linalg.norm(velocity)) + self.lead_speed_margin,
            self.min_intercept_speed,
        )
        lead_time = min(
            self._lead_time(relative_position, relative_velocity, intercept_speed),
            self.max_lead_time,
        )
        lead_direction = target_position + target_velocity * lead_time - position
        lead_norm = float(np.linalg.norm(lead_direction))
        lead_los = lead_direction / max(lead_norm, 1e-9)

        los_rate = np.cross(relative_position, relative_velocity) / max(
            distance**2, 1e-9
        )
        closing_speed = max(-float(np.dot(relative_velocity, los)), 0.0)
        proportional_navigation = (
            self.target_navigation_constant
            * closing_speed
            * np.cross(los_rate, los)
        )
        relative_speed_squared = float(np.dot(relative_velocity, relative_velocity))
        closest_time = (
            np.clip(
                -float(np.dot(relative_position, relative_velocity))
                / relative_speed_squared,
                0.0,
                self.max_lead_time,
            )
            if relative_speed_squared > 1e-9
            else 0.0
        )
        if closest_time > 0.0 and self.zero_effort_miss_gain > 0.0:
            zero_effort_miss = relative_position + relative_velocity * closest_time
            zero_effort_miss -= np.dot(zero_effort_miss, los) * los
            zem_acceleration = (
                self.zero_effort_miss_gain
                * zero_effort_miss
                / max(closest_time, self.minimum_zem_time) ** 2
            )
        else:
            zem_acceleration = np.zeros(3)

        terminal_correction = proportional_navigation + zem_acceleration
        correction_norm = float(np.linalg.norm(terminal_correction))
        if correction_norm > self.current_available_lateral_acceleration:
            terminal_correction *= (
                self.current_available_lateral_acceleration / correction_norm
            )

        desired_thrust = (
            self.target_forward_acceleration * lead_los
            + terminal_correction
        )
        desired_norm = float(np.linalg.norm(desired_thrust))
        if desired_norm <= 1e-9:
            return position + los
        return position + desired_thrust / desired_norm

    def _arrival_estimate(self, current_speed, distance):
        current_speed = max(float(current_speed), 0.0)
        distance = max(float(distance), 0.0)
        arrival_speed = math.sqrt(
            current_speed**2
            + 2.0 * self.route_speed_estimation_acceleration * distance
        )
        average_speed = max(
            0.5 * (current_speed + arrival_speed), self.turn_speed_floor
        )
        return arrival_speed, distance / average_speed

    def _route_continuation_metrics(
        self,
        target_index,
        balloon_states,
        available,
        incoming_direction,
        arrival_speed,
        prediction_time,
    ):
        incoming_norm = float(np.linalg.norm(incoming_direction))
        if incoming_norm <= 1e-9:
            return self.route_dead_end_penalty, 0, np.inf
        incoming = incoming_direction / incoming_norm
        projected_positions = (
            balloon_states[:, :3]
            + balloon_states[:, 3:6] * max(float(prediction_time), 0.0)
        )
        origin = projected_positions[target_index]
        other_indices = available[available != target_index]
        if other_indices.size == 0:
            return self.route_dead_end_penalty, 0, np.inf
        onward = projected_positions[other_indices] - origin
        onward_distances = np.linalg.norm(onward, axis=1)
        valid_rows = np.flatnonzero(onward_distances > 1e-9)
        turns = []
        for row in valid_rows:
            metrics = self._turn_acceleration_metrics(
                incoming,
                onward[row],
                onward_distances[row],
                arrival_speed,
            )
            turns.append((metrics[0], metrics[1], row))
        if not turns:
            return self.route_dead_end_penalty, 0, np.inf
        feasible = [
            item
            for item in turns
            if item[0] <= self.max_planned_turn
        ]
        minimum_required = min(item[1] for item in turns)
        if not feasible:
            return self.route_dead_end_penalty, 0, minimum_required
        successor_rows = np.asarray([item[2] for item in feasible], dtype=int)
        nearest = float(np.min(onward_distances[successor_rows]))
        successor_count = len(feasible)
        cost = (
            self.route_distance_weight * nearest
            + self.turn_weight * min(item[0] for item in feasible)
            - self.route_successor_bonus * min(successor_count, 3)
        )
        return cost, successor_count, minimum_required

    def _target_metrics(self, index, balloon_states, position, velocity):
        target_position = balloon_states[index, :3]
        target_velocity = balloon_states[index, 3:6]
        relative_position = target_position - position
        distance = max(float(np.linalg.norm(relative_position)), 1e-9)
        los = relative_position / distance
        relative_velocity = target_velocity - velocity
        closing_speed = -float(np.dot(relative_velocity, los))
        guidance_point = self._moving_target_guidance_point(
            target_position, target_velocity, position, velocity
        )
        guidance_direction = guidance_point - position
        incoming, planning_speed = self._motion_direction(velocity)
        turn_angle, required_acceleration, _ = self._turn_acceleration_metrics(
            incoming, guidance_direction, distance, planning_speed
        )
        score = (
            self.distance_weight * distance
            + self.turn_weight * turn_angle
            - self.closing_weight * closing_speed
            + self.altitude_weight * abs(float(relative_position[2]))
        )
        return score, guidance_point, turn_angle, distance, required_acceleration

    def _launch_clearance_active(self, position, simulation_time):
        if not self.launch_decided or not np.isfinite(self.actual_launch_time):
            return False
        flight_time = max(simulation_time - self.actual_launch_time, 0.0)
        altitude_gain = float(position[2] - self.waypoint_start[2])
        return (
            flight_time < self.launch_clearance_time
            or (
                altitude_gain < self.launch_clearance_altitude
                and flight_time < self.launch_clearance_max_time
            )
        )

    def _launch_clearance_guidance_point(
        self, position, velocity, simulation_time
    ):
        if not self._launch_clearance_active(position, simulation_time):
            return None
        incoming, planning_speed = self._motion_direction(velocity)
        direction = self.launch_direction / max(
            float(np.linalg.norm(self.launch_direction)), 1e-9
        )
        lookahead = float(
            np.clip(
                planning_speed * self.turn_lookahead_time,
                self.turn_lookahead_min,
                self.turn_lookahead_max,
            )
        )
        self.planned_guidance_turn_angle = math.acos(
            float(np.clip(np.dot(incoming, direction), -1.0, 1.0))
        )
        self.planned_curvature = (
            self.planned_guidance_turn_angle / max(lookahead, 1e-9)
        )
        self.virtual_waypoint = position + lookahead * direction
        self.path_virtual_waypoint = self.virtual_waypoint.copy()
        return self.virtual_waypoint.copy()

    def _select_target(self, observation, position, velocity, simulation_time):
        status = np.asarray(observation["balloon_status"]).reshape(-1)
        available = np.flatnonzero(status == 1)
        if available.size == 0:
            self.selected_target = None
            return None

        current_available = self.selected_target in set(available.tolist())
        states = np.asarray(observation["balloon_states"], dtype=float)
        self.target_approach_locked = False
        self.selected_target_passed = False
        if current_available:
            current_position = states[self.selected_target, :3]
            current_velocity = states[self.selected_target, 3:6]
            current_relative_position = current_position - position
            current_distance = float(np.linalg.norm(current_relative_position))
            if current_distance > 1e-9:
                current_los = current_relative_position / current_distance
                current_closing_speed = -float(
                    np.dot(current_velocity - velocity, current_los)
                )
                time_to_go = current_distance / max(current_closing_speed, 1e-9)
                self.target_approach_locked = (
                    current_closing_speed > 0.0
                    and time_to_go <= self.target_approach_lock_time
                )
                self.selected_target_passed = current_closing_speed <= 0.0
        clearance_active = self._launch_clearance_active(
            position, simulation_time
        )
        selection_due = (
            not clearance_active
            and not self.target_approach_locked
            and not (
                self.selected_target == self.corridor_target
                and not self.selected_target_passed
            )
            and simulation_time - self.last_target_selection_time
            >= self.target_switch_period
            and (
                self.selected_target_passed
                or simulation_time - self.selected_target_time
                >= self.target_commit_time
            )
        )
        if selection_due or not current_available:
            candidates = [
                (
                    self._target_metrics(int(index), states, position, velocity),
                    int(index),
                )
                for index in available
            ]
            feasible = [
                candidate
                for candidate in candidates
                if candidate[0][2] <= self.max_planned_turn
            ]
            candidate_pool = feasible if feasible else candidates

            speed = float(np.linalg.norm(velocity))

            def route_adjusted_score(candidate):
                incoming = candidate[0][1] - position
                arrival_speed, prediction_time = self._arrival_estimate(
                    speed, candidate[0][3]
                )
                route_cost, _, _ = self._route_continuation_metrics(
                    candidate[1],
                    states,
                    available,
                    incoming,
                    arrival_speed,
                    prediction_time,
                )
                return candidate[0][0] + route_cost

            new_target = min(candidate_pool, key=route_adjusted_score)[1]
            if new_target != self.selected_target:
                self.target_history.append(new_target)
                self.selected_target_time = simulation_time
            self.selected_target = new_target
            self.last_target_selection_time = simulation_time

        metrics = self._target_metrics(
            self.selected_target, states, position, velocity
        )
        self.selected_target_turn_angle = metrics[2]
        self.selected_target_distance = metrics[3]
        self.selected_target_required_lateral_acceleration = metrics[4]
        self.selected_target_relative_position = (
            states[self.selected_target, :3] - position
        )
        self.selected_target_relative_velocity = (
            states[self.selected_target, 3:6] - velocity
        )
        speed = float(np.linalg.norm(velocity))
        arrival_speed, prediction_time = self._arrival_estimate(speed, metrics[3])
        _, self.selected_target_successor_count, _ = self._route_continuation_metrics(
            self.selected_target,
            states,
            available,
            metrics[1] - position,
            arrival_speed,
            prediction_time,
        )
        self.raw_guidance_turn_angle = metrics[2]
        clearance_point = self._launch_clearance_guidance_point(
            position, velocity, simulation_time
        )
        if clearance_point is not None:
            return clearance_point
        self.planned_guidance_turn_angle = metrics[2]
        self.planned_curvature = 0.0
        self.planned_lateral_acceleration = 0.0
        self.virtual_waypoint = metrics[1].copy()
        self.path_virtual_waypoint = metrics[1].copy()
        return metrics[1]

    def _guidance_point(self, observation, position, velocity, simulation_time):
        if self.fixed_waypoints is None:
            return self._select_target(
                observation, position, velocity, simulation_time
            )

        distances = np.linalg.norm(self.fixed_waypoints - position, axis=1)
        if self.previous_guidance_position is not None:
            segment = position - self.previous_guidance_position
            segment_norm_sq = float(np.dot(segment, segment))
            if segment_norm_sq > 1e-12:
                fractions = np.clip(
                    (self.fixed_waypoints - self.previous_guidance_position)
                    @ segment
                    / segment_norm_sq,
                    0.0,
                    1.0,
                )
                swept_points = self.previous_guidance_position + fractions[:, None] * segment
                distances = np.minimum(
                    distances,
                    np.linalg.norm(self.fixed_waypoints - swept_points, axis=1),
                )
        speed = float(np.linalg.norm(velocity))
        improved = distances < self.closest_waypoint_distances
        self.closest_waypoint_distances[improved] = distances[improved]
        self.closest_waypoint_times[improved] = simulation_time
        self.closest_waypoint_speeds[improved] = speed

        distance = float(distances[self.current_waypoint_index])
        if distance <= self.waypoint_radius:
            passed_index = self.current_waypoint_index
            self.waypoints_passed[passed_index] = True
            self.waypoint_pass_times[passed_index] = simulation_time
            self.waypoint_pass_speeds[passed_index] = speed
            if passed_index + 1 < len(self.fixed_waypoints):
                self._activate_waypoint(passed_index + 1)
            else:
                self.waypoint_reached = True
                return None

        # Follow the line from the launch point through the waypoint.  Position
        # and velocity feedback damp cross-track motion; gravity feed-forward
        # converts the requested net acceleration into a thrust direction.
        from_start = position - self.active_segment_start
        along_track = float(np.dot(from_start, self.waypoint_line_direction))
        cross_track = from_start - along_track * self.waypoint_line_direction
        along_velocity = float(np.dot(velocity, self.waypoint_line_direction))
        cross_velocity = velocity - along_velocity * self.waypoint_line_direction
        relative_waypoint = self.fixed_waypoint - position
        relative_norm = float(np.linalg.norm(relative_waypoint))
        waypoint_los = (
            relative_waypoint / relative_norm
            if relative_norm > 1e-9
            else self.waypoint_line_direction
        )
        relative_velocity = -velocity
        los_rate = np.cross(relative_waypoint, relative_velocity) / max(
            relative_norm**2, 1e-9
        )
        closing_speed = max(float(np.dot(velocity, waypoint_los)), 0.0)
        proportional_navigation = (
            self.navigation_constant
            * closing_speed
            * np.cross(los_rate, waypoint_los)
        )
        pn_norm = float(np.linalg.norm(proportional_navigation))
        if pn_norm > self.max_lateral_acceleration:
            proportional_navigation *= self.max_lateral_acceleration / pn_norm
        desired_thrust = (
            self.line_forward_acceleration * waypoint_los
            - self.line_position_gain * cross_track
            - self.line_velocity_gain * cross_velocity
            + proportional_navigation
            + np.array([0.0, 0.0, 9.81])
        )
        thrust_norm = float(np.linalg.norm(desired_thrust))
        if thrust_norm <= 1e-9:
            return position + self.waypoint_line_direction
        return position + desired_thrust / thrust_norm

    def _pid_command(self, desired_rate, gyro, dt, gain_scale):
        error = desired_rate - gyro
        # Derivative on measurement avoids a command spike when guidance changes
        # the desired rate abruptly (set-point derivative kick).
        measurement_derivative = (
            -(gyro - self.previous_gyro) / dt if dt > 1e-9 else np.zeros(3)
        )
        candidate_integral = np.clip(
            self.rate_integral + error * max(dt, 0.0),
            -self.integral_limit,
            self.integral_limit,
        )
        unsaturated = gain_scale * (
            self.rate_kp * error
            + self.rate_ki * candidate_integral
            + self.rate_kd * measurement_derivative
        )
        limits = np.array([self.max_gimbal, self.max_gimbal, self.max_roll])
        command = np.clip(unsaturated, -limits, limits)

        # Conditional integration: accept integral only if not saturated or if
        # the present error drives a saturated output back toward its range.
        integrate = (np.abs(unsaturated) <= limits) | (error * unsaturated < 0.0)
        self.rate_integral = np.where(integrate, candidate_integral, self.rate_integral)
        return command, error

    def _apply_control_rate_limits(self, command, dt):
        if dt <= 0.0:
            return self.previous_control_command.copy()
        rate_limits = np.array(
            [self.gimbal_rate_limit, self.gimbal_rate_limit, self.roll_rate_limit]
        )
        # Stay microscopically inside the bound to avoid a false warning from
        # floating-point comparison at exactly rate_limit * dt.
        limited_delta = np.clip(
            command - self.previous_control_command,
            -0.999 * rate_limits * dt,
            0.999 * rate_limits * dt,
        )
        limited = self.previous_control_command + limited_delta
        self.previous_control_command = limited.copy()
        return limited

    def get_action(self, observation):
        simulation_time = float(observation["simulation_time"])
        self.current_available_lateral_acceleration = (
            self._available_lateral_acceleration(simulation_time)
        )
        self.current_thrust_acceleration = self._thrust_acceleration(
            simulation_time
        )
        self.current_launch_turn_acceleration = (
            self._available_launch_turn_acceleration(simulation_time)
        )
        dt = (
            max(simulation_time - self.previous_time, 0.0)
            if self.previous_time is not None
            else 0.0
        )
        sensors = np.asarray(observation["rocket_sensors"], dtype=float)
        valid = sensors.shape == (12,) and np.isfinite(sensors).all()
        status = np.asarray(observation["balloon_status"]).reshape(-1)
        released_count = int(np.count_nonzero(status == 1))
        required_released = math.ceil(
            len(status) * (self.launch_release_fraction or 0.0)
        )
        fixed_waypoint_mode = self.fixed_waypoints is not None
        fraction_ready = (
            self.launch_release_fraction is None
            or released_count >= required_released
        )
        launch_ready = simulation_time >= self.launch_time and (
            fixed_waypoint_mode
            or fraction_ready
            or simulation_time >= self.max_launch_time
        )
        if launch_ready and not self.launch_decided:
            if not fixed_waypoint_mode:
                self._prepare_balloon_launch(observation, simulation_time)
            self.launch_decided = True
            self.actual_launch_time = simulation_time

        gyro = np.zeros(3)
        position = np.array(
            [0.0, 0.0, float(self.given_parameters["environment"]["elevation"])]
        )
        velocity = np.zeros(3)
        acceleration = self.filtered_acceleration.copy()
        desired_rate = np.zeros(3)
        attitude_error = np.zeros(3)
        control_command = np.zeros(3)
        waypoint_distance = np.nan

        if valid:
            gyro_bias = _as_vector(
                self.given_parameters["rocket"]["sensors"]["gyro_constant_bias"],
                3,
                "gyro_constant_bias",
            )
            gyro = sensors[:3] - gyro_bias
            position = sensors[6:9].copy()
            velocity = sensors[9:12].copy()
            self._integrate_attitude(gyro, dt)

            if self.previous_velocity is not None and dt > 1e-9:
                raw_acceleration = (velocity - self.previous_velocity) / dt
                alpha = dt / (self.acceleration_filter_tau + dt)
                self.filtered_acceleration += alpha * (
                    raw_acceleration - self.filtered_acceleration
                )
            acceleration = self.filtered_acceleration.copy()
            self.previous_velocity = velocity.copy()

            intercept = self._guidance_point(
                observation, position, velocity, simulation_time
            )
            if self.fixed_waypoints is not None:
                self.previous_guidance_position = position.copy()
            if self.fixed_waypoints is not None and not self.waypoint_reached:
                waypoint_distance = float(
                    np.linalg.norm(self.fixed_waypoint - position)
                )
            if intercept is not None:
                direction = intercept - position
                norm = np.linalg.norm(direction)
                if norm > 1e-9:
                    desired_body = _rotate_inertial_to_body(
                        self.attitude, direction / norm
                    )
                    attitude_error = np.cross(np.array([0.0, 0.0, 1.0]), desired_body)
                    desired_rate = np.clip(
                        self.attitude_kp * attitude_error,
                        -self.max_desired_rate,
                        self.max_desired_rate,
                    )

            gain_scale = self._mass_gain_scale(simulation_time)
            control_command, _ = self._pid_command(
                desired_rate, gyro, dt, gain_scale
            )
            control_command = self._apply_control_rate_limits(control_command, dt)
            self.previous_gyro = gyro.copy()

        launch = self.launch_decided
        throttle = float(
            np.clip(self.throttle_command, self.throttle_min, self.throttle_max)
        )
        tvc = np.clip(control_command[:2], -self.max_gimbal, self.max_gimbal)
        roll = float(np.clip(control_command[2], -self.max_roll, self.max_roll))

        self.telemetry.append(
            {
                "time": simulation_time,
                "position": position.copy(),
                "velocity": velocity.copy(),
                "acceleration": acceleration.copy(),
                "gyro": gyro.copy(),
                "desired_rate": desired_rate.copy(),
                "tvc_x": float(tvc[0]),
                "tvc_y": float(tvc[1]),
                "roll": roll,
                "throttle": throttle,
                "target_index": -1 if self.selected_target is None else int(self.selected_target),
                "attitude_error": attitude_error.copy(),
                "waypoint_distance": waypoint_distance,
                "waypoint_reached": self.waypoint_reached,
                "waypoint_index": self.current_waypoint_index,
                "waypoints_reached_count": int(np.count_nonzero(self.waypoints_passed)),
                "released_balloon_count": released_count,
                "launch_command": launch,
                "target_turn_angle": self.selected_target_turn_angle,
                "target_distance": getattr(self, "selected_target_distance", np.nan),
                "target_relative_position": (
                    self.selected_target_relative_position.copy()
                ),
                "target_relative_velocity": (
                    self.selected_target_relative_velocity.copy()
                ),
                "target_successor_count": self.selected_target_successor_count,
                "target_approach_locked": self.target_approach_locked,
                "target_passed": self.selected_target_passed,
                "required_lateral_acceleration": (
                    self.selected_target_required_lateral_acceleration
                ),
                "available_lateral_acceleration": (
                    self.current_available_lateral_acceleration
                ),
                "available_launch_turn_acceleration": (
                    self.current_launch_turn_acceleration
                ),
                "raw_guidance_turn_angle": self.raw_guidance_turn_angle,
                "planned_guidance_turn_angle": self.planned_guidance_turn_angle,
                "planned_curvature": self.planned_curvature,
                "planned_lateral_acceleration": (
                    self.planned_lateral_acceleration
                ),
                "virtual_waypoint": self.virtual_waypoint.copy(),
                "path_virtual_waypoint": self.path_virtual_waypoint.copy(),
            }
        )
        self.previous_time = simulation_time

        return {
            "launch": launch,
            "launch_inclination_heading": self.launch_attitude.copy(),
            "tvc": tvc.astype(float),
            "roll": roll,
            "throttle": throttle,
        }
