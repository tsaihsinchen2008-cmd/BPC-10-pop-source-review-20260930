"""Three-balloon experiment built on the protected two-balloon PID agent.

Only observation data are used.  The stable acceleration-guidance and cascaded
PID implementation remains in ``guided_pid_agent_copy.py``; this subclass adds
three-target route lookahead and reacts when the swept rocket path pops a
balloon other than the currently selected target.
"""

from __future__ import annotations

import numpy as np

from BalloonPoppingGymEnv.agents.guided_pid_agent import _rotate_body_to_inertial
from BalloonPoppingGymEnv.agents.guided_pid_agent_copy import (
    GuidedPidAgent as TwoPointGuidedPidAgent,
    _unit,
)


class GuidedPidAgent(TwoPointGuidedPidAgent):
    """Plan an observation-only three-balloon route without changing the PID core."""

    def __init__(self, given_parameters, **kwargs):
        # These defaults are isolated to this experimental copy.  They reflect
        # the measured scenario-1 results: 80% release produced an incidental
        # second pop, while the higher rate-loop damping reduced turn miss.
        kwargs.setdefault("launch_release_fraction", 0.80)
        kwargs.setdefault("attitude_kp", [3.0, 3.0, 1.0])
        kwargs.setdefault("rate_kp", [18.0, 18.0, 2.0])
        kwargs.setdefault("rate_kd", [0.06, 0.06, 0.0])
        super().__init__(given_parameters, **kwargs)
        self.threepoint_max_handoffs = int(kwargs.get("threepoint_max_handoffs", 2))
        self.threepoint_route_lookahead = bool(
            kwargs.get("threepoint_route_lookahead", True)
        )
        self.threepoint_opportunistic_retarget = bool(
            kwargs.get("threepoint_opportunistic_retarget", True)
        )
        if self.threepoint_max_handoffs < 0:
            raise ValueError("threepoint_max_handoffs must be non-negative")
        self.threepoint_observed_popped_count = 0
        self.threepoint_opportunistic_retargets = 0
        self.threepoint_last_route = None
        self.threepoint_route_candidates = []

    def _best_third_target(
        self,
        second_index,
        first_index,
        states,
        released,
        first_position,
        incoming,
        first_speed,
        first_arrival_time,
        available_lateral,
        remaining_burn,
    ):
        """Return the best predicted continuation after a proposed second target."""
        second_at_first = (
            states[second_index, :3]
            + states[second_index, 3:6] * first_arrival_time
        )
        first_leg = second_at_first - first_position
        first_leg_distance = max(float(np.linalg.norm(first_leg)), 1e-9)
        first_turn, first_lateral, _ = self._turn_acceleration_metrics(
            incoming, first_leg, first_leg_distance, first_speed
        )
        second_speed, second_leg_time = self._arrival_estimate(
            first_speed, first_leg_distance
        )
        second_arrival_time = first_arrival_time + second_leg_time
        second_position = (
            states[second_index, :3]
            + states[second_index, 3:6] * second_arrival_time
        )
        second_incoming = _unit(first_leg, incoming)
        best = None
        for third_index in released:
            third_index = int(third_index)
            if third_index in (first_index, second_index):
                continue
            third_position = (
                states[third_index, :3]
                + states[third_index, 3:6] * second_arrival_time
            )
            second_leg = third_position - second_position
            second_leg_distance = max(float(np.linalg.norm(second_leg)), 1e-9)
            second_turn, second_lateral, _ = self._turn_acceleration_metrics(
                second_incoming,
                second_leg,
                second_leg_distance,
                second_speed,
            )
            _, third_leg_time = self._arrival_estimate(
                second_speed, second_leg_distance
            )
            total_time = second_arrival_time + third_leg_time
            feasible = bool(
                first_lateral
                <= available_lateral * self.acceleration_feasibility_margin
                and second_lateral
                <= available_lateral * self.acceleration_feasibility_margin
                and total_time < remaining_burn
            )
            candidate = {
                "second_index": int(second_index),
                "third_index": third_index,
                "first_lateral": first_lateral,
                "second_lateral": second_lateral,
                "first_turn": first_turn,
                "second_turn": second_turn,
                "total_time": total_time,
                "feasible": feasible,
            }
            key = (
                not feasible,
                max(first_lateral, second_lateral) / available_lateral,
                (first_lateral + second_lateral) / available_lateral,
                total_time,
            )
            if best is None or key < best[0]:
                best = key, candidate
        return None if best is None else best[1]

    def _trajectory_target(self, observation):
        if self.fixed_waypoints is not None:
            return super()._trajectory_target(observation)

        status = np.asarray(observation["balloon_status"]).reshape(-1)
        if self.selected_target is None or status[self.selected_target] != 1:
            return None
        states = np.asarray(observation["balloon_states"], dtype=float)
        target_index = int(self.selected_target)
        target_position = states[target_index, :3].copy()
        target_velocity = states[target_index, 3:6].copy()
        successors = []
        if (
            self.terminal_direction_weight <= 0.0
            or self.trajectory_completed_handoffs >= self.threepoint_max_handoffs
        ):
            return target_index, target_position, target_velocity, successors

        candidates = np.flatnonzero(status == 1)
        candidates = candidates[candidates != target_index]
        released = candidates.copy()
        if (
            self.trajectory_successor_source_target == target_index
            and self.trajectory_committed_successor is not None
            and status[self.trajectory_committed_successor] == 1
        ):
            candidates = np.asarray([self.trajectory_committed_successor], dtype=int)

        nose = _rotate_body_to_inertial(
            self.attitude, np.array([0.0, 0.0, 1.0])
        )
        incoming = _unit(self.previous_velocity, nose)
        speed = max(
            self.terminal_pass_speed,
            float(np.linalg.norm(self.previous_velocity))
            if self.previous_velocity is not None
            else 0.0,
        )
        available_lateral = max(
            self.current_available_lateral_acceleration
            * self.acceleration_feasibility_margin,
            1e-9,
        )
        remaining_burn = max(
            self.actual_launch_time
            + self.burn_time
            - float(observation["simulation_time"]),
            0.0,
        )
        use_route_lookahead = bool(
            self.threepoint_route_lookahead
            and self.trajectory_completed_handoffs == 0
            and candidates.size > 1
        )
        route_by_second = {}
        if use_route_lookahead:
            observed_position = np.asarray(
                observation["rocket_sensors"], dtype=float
            )[6:9]
            first_distance = float(np.linalg.norm(target_position - observed_position))
            first_speed, first_arrival_time = self._arrival_estimate(
                float(np.linalg.norm(self.previous_velocity)), first_distance
            )
            first_speed = max(first_speed, self.terminal_pass_speed)
            first_position = target_position + target_velocity * first_arrival_time
            for second_index in candidates:
                route = self._best_third_target(
                    int(second_index),
                    target_index,
                    states,
                    released,
                    first_position,
                    incoming,
                    first_speed,
                    first_arrival_time,
                    available_lateral,
                    remaining_burn,
                )
                if route is not None:
                    route_by_second[int(second_index)] = route
            self.threepoint_route_candidates = list(route_by_second.values())

        def successor_cost(index):
            index = int(index)
            if index in route_by_second:
                route = route_by_second[index]
                return (
                    not route["feasible"],
                    max(route["first_lateral"], route["second_lateral"])
                    / available_lateral,
                    (route["first_lateral"] + route["second_lateral"])
                    / available_lateral,
                    route["total_time"],
                )
            onward = states[index, :3] - target_position
            distance = max(float(np.linalg.norm(onward)), 1e-9)
            turn, required_lateral, _ = self._turn_acceleration_metrics(
                incoming, onward, distance, speed
            )
            return (
                required_lateral > available_lateral,
                required_lateral / available_lateral,
                turn,
                distance,
            )

        selected_successors = sorted(candidates.tolist(), key=successor_cost)[
            : self.trajectory_successor_candidates
        ]
        for second_index in selected_successors:
            successors.append(
                (
                    int(second_index),
                    states[second_index, :3].copy(),
                    states[second_index, 3:6].copy(),
                )
            )
        if selected_successors and selected_successors[0] in route_by_second:
            self.threepoint_last_route = route_by_second[selected_successors[0]].copy()
        return target_index, target_position, target_velocity, successors

    def _reachable_opportunistic_target(
        self, observation, position, velocity, simulation_time
    ):
        status = np.asarray(observation["balloon_status"]).reshape(-1)
        states = np.asarray(observation["balloon_states"], dtype=float)
        speed = float(np.linalg.norm(velocity))
        available = max(self.current_available_lateral_acceleration, 1e-9)
        remaining_burn = max(
            self.actual_launch_time + self.burn_time - simulation_time, 0.0
        )
        candidates = []
        for index in np.flatnonzero(status == 1):
            relative = states[index, :3] - position
            distance = max(float(np.linalg.norm(relative)), 1e-9)
            angle, required_lateral, _ = self._turn_acceleration_metrics(
                velocity, relative, distance, speed
            )
            _, arrival_time = self._arrival_estimate(speed, distance)
            if (
                required_lateral
                > available * self.acceleration_feasibility_margin
                or arrival_time >= remaining_burn
            ):
                continue
            candidates.append(
                (
                    arrival_time + required_lateral / available,
                    angle,
                    int(index),
                )
            )
        return None if not candidates else min(candidates)[2]

    def _select_target(self, observation, position, velocity, simulation_time):
        status = np.asarray(observation["balloon_status"]).reshape(-1)
        popped_count = int(np.count_nonzero(status == 2))
        if (
            self.threepoint_opportunistic_retarget
            and popped_count > self.threepoint_observed_popped_count
            and popped_count >= 2
            and self.selected_target is not None
            and status[self.selected_target] == 1
        ):
            replacement = self._reachable_opportunistic_target(
                observation, position, velocity, simulation_time
            )
            if replacement is not None and replacement != self.selected_target:
                self.selected_target = replacement
                self.selected_target_time = simulation_time
                self.last_target_selection_time = simulation_time
                self.target_history.append(replacement)
                self.trajectory_plan = None
                self.trajectory_completed_handoffs = self.threepoint_max_handoffs
                self.trajectory_committed_successor = None
                self.trajectory_successor_source_target = None
                self.threepoint_opportunistic_retargets += 1
        self.threepoint_observed_popped_count = popped_count
        return super()._select_target(
            observation, position, velocity, simulation_time
        )

    def get_action(self, observation):
        action = super().get_action(observation)
        self.telemetry[-1].update(
            {
                "threepoint_observed_popped_count": (
                    self.threepoint_observed_popped_count
                ),
                "threepoint_opportunistic_retargets": (
                    self.threepoint_opportunistic_retargets
                ),
            }
        )
        return action
