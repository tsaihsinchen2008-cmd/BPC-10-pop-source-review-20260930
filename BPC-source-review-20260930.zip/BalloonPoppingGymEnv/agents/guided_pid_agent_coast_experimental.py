"""Wider post-eight direction-bias experiment; unchanged physical actuator limits."""
import math
import numpy as np
from BalloonPoppingGymEnv.agents.guided_pid_agent_nine_balloon import GuidedPidAgent as Nine

class GuidedPidAgent(Nine):
    def __init__(self,given_parameters,terminal_capture_throttle_scale=1.,
                 terminal_capture_lateral_bias=0.12,terminal_capture_normal_bias=0.24,
                 terminal_capture_bias_duration=1.,coast_second_throttle=None,
                 coast_switch_time=1.,**kwargs):
        values=[terminal_capture_throttle_scale,terminal_capture_lateral_bias,
                terminal_capture_normal_bias,terminal_capture_bias_duration]
        if not all(math.isfinite(v) for v in values):
            raise ValueError('Coast settings must be finite')
        if not 0<=values[0]<=1 or max(abs(values[1]),abs(values[2]))>1.2 or not 0<values[3]<=3.:
            raise ValueError('Invalid coast experiment setting')
        super().__init__(given_parameters,**kwargs)
        backend=self.scheduled_backend
        backend.terminal_capture_throttle_scale=values[0]
        backend.terminal_capture_lateral_bias=values[1]
        backend.terminal_capture_normal_bias=values[2]
        backend.terminal_capture_bias_duration=values[3]
        self.experimental_config=dict(zip(('throttle','lateral','normal','duration'),values))
        if coast_second_throttle is not None and not (
            math.isfinite(coast_second_throttle) and 0<=coast_second_throttle<=1
        ):
            raise ValueError('Second throttle must be finite and within [0,1]')
        if not math.isfinite(coast_switch_time) or coast_switch_time<0:
            raise ValueError('Switch time must be finite and nonnegative')
        self._coast_first_throttle=values[0]
        self._coast_second_throttle=coast_second_throttle
        self._coast_switch_time=coast_switch_time
        self._coast_start=None
        self._coast_previous_time=None
        self.experimental_config.update(second_throttle=coast_second_throttle,
                                        switch_time=coast_switch_time)

    def get_action(self,observation):
        if self._coast_second_throttle is not None:
            now=float(observation['simulation_time'])
            if self._coast_previous_time is not None and now<self._coast_previous_time:
                self._coast_start=None
            self._coast_previous_time=now
            popped=int(np.count_nonzero(np.asarray(observation['balloon_status'])==2))
            if popped>=8 and self._coast_start is None:
                self._coast_start=now
            late=(self._coast_start is not None and
                  now-self._coast_start>=self._coast_switch_time)
            self.scheduled_backend.terminal_capture_throttle_scale=(
                self._coast_second_throttle if late else self._coast_first_throttle)
        return super().get_action(observation)
