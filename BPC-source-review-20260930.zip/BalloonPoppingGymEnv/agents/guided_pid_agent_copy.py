"""Observation-only time-parameterized acceleration guidance experiments.

The proven one-balloon PID agent stays untouched in ``guided_pid_agent.py``.
This module changes only its upstream thrust-direction reference and records
why a candidate trajectory was or was not physically achievable.
"""

from __future__ import annotations

import math
from collections import Counter

import numpy as np

from BalloonPoppingGymEnv.agents.guided_pid_agent import (
    GuidedPidAgent as BaselineGuidedPidAgent,
    _rotate_body_to_inertial,
    _rotate_inertial_to_body,
)


def _unit(vector, fallback=None):
    """Return a normalized vector without manufacturing NaN directions."""
    vector = np.asarray(vector, dtype=float)
    magnitude = float(np.linalg.norm(vector))
    if magnitude > 1e-9:
        return vector / magnitude
    if fallback is None:
        return np.array([0.0, 0.0, 1.0])
    return _unit(fallback)


def _angle(first, second):
    return math.acos(float(np.clip(np.dot(_unit(first), _unit(second)), -1.0, 1.0)))


class GuidedPidAgent(BaselineGuidedPidAgent):
    """Add physically screened acceleration guidance to the existing PID loops."""

    def __init__(self, given_parameters, **kwargs):
        self.use_acceleration_guidance = bool(
            kwargs.get("use_acceleration_guidance", True)
        )
        self.intercept_time_min = float(kwargs.get("intercept_time_min", 0.35))
        self.intercept_time_max = float(kwargs.get("intercept_time_max", 16.0))
        self.intercept_time_samples = int(kwargs.get("intercept_time_samples", 15))
        self.terminal_pass_speed = float(kwargs.get("terminal_pass_speed", 25.0))
        self.terminal_direction_weight = float(
            kwargs.get("terminal_direction_weight", 0.35)
        )
        self.acceleration_feasibility_margin = float(
            kwargs.get("acceleration_feasibility_margin", 0.98)
        )
        self.gravity_compensation = float(kwargs.get("gravity_compensation", 1.0))
        self.trajectory_replan_period = float(
            kwargs.get("trajectory_replan_period", 0.18)
        )
        self.trajectory_tracking_position_kp = float(
            kwargs.get("trajectory_tracking_position_kp", 0.12)
        )
        self.trajectory_tracking_velocity_kp = float(
            kwargs.get("trajectory_tracking_velocity_kp", 0.55)
        )
        self.max_trajectory_jerk = float(kwargs.get("max_trajectory_jerk", 15.0))
        self.trajectory_sample_count = int(kwargs.get("trajectory_sample_count", 7))
        self.trajectory_successor_candidates = int(
            kwargs.get("trajectory_successor_candidates", 2)
        )
        self.trajectory_lock_target = bool(kwargs.get("trajectory_lock_target", True))
        self.trajectory_direction_rate_margin = float(
            kwargs.get("trajectory_direction_rate_margin", 0.85)
        )

        if not 0.0 < self.intercept_time_min < self.intercept_time_max:
            raise ValueError("intercept time bounds must be positive and ordered")
        if self.intercept_time_samples < 2 or self.trajectory_sample_count < 2:
            raise ValueError("trajectory sampling must contain at least two values")
        if self.terminal_pass_speed <= 0.0:
            raise ValueError("terminal_pass_speed must be positive")
        if not 0.0 <= self.terminal_direction_weight <= 1.0:
            raise ValueError("terminal_direction_weight must be between zero and one")
        if not 0.0 < self.acceleration_feasibility_margin <= 1.0:
            raise ValueError("acceleration_feasibility_margin must be in (0, 1]")
        if self.gravity_compensation < 0.0:
            raise ValueError("gravity_compensation must be non-negative")
        if self.trajectory_replan_period <= 0.0:
            raise ValueError("trajectory_replan_period must be positive")
        if min(
            self.trajectory_tracking_position_kp,
            self.trajectory_tracking_velocity_kp,
        ) < 0.0:
            raise ValueError("trajectory tracking gains must be non-negative")
        if self.max_trajectory_jerk <= 0.0:
            raise ValueError("max_trajectory_jerk must be positive")
        if self.trajectory_successor_candidates < 1:
            raise ValueError("trajectory_successor_candidates must be positive")
        if not 0.0 < self.trajectory_direction_rate_margin <= 1.0:
            raise ValueError("trajectory_direction_rate_margin must be in (0, 1]")

        super().__init__(given_parameters, **kwargs)
        self.trajectory_plan = None
        self.trajectory_last_plan_time = -np.inf
        self.trajectory_last_direction = None
        self.trajectory_last_direction_time = None
        self.trajectory_committed_successor = None
        self.trajectory_successor_source_target = None
        self.trajectory_completed_handoffs = 0
        self.trajectory_candidate_count = 0
        self.trajectory_rejected_count = 0
        self.trajectory_rejection_counts = Counter()
        self.trajectory_snapshot = self._empty_trajectory_snapshot()

    @staticmethod
    def _hermite_coefficients(position, velocity, target, terminal_velocity, horizon):
        """Return a(0), jerk for p(T)=target and v(T)=terminal_velocity."""
        displacement = target - position - velocity * horizon
        velocity_delta = terminal_velocity - velocity
        acceleration = (
            6.0 * displacement / horizon**2 - 2.0 * velocity_delta / horizon
        )
        jerk = (
            6.0 * velocity_delta / horizon**2 - 12.0 * displacement / horizon**3
        )
        return acceleration, jerk

    @staticmethod
    def _trajectory_state(position, velocity, acceleration, jerk, elapsed):
        return (
            position
            + velocity * elapsed
            + 0.5 * acceleration * elapsed**2
            + jerk * elapsed**3 / 6.0,
            velocity + acceleration * elapsed + 0.5 * jerk * elapsed**2,
            acceleration + jerk * elapsed,
        )

    def _empty_trajectory_snapshot(self):
        return {
            "trajectory_target_index": -1,
            "trajectory_next_target_index": -1,
            "intercept_time_T": np.nan,
            "reference_position": np.full(3, np.nan),
            "reference_velocity": np.full(3, np.nan),
            "reference_acceleration": np.full(3, np.nan),
            "reference_jerk": np.full(3, np.nan),
            "required_thrust_acceleration": np.nan,
            "available_thrust_acceleration": np.nan,
            "trajectory_required_lateral_acceleration": np.nan,
            "trajectory_available_lateral_acceleration": np.nan,
            "trajectory_successor_distance": np.nan,
            "trajectory_successor_required_lateral_acceleration": np.nan,
            "minimum_turn_radius": np.nan,
            "desired_thrust_direction": np.full(3, np.nan),
            "desired_direction_rate": np.nan,
            "terminal_velocity_direction_error": np.nan,
            "trajectory_feasible": False,
            "feasibility_rejection_reason": "not_planned",
            "trajectory_candidate_count": self.trajectory_candidate_count
            if hasattr(self, "trajectory_candidate_count")
            else 0,
            "trajectory_rejected_count": self.trajectory_rejected_count
            if hasattr(self, "trajectory_rejected_count")
            else 0,
            "trajectory_thrust_projected": False,
            "trajectory_terminal_direction_weight": 0.0,
        }

    def _future_thrust_acceleration(self, simulation_time):
        if self.nominal_thrust <= 0.0:
            return 0.0
        if np.isfinite(self.actual_launch_time):
            flight_time = max(simulation_time - self.actual_launch_time, 0.0)
            if flight_time >= self.burn_time:
                return 0.0
        throttle = float(
            np.clip(self.throttle_command, self.throttle_min, self.throttle_max)
        )
        return self.nominal_thrust * throttle / max(
            self._scheduled_mass(simulation_time), 1e-9
        )

    def _trajectory_direction_rate_limit(self):
        body_rate = float(np.min(self.max_desired_rate[:2]))
        actuator_rate = math.radians(self.gimbal_rate_limit)
        return self.trajectory_direction_rate_margin * min(body_rate, actuator_rate)

    def _trajectory_target(self, observation):
        if self.fixed_waypoints is not None:
            if self.waypoint_reached:
                return None
            target_index = int(self.current_waypoint_index)
            successors = []
            if target_index + 1 < len(self.fixed_waypoints):
                successors.append(
                    (
                        target_index + 1,
                        self.fixed_waypoints[target_index + 1].copy(),
                        np.zeros(3),
                    )
                )
            return (
                target_index,
                self.fixed_waypoint.copy(),
                np.zeros(3),
                successors,
            )

        status = np.asarray(observation["balloon_status"]).reshape(-1)
        if self.selected_target is None or status[self.selected_target] != 1:
            return None
        states = np.asarray(observation["balloon_states"], dtype=float)
        target_index = int(self.selected_target)
        target_position = states[target_index, :3].copy()
        target_velocity = states[target_index, 3:6].copy()
        successors = []
        if (
            self.terminal_direction_weight > 0.0
            and self.trajectory_completed_handoffs == 0
        ):
            candidates = np.flatnonzero(status == 1)
            candidates = candidates[candidates != target_index]
            if (
                self.trajectory_successor_source_target == target_index
                and self.trajectory_committed_successor is not None
                and status[self.trajectory_committed_successor] == 1
            ):
                candidates = np.asarray(
                    [self.trajectory_committed_successor], dtype=int
                )
            nose = _rotate_body_to_inertial(
                self.attitude, np.array([0.0, 0.0, 1.0])
            )
            incoming = _unit(self.previous_velocity, nose)
            pair_speed = max(
                self.terminal_pass_speed,
                float(np.linalg.norm(self.previous_velocity))
                if self.previous_velocity is not None
                else 0.0,
            )
            available_lateral = max(
                self.current_available_lateral_acceleration
                * self.acceleration_feasibility_margin,
                1e-9,
            )

            def successor_cost(index):
                onward = states[index, :3] - target_position
                distance = max(float(np.linalg.norm(onward)), 1e-9)
                turn_angle, required_lateral, _ = self._turn_acceleration_metrics(
                    incoming, onward, distance, pair_speed
                )
                return (
                    required_lateral > available_lateral,
                    required_lateral / available_lateral,
                    turn_angle,
                    distance,
                )

            for candidate in sorted(candidates.tolist(), key=successor_cost)[
                : self.trajectory_successor_candidates
            ]:
                successors.append(
                    (
                        int(candidate),
                        states[candidate, :3].copy(),
                        states[candidate, 3:6].copy(),
                    )
                )
        return target_index, target_position, target_velocity, successors

    def _candidate_feasibility(
        self,
        position,
        velocity,
        acceleration,
        jerk,
        horizon,
        simulation_time,
    ):
        if float(np.linalg.norm(jerk)) > self.max_trajectory_jerk:
            return False, "jerk", None

        gravity = np.array([0.0, 0.0, 9.81 * self.gravity_compensation])
        sample_times = np.linspace(0.0, horizon, self.trajectory_sample_count)
        previous_direction = None
        previous_time = None
        peak_thrust_ratio = 0.0
        peak_lateral_ratio = 0.0
        peak_direction_rate = 0.0
        minimum_radius = np.inf
        magnitude_mismatch = 0.0

        for elapsed in sample_times:
            _, sample_velocity, sample_acceleration = self._trajectory_state(
                position, velocity, acceleration, jerk, elapsed
            )
            available_thrust = self._future_thrust_acceleration(
                simulation_time + elapsed
            )
            if available_thrust <= 1e-9:
                return False, "burn_time", None
            requested_thrust = sample_acceleration + gravity
            required_thrust = float(np.linalg.norm(requested_thrust))
            if required_thrust <= 1e-9:
                return False, "zero_thrust_direction", None
            thrust_ratio = required_thrust / (
                available_thrust * self.acceleration_feasibility_margin
            )
            peak_thrust_ratio = max(peak_thrust_ratio, thrust_ratio)
            magnitude_mismatch += abs(required_thrust - available_thrust)
            if thrust_ratio > 1.0 + 1e-9:
                return False, "thrust", None

            sample_speed = float(np.linalg.norm(sample_velocity))
            tangent = _unit(sample_velocity, self.launch_direction)
            lateral = float(
                np.linalg.norm(
                    sample_acceleration
                    - np.dot(sample_acceleration, tangent) * tangent
                )
            )
            available_lateral = min(
                self.max_lateral_acceleration,
                available_thrust * self.path_authority_margin,
            ) * self.acceleration_feasibility_margin
            if available_lateral <= 1e-9:
                return False, "lateral_authority", None
            lateral_ratio = lateral / available_lateral
            peak_lateral_ratio = max(peak_lateral_ratio, lateral_ratio)
            if lateral_ratio > 1.0 + 1e-9:
                return False, "lateral_acceleration", None
            if sample_speed > 1e-6:
                minimum_radius = min(
                    minimum_radius, sample_speed**2 / available_lateral
                )

            direction = requested_thrust / required_thrust
            if previous_direction is not None:
                direction_rate = _angle(previous_direction, direction) / max(
                    elapsed - previous_time, 1e-9
                )
                peak_direction_rate = max(peak_direction_rate, direction_rate)
                if direction_rate > self._trajectory_direction_rate_limit() + 1e-9:
                    return False, "attitude_direction_rate", None
            previous_direction = direction
            previous_time = elapsed

        desired_body = _rotate_inertial_to_body(
            self.attitude, _unit(acceleration + gravity)
        )
        attitude_error = np.cross(np.array([0.0, 0.0, 1.0]), desired_body)
        desired_rate = np.clip(
            self.attitude_kp * attitude_error,
            -self.max_desired_rate,
            self.max_desired_rate,
        )
        predicted_tvc = self._mass_gain_scale(simulation_time) * self.rate_kp[
            :2
        ] * (desired_rate[:2] - self.previous_gyro[:2])
        if np.any(np.abs(predicted_tvc) > self.max_gimbal + 1e-9):
            return False, "tvc_angle", None
        correction_window = min(max(self.trajectory_replan_period, 0.25), horizon)
        available_tvc_delta = self.gimbal_rate_limit * correction_window
        if np.any(
            np.abs(predicted_tvc - self.previous_control_command[:2])
            > available_tvc_delta + 1e-9
        ):
            return False, "tvc_slew", None

        return (
            True,
            "feasible",
            {
                "peak_thrust_ratio": peak_thrust_ratio,
                "peak_lateral_ratio": peak_lateral_ratio,
                "peak_direction_rate": peak_direction_rate,
                "minimum_turn_radius": minimum_radius,
                "thrust_mismatch": magnitude_mismatch / len(sample_times),
            },
        )

    def _trajectory_candidates(
        self,
        position,
        velocity,
        target_index,
        target_position,
        target_velocity,
        successors,
        simulation_time,
    ):
        horizons = np.linspace(
            self.intercept_time_min,
            self.intercept_time_max,
            self.intercept_time_samples,
        )
        if np.isfinite(self.actual_launch_time):
            remaining_burn = max(
                self.actual_launch_time + self.burn_time - simulation_time,
                0.0,
            )
            horizons = horizons[horizons < remaining_burn]
        if self.trajectory_plan is not None:
            remaining = self.trajectory_plan["end_time"] - simulation_time
            if (
                self.intercept_time_min <= remaining <= self.intercept_time_max
                and (
                    not np.isfinite(self.actual_launch_time)
                    or simulation_time + remaining
                    < self.actual_launch_time + self.burn_time
                )
            ):
                horizons = np.unique(np.r_[horizons, remaining])
        weighted_successors = [(None, 0.0)]
        if successors and self.terminal_direction_weight > 0.0:
            for successor in successors:
                weighted_successors.extend(
                    (successor, weight)
                    for weight in (
                        self.terminal_direction_weight,
                        0.5 * self.terminal_direction_weight,
                    )
                )

        for horizon in horizons:
            predicted_target = target_position + target_velocity * horizon
            displacement = predicted_target - position - velocity * horizon
            for successor, direction_weight in weighted_successors:
                if successor is None:
                    acceleration = 2.0 * displacement / horizon**2
                    jerk = np.zeros(3)
                    next_index = -1
                    next_direction = np.full(3, np.nan)
                    terminal_error = np.nan
                else:
                    next_index, next_position, next_velocity = successor
                    predicted_next = next_position + next_velocity * horizon
                    next_direction = _unit(
                        predicted_next - predicted_target,
                        predicted_target - position,
                    )
                    current_direction = _unit(
                        velocity, predicted_target - position
                    )
                    blended_direction = _unit(
                        (1.0 - direction_weight) * current_direction
                        + direction_weight * next_direction,
                        next_direction,
                    )
                    terminal_speed = max(
                        self.terminal_pass_speed,
                        min(float(np.linalg.norm(velocity)), 1.5 * self.terminal_pass_speed),
                    )
                    terminal_velocity = terminal_speed * blended_direction
                    acceleration, jerk = self._hermite_coefficients(
                        position,
                        velocity,
                        predicted_target,
                        terminal_velocity,
                        horizon,
                    )
                    terminal_error = _angle(terminal_velocity, next_direction)

                self.trajectory_candidate_count += 1
                feasible, reason, metrics = self._candidate_feasibility(
                    position,
                    velocity,
                    acceleration,
                    jerk,
                    horizon,
                    simulation_time,
                )
                if not feasible:
                    self.trajectory_rejected_count += 1
                    self.trajectory_rejection_counts[reason] += 1
                    continue

                score = (
                    horizon
                    + 0.2 * metrics["thrust_mismatch"]
                    + 0.2 * metrics["peak_lateral_ratio"]
                    + 0.03 * float(np.linalg.norm(jerk))
                )
                if np.isfinite(terminal_error):
                    score += 2.0 * terminal_error
                    score -= 0.5 * direction_weight
                yield {
                    "score": score,
                    "start_time": simulation_time,
                    "end_time": simulation_time + horizon,
                    "horizon": float(horizon),
                    "start_position": position.copy(),
                    "start_velocity": velocity.copy(),
                    "target_index": int(target_index),
                    "next_target_index": int(next_index),
                    "target_position": target_position.copy(),
                    "target_velocity": target_velocity.copy(),
                    "next_direction": next_direction.copy(),
                    "acceleration": acceleration.copy(),
                    "jerk": jerk.copy(),
                    "terminal_direction_error": terminal_error,
                    "direction_weight": direction_weight,
                    "minimum_turn_radius": metrics["minimum_turn_radius"],
                }

    def _plan_trajectory(self, observation, position, velocity, simulation_time):
        if self._future_thrust_acceleration(simulation_time) <= 1e-9:
            self.trajectory_plan = None
            return
        target = self._trajectory_target(observation)
        if target is None:
            self.trajectory_plan = None
            return
        target_index, target_position, target_velocity, successors = target
        replan_due = (
            self.trajectory_plan is None
            or self.trajectory_plan["target_index"] != target_index
            or simulation_time - self.trajectory_last_plan_time
            >= self.trajectory_replan_period
            or simulation_time >= self.trajectory_plan["end_time"]
        )
        if not replan_due:
            return

        candidates = list(
            self._trajectory_candidates(
                position,
                velocity,
                target_index,
                target_position,
                target_velocity,
                successors,
                simulation_time,
            )
        )
        self.trajectory_last_plan_time = simulation_time
        if candidates:
            constrained_candidates = [
                candidate
                for candidate in candidates
                if candidate["next_target_index"] >= 0
            ]
            candidate_pool = (
                constrained_candidates if constrained_candidates else candidates
            )
            self.trajectory_plan = min(
                candidate_pool, key=lambda item: item["score"]
            )
            if self.trajectory_plan["next_target_index"] >= 0:
                self.trajectory_committed_successor = int(
                    self.trajectory_plan["next_target_index"]
                )
                self.trajectory_successor_source_target = int(target_index)
        elif (
            self.trajectory_plan is None
            or self.trajectory_plan["target_index"] != target_index
            or simulation_time >= self.trajectory_plan["end_time"]
        ):
            self.trajectory_plan = None

    def _acceleration_guidance_point(
        self, observation, position, velocity, simulation_time
    ):
        self._plan_trajectory(observation, position, velocity, simulation_time)
        if self.trajectory_plan is None:
            if self._future_thrust_acceleration(simulation_time) <= 1e-9:
                dominant_reason = "burn_time"
            else:
                dominant_reason = (
                    self.trajectory_rejection_counts.most_common(1)[0][0]
                    if self.trajectory_rejection_counts
                    else "no_released_target"
                )
            self.trajectory_snapshot.update(
                {
                    "trajectory_target_index": -1
                    if self.selected_target is None
                    else int(self.selected_target),
                    "available_thrust_acceleration": (
                        self._future_thrust_acceleration(simulation_time)
                    ),
                    "trajectory_available_lateral_acceleration": (
                        self.current_available_lateral_acceleration
                    ),
                    "feasibility_rejection_reason": dominant_reason,
                }
            )
            nose = _rotate_body_to_inertial(
                self.attitude, np.array([0.0, 0.0, 1.0])
            )
            return position + _unit(nose)

        plan = self.trajectory_plan
        elapsed = np.clip(simulation_time - plan["start_time"], 0.0, plan["horizon"])
        reference_position, reference_velocity, reference_acceleration = (
            self._trajectory_state(
                plan["start_position"],
                plan["start_velocity"],
                plan["acceleration"],
                plan["jerk"],
                elapsed,
            )
        )
        acceleration_command = (
            reference_acceleration
            + self.trajectory_tracking_position_kp * (reference_position - position)
            + self.trajectory_tracking_velocity_kp * (reference_velocity - velocity)
        )
        gravity = np.array([0.0, 0.0, 9.81 * self.gravity_compensation])
        thrust_request = acceleration_command + gravity
        required_thrust = float(np.linalg.norm(thrust_request))
        available_thrust = self._future_thrust_acceleration(simulation_time)
        projected = required_thrust > available_thrust > 1e-9
        if projected:
            thrust_request *= available_thrust / required_thrust
        direction = _unit(thrust_request, self.launch_direction)

        direction_rate = 0.0
        if self.trajectory_last_direction is not None:
            direction_dt = max(
                simulation_time - self.trajectory_last_direction_time, 0.0
            )
            if direction_dt > 1e-9:
                allowed_turn = self._trajectory_direction_rate_limit() * direction_dt
                direction = self._rotate_direction_toward(
                    self.trajectory_last_direction, direction, allowed_turn
                )
                direction_rate = _angle(
                    self.trajectory_last_direction, direction
                ) / direction_dt
        self.trajectory_last_direction = direction.copy()
        self.trajectory_last_direction_time = simulation_time

        speed = float(np.linalg.norm(velocity))
        tangent = _unit(velocity, self.launch_direction)
        required_lateral = float(
            np.linalg.norm(
                acceleration_command - np.dot(acceleration_command, tangent) * tangent
            )
        )
        available_lateral = min(
            self.max_lateral_acceleration,
            available_thrust * self.path_authority_margin,
        )
        next_target_index = plan["next_target_index"]
        next_direction = plan["next_direction"]
        if (
            next_target_index < 0
            and self.fixed_waypoints is None
            and self.trajectory_successor_source_target == plan["target_index"]
            and self.trajectory_committed_successor is not None
        ):
            states = np.asarray(observation["balloon_states"], dtype=float)
            status = np.asarray(observation["balloon_status"]).reshape(-1)
            if status[self.trajectory_committed_successor] == 1:
                next_target_index = int(self.trajectory_committed_successor)
                next_direction = _unit(
                    states[next_target_index, :3]
                    - states[plan["target_index"], :3],
                    direction,
                )
        terminal_error = (
            _angle(velocity, next_direction)
            if np.isfinite(next_direction).all() and speed > 1e-9
            else plan["terminal_direction_error"]
        )
        successor_distance = np.nan
        successor_required_lateral = np.nan
        if next_target_index >= 0 and self.fixed_waypoints is None:
            states = np.asarray(observation["balloon_states"], dtype=float)
            onward = states[next_target_index, :3] - position
            successor_distance = float(np.linalg.norm(onward))
            if speed > 1e-9 and successor_distance > 1e-9:
                _, successor_required_lateral, _ = self._turn_acceleration_metrics(
                    velocity, onward, successor_distance, speed
                )
        self.planned_guidance_turn_angle = _angle(tangent, direction)
        self.planned_lateral_acceleration = required_lateral
        self.planned_curvature = required_lateral / max(speed**2, 1e-9)
        self.virtual_waypoint = position + direction
        self.path_virtual_waypoint = self.virtual_waypoint.copy()
        self.trajectory_snapshot.update(
            {
                "trajectory_target_index": plan["target_index"],
                "trajectory_next_target_index": next_target_index,
                "intercept_time_T": max(plan["end_time"] - simulation_time, 0.0),
                "reference_position": reference_position.copy(),
                "reference_velocity": reference_velocity.copy(),
                "reference_acceleration": reference_acceleration.copy(),
                "reference_jerk": plan["jerk"].copy(),
                "required_thrust_acceleration": required_thrust,
                "available_thrust_acceleration": available_thrust,
                "trajectory_required_lateral_acceleration": required_lateral,
                "trajectory_available_lateral_acceleration": available_lateral,
                "trajectory_successor_distance": successor_distance,
                "trajectory_successor_required_lateral_acceleration": (
                    successor_required_lateral
                ),
                "minimum_turn_radius": plan["minimum_turn_radius"],
                "desired_thrust_direction": direction.copy(),
                "desired_direction_rate": direction_rate,
                "terminal_velocity_direction_error": terminal_error,
                "trajectory_feasible": True,
                "feasibility_rejection_reason": (
                    "tracking_thrust_projected" if projected else "feasible"
                ),
                "trajectory_thrust_projected": projected,
                "trajectory_terminal_direction_weight": plan["direction_weight"],
            }
        )
        return position + direction

    def _select_target(self, observation, position, velocity, simulation_time):
        if not self.use_acceleration_guidance or not self.trajectory_lock_target:
            return super()._select_target(
                observation, position, velocity, simulation_time
            )
        status = np.asarray(observation["balloon_status"]).reshape(-1)
        if (
            self.selected_target is not None
            and status[self.selected_target] != 1
            and self.trajectory_successor_source_target == self.selected_target
            and self.trajectory_committed_successor is not None
            and status[self.trajectory_committed_successor] == 1
        ):
            self.selected_target = int(self.trajectory_committed_successor)
            self.selected_target_time = simulation_time
            self.last_target_selection_time = simulation_time
            self.target_history.append(self.selected_target)
            self.trajectory_plan = None
            self.trajectory_completed_handoffs += 1
            self.trajectory_committed_successor = None
            self.trajectory_successor_source_target = None
        locked = (
            self.selected_target is not None and status[self.selected_target] == 1
        )
        if not locked:
            return super()._select_target(
                observation, position, velocity, simulation_time
            )

        states = np.asarray(observation["balloon_states"], dtype=float)
        metrics = self._target_metrics(
            self.selected_target, states, position, velocity
        )
        self.selected_target_turn_angle = metrics[2]
        self.selected_target_distance = metrics[3]
        self.selected_target_required_lateral_acceleration = metrics[4]
        self.selected_target_relative_position = (
            states[self.selected_target, :3] - position
        )
        self.selected_target_relative_velocity = (
            states[self.selected_target, 3:6] - velocity
        )
        relative_norm = max(
            float(np.linalg.norm(self.selected_target_relative_position)), 1e-9
        )
        closing_speed = -float(
            np.dot(
                self.selected_target_relative_velocity,
                self.selected_target_relative_position / relative_norm,
            )
        )
        self.selected_target_passed = closing_speed <= 0.0
        self.target_approach_locked = closing_speed > 0.0
        self.raw_guidance_turn_angle = metrics[2]
        self.virtual_waypoint = metrics[1].copy()
        self.path_virtual_waypoint = metrics[1].copy()
        return metrics[1]

    def _guidance_point(self, observation, position, velocity, simulation_time):
        baseline_point = super()._guidance_point(
            observation, position, velocity, simulation_time
        )
        if not self.use_acceleration_guidance or baseline_point is None:
            return baseline_point
        return self._acceleration_guidance_point(
            observation, position, velocity, simulation_time
        )

    def get_action(self, observation):
        self.trajectory_snapshot = self._empty_trajectory_snapshot()
        action = super().get_action(observation)
        self.trajectory_snapshot["trajectory_candidate_count"] = (
            self.trajectory_candidate_count
        )
        self.trajectory_snapshot["trajectory_rejected_count"] = (
            self.trajectory_rejected_count
        )
        sample = self.telemetry[-1]
        sample.update(self.trajectory_snapshot)
        sample["gyro_tracking_error"] = sample["desired_rate"] - sample["gyro"]
        sample["tvc_saturated"] = bool(
            max(abs(sample["tvc_x"]), abs(sample["tvc_y"]))
            >= 0.99 * self.max_gimbal
        )
        sample["tvc_rate_limited"] = bool(
            sample["time"] > self.actual_launch_time
            and max(abs(sample["tvc_x"]), abs(sample["tvc_y"])) > 0.0
            and np.any(
                np.abs(sample["gyro_tracking_error"][:2])
                > self.max_gimbal / np.maximum(self.rate_kp[:2], 1e-9)
            )
        )
        return action
