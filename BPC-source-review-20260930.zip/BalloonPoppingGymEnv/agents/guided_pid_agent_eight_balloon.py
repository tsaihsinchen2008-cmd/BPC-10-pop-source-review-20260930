"""Eight-hit observation-only profile, validated on scenario 1 / seed 14."""

from BalloonPoppingGymEnv.agents.guided_pid_agent_seven_balloon import (
    GuidedPidAgent as _SevenBalloonAgent,
)


class GuidedPidAgent(_SevenBalloonAgent):
    def __init__(self, given_parameters, **kwargs):
        settings = {
            "dynamic_corridor_weight": 0.12,
            "dynamic_corridor_radius": 25.0,
            "dynamic_corridor_horizon": 6.0,
            "dynamic_corridor_min_popped": 5,
            "dynamic_corridor_one_shot": True,
            "dynamic_corridor_min_lock_duration": 4.0,
            "dynamic_corridor_use_powered_tgo": True,
            "use_terminal_capture_guidance": True,
            "terminal_capture_min_popped": 7,
            "terminal_capture_radius": 25.0,
            "terminal_capture_lookahead_weight": 0.0,
        }
        settings.update(kwargs)
        super().__init__(given_parameters, **settings)
