"""Energy-limited, curvature-continuous guidance for the balloon challenge.

The planner is active from launch and uses only the current observation and
constructor parameters.  Time-parameterized cubic Hermite trajectories are
the primary translational reference; a curvature-limited Frenet/ZEM law is the
fallback.  The protected attitude-P/rate-PID loops still turn the requested
thrust direction into TVC and roll commands.

Optional online identification estimates effective aerodynamic angular
damping and longitudinal drag from observation/action history.  Both models
are bounded and their feed-forward terms remain disabled until sufficient
excitation has been observed.
"""

from __future__ import annotations

import math

import numpy as np

from BalloonPoppingGymEnv.agents.guided_pid_agent import (
    _rotate_body_to_inertial,
    _rotate_inertial_to_body,
)
from BalloonPoppingGymEnv.agents.guided_pid_agent_THREEPOINT_backup import (
    GuidedPidAgent as ThreePointGuidedPidAgent,
)
from BalloonPoppingGymEnv.agents.guided_pid_agent_copy import _angle, _unit


class GuidedPidAgent(ThreePointGuidedPidAgent):
    """Plan low-energy curved trajectories from launch and retain PID control."""

    def __init__(self, given_parameters, **kwargs):
        kwargs.setdefault("launch_release_fraction", 0.75)
        kwargs.setdefault("trajectory_tracking_position_kp", 0.65)
        kwargs.setdefault(
            "threepoint_max_handoffs",
            int(kwargs.get("energy_arc_successor_handoffs", 1)),
        )
        super().__init__(given_parameters, **kwargs)

        self.energy_arc_cruise_speed = float(
            kwargs.get("energy_arc_cruise_speed", 34.0)
        )
        self.energy_arc_min_speed = float(
            kwargs.get("energy_arc_min_speed", 18.0)
        )
        self.energy_arc_pass_speed = float(
            kwargs.get("energy_arc_pass_speed", 30.0)
        )
        self.energy_arc_capture_distance = float(
            kwargs.get("energy_arc_capture_distance", 65.0)
        )
        self.energy_arc_replan_period = float(
            kwargs.get("energy_arc_replan_period", 0.12)
        )
        self.energy_arc_speed_kp = float(
            kwargs.get("energy_arc_speed_kp", 0.55)
        )
        self.energy_arc_max_tangential_acceleration = float(
            kwargs.get("energy_arc_max_tangential_acceleration", 3.0)
        )
        self.energy_arc_max_tangential_deceleration = float(
            kwargs.get("energy_arc_max_tangential_deceleration", 3.5)
        )
        self.energy_arc_lateral_authority = float(
            kwargs.get("energy_arc_lateral_authority", 0.88)
        )
        self.energy_arc_max_lateral_jerk = float(
            kwargs.get("energy_arc_max_lateral_jerk", 5.0)
        )
        self.energy_arc_speed_margin = float(
            kwargs.get("energy_arc_speed_margin", 0.88)
        )
        self.energy_arc_altitude_kp = float(
            kwargs.get("energy_arc_altitude_kp", 0.035)
        )
        self.energy_arc_altitude_kd = float(
            kwargs.get("energy_arc_altitude_kd", 0.24)
        )
        self.energy_arc_max_vertical_acceleration = float(
            kwargs.get("energy_arc_max_vertical_acceleration", 2.5)
        )
        self.energy_arc_altitude_buffer = float(
            kwargs.get("energy_arc_altitude_buffer", 8.0)
        )
        self.energy_arc_zem_gain = float(
            kwargs.get("energy_arc_zem_gain", 1.0)
        )
        self.energy_arc_zem_max_acceleration = float(
            kwargs.get("energy_arc_zem_max_acceleration", 3.0)
        )
        self.energy_arc_target_height_weight = float(
            kwargs.get("energy_arc_target_height_weight", 0.025)
        )
        self.energy_arc_target_time_weight = float(
            kwargs.get("energy_arc_target_time_weight", 1.0)
        )
        self.energy_arc_target_curvature_weight = float(
            kwargs.get("energy_arc_target_curvature_weight", 8.0)
        )
        self.energy_arc_target_speed_weight = float(
            kwargs.get("energy_arc_target_speed_weight", 0.25)
        )
        self.energy_arc_trajectory_speed_weight = float(
            kwargs.get("energy_arc_trajectory_speed_weight", 0.02)
        )
        self.energy_arc_trajectory_altitude_weight = float(
            kwargs.get("energy_arc_trajectory_altitude_weight", 0.01)
        )
        self.energy_arc_terminal_direction_weight = float(
            kwargs.get("energy_arc_terminal_direction_weight", 0.20)
        )
        self.energy_arc_hard_route_commit = bool(
            kwargs.get("energy_arc_hard_route_commit", False)
        )
        self.energy_arc_hard_deadline = bool(
            kwargs.get("energy_arc_hard_deadline", False)
        )
        self.energy_arc_use_zem_fallback = bool(
            kwargs.get("energy_arc_use_zem_fallback", True)
        )
        self.energy_arc_release_missed_target = bool(
            kwargs.get("energy_arc_release_missed_target", True)
        )
        self.energy_arc_capture_tube_distance = float(
            kwargs.get("energy_arc_capture_tube_distance", 40.0)
        )
        self.energy_arc_capture_tube_kp = float(
            kwargs.get("energy_arc_capture_tube_kp", 0.30)
        )
        self.energy_arc_capture_tube_max_acceleration = float(
            kwargs.get("energy_arc_capture_tube_max_acceleration", 1.5)
        )
        self.energy_arc_terminal_zem_gain = float(
            kwargs.get("energy_arc_terminal_zem_gain", 0.35)
        )
        self.energy_arc_terminal_zem_max_acceleration = float(
            kwargs.get("energy_arc_terminal_zem_max_acceleration", 0.8)
        )
        self.energy_arc_deadline_extension_weight = float(
            kwargs.get("energy_arc_deadline_extension_weight", 40.0)
        )
        self.terminal_pass_speed = self.energy_arc_pass_speed
        self.terminal_direction_weight = self.energy_arc_terminal_direction_weight

        self.use_energy_throttle_pid = bool(
            kwargs.get("use_energy_throttle_pid", True)
        )
        self.energy_throttle_floor = float(
            kwargs.get("energy_throttle_floor", 0.68)
        )
        self.energy_throttle_turn_floor = float(
            kwargs.get("energy_throttle_turn_floor", 0.86)
        )
        self.energy_throttle_kp = float(
            kwargs.get("energy_throttle_kp", 0.0025)
        )
        self.energy_throttle_ki = float(
            kwargs.get("energy_throttle_ki", 0.00035)
        )
        self.energy_throttle_integral_limit = float(
            kwargs.get("energy_throttle_integral_limit", 120.0)
        )
        self.energy_throttle_full_turn_ratio = float(
            kwargs.get("energy_throttle_full_turn_ratio", 1.05)
        )

        self.use_angular_sysid = bool(kwargs.get("use_angular_sysid", True))
        self.use_angular_feedforward = bool(
            kwargs.get("use_angular_feedforward", False)
        )
        self.angular_sysid_forgetting = float(
            kwargs.get("angular_sysid_forgetting", 0.998)
        )
        self.angular_sysid_min_samples = int(
            kwargs.get("angular_sysid_min_samples", 250)
        )
        self.angular_sysid_min_control_energy = float(
            kwargs.get("angular_sysid_min_control_energy", 120.0)
        )
        self.angular_feedforward_limit = float(
            kwargs.get("angular_feedforward_limit", 3.0)
        )
        self.angular_feedforward_min_aoa = math.radians(
            float(kwargs.get("angular_feedforward_min_aoa_deg", 5.0))
        )

        self.use_drag_sysid = bool(kwargs.get("use_drag_sysid", True))
        self.use_drag_feedforward = bool(
            kwargs.get("use_drag_feedforward", True)
        )
        self.use_drag_throttle_feedforward = bool(
            kwargs.get("use_drag_throttle_feedforward", False)
        )
        self.drag_sysid_min_samples = int(
            kwargs.get("drag_sysid_min_samples", 200)
        )
        self.drag_sysid_filter_gain = float(
            kwargs.get("drag_sysid_filter_gain", 0.015)
        )
        self.drag_coefficient_max = float(
            kwargs.get("drag_coefficient_max", 0.0012)
        )
        self.drag_sysid_max_aoa = math.radians(
            float(kwargs.get("drag_sysid_max_aoa_deg", 20.0))
        )

        positive = (
            self.energy_arc_cruise_speed,
            self.energy_arc_min_speed,
            self.energy_arc_pass_speed,
            self.energy_arc_capture_distance,
            self.energy_arc_replan_period,
            self.energy_arc_max_tangential_acceleration,
            self.energy_arc_max_tangential_deceleration,
            self.energy_arc_max_lateral_jerk,
            self.energy_arc_speed_margin,
            self.energy_arc_max_vertical_acceleration,
            self.energy_arc_capture_tube_max_acceleration,
            self.energy_arc_terminal_zem_max_acceleration,
            self.angular_sysid_forgetting,
            self.angular_feedforward_limit,
            self.drag_coefficient_max,
        )
        if min(positive) <= 0.0:
            raise ValueError("energy-arc positive parameters must be positive")
        if self.energy_arc_min_speed > self.energy_arc_cruise_speed:
            raise ValueError("energy_arc_min_speed cannot exceed cruise speed")
        if not 0.0 < self.energy_arc_lateral_authority <= 1.0:
            raise ValueError("energy_arc_lateral_authority must be in (0, 1]")
        if not 0.0 <= self.energy_arc_terminal_direction_weight <= 1.0:
            raise ValueError("energy_arc_terminal_direction_weight must be in [0, 1]")
        if self.energy_arc_capture_tube_kp < 0.0:
            raise ValueError("energy_arc_capture_tube_kp cannot be negative")
        if self.energy_arc_terminal_zem_gain < 0.0:
            raise ValueError("energy_arc_terminal_zem_gain cannot be negative")
        if not self.throttle_min <= self.energy_throttle_floor <= self.throttle_max:
            raise ValueError("energy_throttle_floor is outside throttle range")
        if not self.throttle_min <= self.energy_throttle_turn_floor <= self.throttle_max:
            raise ValueError("energy_throttle_turn_floor is outside throttle range")
        if not 0.0 < self.angular_sysid_forgetting <= 1.0:
            raise ValueError("angular_sysid_forgetting must be in (0, 1]")

        self.energy_arc_last_plan_time = -np.inf
        self.energy_arc_last_direction_time = None
        self.energy_arc_lateral_acceleration = 0.0
        self.energy_arc_previous_normal = np.zeros(3)
        self.energy_arc_throttle_integral = 0.0
        self.energy_arc_previous_throttle = self.throttle_max
        self.energy_arc_snapshot = self._empty_energy_arc_snapshot()

        # theta = [TVC effectiveness, AoA restoring, rate damping, bias].
        inertia = np.asarray(
            given_parameters["rocket"]["rocket_body"]["inertia"], dtype=float
        )
        motor_position = float(
            given_parameters["rocket"]["motor"].get("motor_position", -0.8)
        )
        nominal_arm = max(abs(motor_position), 0.25)
        initial_effectiveness = (
            self.nominal_thrust
            * nominal_arm
            / np.maximum(inertia[:2], 1e-6)
            * math.pi
            / 180.0
        )
        # Approximate rad/s² per degree; online identification corrects it.
        initial_effectiveness = np.clip(initial_effectiveness, 0.15, 1.5)
        self.angular_sysid_theta = np.column_stack(
            (initial_effectiveness, np.zeros((2, 3)))
        )
        self.angular_sysid_covariance = np.repeat(
            (50.0 * np.eye(4))[None, :, :], 2, axis=0
        )
        self.angular_sysid_samples = 0
        self.angular_sysid_control_energy = 0.0
        self.angular_sysid_confidence = 0.0
        self.angular_sysid_residual = np.zeros(2)
        self.angular_feedforward_command = np.zeros(2)
        self.angular_previous_feature = None
        self.angular_previous_gyro = None
        self.angular_previous_desired_rate = None

        self.drag_coefficient_estimate = 0.0
        self.drag_sysid_samples = 0
        self.drag_sysid_confidence = 0.0
        self.drag_sysid_residual = 0.0
        self.drag_previous_state = None
        self.energy_arc_missed_target_retargets = 0
        self.energy_arc_tracked_target = None
        self.energy_arc_target_was_closing = False

    @staticmethod
    def _empty_energy_arc_snapshot():
        return {
            "energy_arc_speed_reference": 0.0,
            "energy_arc_altitude_reference": np.nan,
            "energy_arc_curvature_reference": 0.0,
            "energy_arc_curvature_command": 0.0,
            "energy_arc_curvature_rate": 0.0,
            "energy_arc_radius": np.inf,
            "energy_arc_length": np.nan,
            "energy_arc_turn_time": np.nan,
            "energy_arc_tangential_acceleration": 0.0,
            "energy_arc_normal_acceleration": np.zeros(3),
            "energy_arc_vertical_acceleration": 0.0,
            "energy_arc_zem": np.zeros(3),
            "energy_arc_zem_correction": np.zeros(3),
            "energy_arc_specific_energy": np.nan,
            "energy_arc_reference_energy": np.nan,
            "energy_arc_energy_error": np.nan,
            "energy_arc_throttle_feedforward": 1.0,
            "energy_arc_throttle_feedback": 0.0,
            "energy_arc_requested_throttle": 1.0,
            "energy_arc_predicted_target": np.full(3, np.nan),
            "energy_arc_target_feasible": False,
            "energy_arc_guidance_mode": "none",
            "trajectory_target_index": -1,
        }

    def _full_thrust_acceleration(self, simulation_time):
        if self.nominal_thrust <= 0.0:
            return 0.0
        return self.nominal_thrust / max(
            self._scheduled_mass(simulation_time), 1e-9
        )

    def _future_thrust_acceleration(self, simulation_time):
        """Use full available authority while screening candidate trajectories."""
        if self.nominal_thrust <= 0.0:
            return 0.0
        if np.isfinite(self.actual_launch_time):
            flight_time = max(simulation_time - self.actual_launch_time, 0.0)
            if flight_time >= self.burn_time:
                return 0.0
        return self._full_thrust_acceleration(simulation_time)

    def _trajectory_candidates(
        self,
        position,
        velocity,
        target_index,
        target_position,
        target_velocity,
        successors,
        simulation_time,
    ):
        """Add speed, altitude and integrated curvature costs to Hermite plans."""
        for candidate in super()._trajectory_candidates(
            position,
            velocity,
            target_index,
            target_position,
            target_velocity,
            successors,
            simulation_time,
        ):
            if (
                self.energy_arc_hard_route_commit
                and successors
                and candidate["next_target_index"] < 0
            ):
                continue
            if (
                self.energy_arc_hard_deadline
                and self.trajectory_plan is not None
                and self.trajectory_plan["target_index"] == target_index
            ):
                committed_remaining = max(
                    self.trajectory_plan["end_time"] - simulation_time, 0.0
                )
                if (
                    committed_remaining >= self.intercept_time_min
                    and candidate["horizon"] > committed_remaining + 0.02
                ):
                    continue
            sample_times = np.linspace(
                0.0, candidate["horizon"], self.trajectory_sample_count
            )
            speeds = []
            altitudes = []
            curvatures = []
            for elapsed in sample_times:
                sample_position, sample_velocity, sample_acceleration = (
                    self._trajectory_state(
                        candidate["start_position"],
                        candidate["start_velocity"],
                        candidate["acceleration"],
                        candidate["jerk"],
                        elapsed,
                    )
                )
                sample_speed = float(np.linalg.norm(sample_velocity))
                tangent = _unit(sample_velocity, self.launch_direction)
                lateral = float(
                    np.linalg.norm(
                        sample_acceleration
                        - np.dot(sample_acceleration, tangent) * tangent
                    )
                )
                speeds.append(sample_speed)
                altitudes.append(float(sample_position[2]))
                curvatures.append(lateral / max(sample_speed**2, 1.0))
            speeds = np.asarray(speeds)
            altitudes = np.asarray(altitudes)
            speed_excess = np.maximum(
                speeds - self.energy_arc_cruise_speed, 0.0
            )
            terminal_target = (
                target_position + target_velocity * candidate["horizon"]
            )
            altitude_ceiling = max(
                float(position[2]), float(terminal_target[2])
            ) + self.energy_arc_altitude_buffer
            altitude_excess = np.maximum(altitudes - altitude_ceiling, 0.0)
            enriched = candidate.copy()
            enriched["score"] += (
                self.energy_arc_trajectory_speed_weight
                * float(np.mean(np.square(speed_excess)))
                + self.energy_arc_trajectory_altitude_weight
                * float(np.mean(np.square(altitude_excess)))
                + self.energy_arc_target_curvature_weight
                * float(np.mean(curvatures))
            )
            enriched["energy_arc_peak_speed"] = float(np.max(speeds))
            enriched["energy_arc_peak_altitude"] = float(np.max(altitudes))
            enriched["energy_arc_mean_curvature"] = float(
                np.mean(curvatures)
            )
            enriched["energy_arc_length"] = float(
                np.sum(
                    0.5
                    * (speeds[1:] + speeds[:-1])
                    * np.diff(sample_times)
                )
            )
            yield enriched

    def _arc_geometry(self, position, velocity, target_position):
        displacement = np.asarray(target_position, dtype=float) - position
        distance = max(float(np.linalg.norm(displacement)), 1e-9)
        tangent = _unit(velocity, self.launch_direction)
        los = displacement / distance
        parallel = float(np.dot(displacement, tangent))
        perpendicular_vector = displacement - parallel * tangent
        perpendicular = float(np.linalg.norm(perpendicular_vector))
        normal = _unit(perpendicular_vector, self.energy_arc_previous_normal)
        angle = _angle(tangent, los)
        if perpendicular <= 1e-6 or angle <= 1e-6:
            curvature = 0.0
            radius = np.inf
            arc_length = distance
        else:
            radius = distance**2 / max(2.0 * perpendicular, 1e-9)
            curvature = 1.0 / max(radius, 1e-9)
            central_angle = 2.0 * math.atan2(perpendicular, parallel)
            arc_length = max(abs(radius * central_angle), distance)
        return {
            "distance": distance,
            "tangent": tangent,
            "los": los,
            "normal": normal,
            "angle": angle,
            "curvature": curvature,
            "radius": radius,
            "arc_length": arc_length,
        }

    def _predict_arc_intercept(
        self,
        position,
        velocity,
        target_position,
        target_velocity,
        simulation_time,
    ):
        speed = float(np.linalg.norm(velocity))
        horizon = float(
            np.clip(
                np.linalg.norm(target_position - position)
                / max(self.energy_arc_cruise_speed, 1e-9),
                self.intercept_time_min,
                self.intercept_time_max,
            )
        )
        available_lateral = max(
            self.current_available_lateral_acceleration
            * self.energy_arc_lateral_authority,
            1e-6,
        )
        predicted_target = target_position.copy()
        geometry = None
        speed_reference = self.energy_arc_cruise_speed
        for _ in range(4):
            predicted_target = target_position + target_velocity * horizon
            geometry = self._arc_geometry(position, velocity, predicted_target)
            curvature = max(geometry["curvature"], 1e-9)
            curve_speed = self.energy_arc_speed_margin * math.sqrt(
                available_lateral / curvature
            )
            speed_reference = float(
                np.clip(
                    min(self.energy_arc_cruise_speed, curve_speed),
                    self.energy_arc_min_speed,
                    self.energy_arc_cruise_speed,
                )
            )
            average_speed = max(
                0.5 * (max(speed, self.energy_arc_min_speed) + speed_reference),
                self.energy_arc_min_speed,
            )
            horizon = float(
                np.clip(
                    geometry["arc_length"] / average_speed,
                    self.intercept_time_min,
                    self.intercept_time_max,
                )
            )
        remaining_burn = (
            max(self.actual_launch_time + self.burn_time - simulation_time, 0.0)
            if np.isfinite(self.actual_launch_time)
            else self.burn_time
        )
        feasible = bool(
            horizon < remaining_burn
            and speed_reference >= self.energy_arc_min_speed - 1e-9
        )
        return {
            **geometry,
            "horizon": horizon,
            "predicted_target": predicted_target,
            "speed_reference": speed_reference,
            "available_lateral": available_lateral,
            "feasible": feasible,
        }

    def _target_metrics(self, index, balloon_states, position, velocity):
        base = super()._target_metrics(index, balloon_states, position, velocity)
        score, guidance_point, turn, distance, required_lateral = base
        plan = self._predict_arc_intercept(
            position,
            velocity,
            balloon_states[index, :3],
            balloon_states[index, 3:6],
            self.previous_time if self.previous_time is not None else 0.0,
        )
        height = max(
            float(balloon_states[index, 2] - self.waypoint_start[2]), 0.0
        )
        curvature_ratio = (
            plan["curvature"]
            * max(float(np.linalg.norm(velocity)), self.energy_arc_min_speed) ** 2
            / max(plan["available_lateral"], 1e-9)
        )
        speed_excess = max(
            float(np.linalg.norm(velocity)) - plan["speed_reference"], 0.0
        )
        energy_score = (
            self.energy_arc_target_time_weight * plan["horizon"]
            + self.energy_arc_target_height_weight * height
            + self.energy_arc_target_curvature_weight * curvature_ratio
            + self.energy_arc_target_speed_weight * speed_excess
        )
        if not plan["feasible"]:
            energy_score += 1e4
        return (
            score + energy_score,
            guidance_point,
            turn,
            distance,
            required_lateral,
        )

    def _select_target(self, observation, position, velocity, simulation_time):
        """Release a missed target instead of commanding a turn back to it."""
        if (
            self.fixed_waypoints is None
            and self.energy_arc_release_missed_target
            and self.selected_target is not None
        ):
            status = np.asarray(observation["balloon_status"]).reshape(-1)
            target_index = int(self.selected_target)
            if target_index != self.energy_arc_tracked_target:
                self.energy_arc_tracked_target = target_index
                self.energy_arc_target_was_closing = False
            if status[target_index] == 1:
                states = np.asarray(observation["balloon_states"], dtype=float)
                relative_position = states[target_index, :3] - position
                distance = float(np.linalg.norm(relative_position))
                if distance > 1e-9:
                    line_of_sight = relative_position / distance
                    closing_speed = -float(
                        np.dot(
                            states[target_index, 3:6] - velocity,
                            line_of_sight,
                        )
                    )
                    if closing_speed > 0.0:
                        self.energy_arc_target_was_closing = True
                    if (
                        self.energy_arc_target_was_closing
                        and closing_speed <= 0.0
                        and distance > self.waypoint_radius
                    ):
                        self.selected_target = None
                        self.trajectory_plan = None
                        self.trajectory_committed_successor = None
                        self.trajectory_successor_source_target = None
                        self.energy_arc_missed_target_retargets += 1
                        self.energy_arc_tracked_target = None
                        self.energy_arc_target_was_closing = False
        return super()._select_target(
            observation, position, velocity, simulation_time
        )

    def _drag_compensation(self, velocity):
        speed = float(np.linalg.norm(velocity))
        if (
            not self.use_drag_feedforward
            or self.drag_sysid_confidence <= 0.0
            or speed <= 1e-6
        ):
            return np.zeros(3)
        return (
            self.drag_sysid_confidence
            * self.drag_coefficient_estimate
            * speed**2
            * velocity
            / speed
        )

    def _energy_arc_guidance(
        self,
        position,
        velocity,
        target_position,
        target_velocity,
        successors,
        simulation_time,
    ):
        plan = self._predict_arc_intercept(
            position,
            velocity,
            target_position,
            target_velocity,
            simulation_time,
        )
        speed = float(np.linalg.norm(velocity))
        tangent = _unit(velocity, self.launch_direction)
        normal = plan["normal"]
        speed_reference = plan["speed_reference"]
        terminal_velocity = self.energy_arc_pass_speed * plan["los"]
        next_target_index = -1
        next_direction = np.full(3, np.nan)
        if successors:
            next_target_index, next_position, next_velocity = successors[0]
            predicted_next = next_position + next_velocity * plan["horizon"]
            next_direction = _unit(
                predicted_next - plan["predicted_target"], plan["los"]
            )
            terminal_direction = _unit(
                (1.0 - self.terminal_direction_weight) * plan["los"]
                + self.terminal_direction_weight * next_direction,
                next_direction,
            )
            terminal_velocity = self.energy_arc_pass_speed * terminal_direction
            speed_reference = min(speed_reference, self.energy_arc_pass_speed)
        if plan["distance"] <= self.energy_arc_capture_distance:
            blend = 1.0 - plan["distance"] / self.energy_arc_capture_distance
            speed_reference = (
                (1.0 - blend) * speed_reference
                + blend * self.energy_arc_pass_speed
            )

        tangential_acceleration = float(
            np.clip(
                self.energy_arc_speed_kp * (speed_reference - speed),
                -self.energy_arc_max_tangential_deceleration,
                self.energy_arc_max_tangential_acceleration,
            )
        )
        route_acceleration, route_jerk = self._hermite_coefficients(
            position,
            velocity,
            plan["predicted_target"],
            terminal_velocity,
            max(plan["horizon"], self.intercept_time_min),
        )
        route_tangential = float(np.dot(route_acceleration, tangent))
        route_normal_vector = route_acceleration - route_tangential * tangent
        route_normal_magnitude = float(np.linalg.norm(route_normal_vector))
        normal = _unit(route_normal_vector, normal)
        tangential_acceleration = float(
            np.clip(
                tangential_acceleration + 0.30 * route_tangential,
                -self.energy_arc_max_tangential_deceleration,
                self.energy_arc_max_tangential_acceleration,
            )
        )
        desired_lateral = min(
            route_normal_magnitude,
            plan["available_lateral"],
        )
        dt = (
            max(simulation_time - self.energy_arc_last_direction_time, 0.0)
            if self.energy_arc_last_direction_time is not None
            else 0.0
        )
        maximum_lateral_change = self.energy_arc_max_lateral_jerk * dt
        lateral_acceleration = float(
            np.clip(
                desired_lateral,
                self.energy_arc_lateral_acceleration - maximum_lateral_change,
                self.energy_arc_lateral_acceleration + maximum_lateral_change,
            )
            if dt > 0.0
            else 0.0
        )
        previous_lateral = self.energy_arc_lateral_acceleration
        self.energy_arc_lateral_acceleration = lateral_acceleration
        self.energy_arc_previous_normal = normal.copy()
        self.energy_arc_last_direction_time = simulation_time

        altitude_reference = min(
            float(plan["predicted_target"][2]),
            max(
                float(position[2]),
                float(target_position[2]) + self.energy_arc_altitude_buffer,
            ),
        )
        # The 3-D Hermite normal already contains vertical trajectory shaping.
        # A separate altitude acceleration would double-count the same demand.
        vertical_acceleration = 0.0

        horizon = max(plan["horizon"], self.intercept_time_min)
        zem = plan["predicted_target"] - (position + velocity * horizon)
        zem_raw = 2.0 * zem / max(horizon**2, 1e-9)
        capture_blend = float(
            np.clip(
                1.0 - plan["distance"] / self.energy_arc_capture_distance,
                0.0,
                1.0,
            )
        )
        zem_correction = self.energy_arc_zem_gain * capture_blend * zem_raw
        zem_norm = float(np.linalg.norm(zem_correction))
        if zem_norm > self.energy_arc_zem_max_acceleration:
            zem_correction *= self.energy_arc_zem_max_acceleration / zem_norm

        acceleration_command = (
            tangential_acceleration * tangent
            + lateral_acceleration * normal
            + vertical_acceleration * np.array([0.0, 0.0, 1.0])
            + zem_correction
        )
        drag_compensation = self._drag_compensation(velocity)
        gravity = np.array([0.0, 0.0, 9.81 * self.gravity_compensation])
        thrust_request = acceleration_command + drag_compensation + gravity
        required_thrust = float(np.linalg.norm(thrust_request))
        full_thrust = self._full_thrust_acceleration(simulation_time)
        direction = _unit(thrust_request, self.launch_direction)

        specific_energy = 0.5 * speed**2 + 9.81 * float(position[2])
        reference_energy = (
            0.5 * speed_reference**2 + 9.81 * altitude_reference
        )
        energy_error = reference_energy - specific_energy
        throttle_feedforward = required_thrust / max(full_thrust, 1e-9)
        throttle_feedback = 0.0
        requested_throttle = self.throttle_max
        if self.use_energy_throttle_pid:
            candidate_integral = float(
                np.clip(
                    self.energy_arc_throttle_integral + energy_error * dt,
                    -self.energy_throttle_integral_limit,
                    self.energy_throttle_integral_limit,
                )
            )
            throttle_feedback = (
                self.energy_throttle_kp * energy_error
                + self.energy_throttle_ki * candidate_integral
            )
            requested_throttle = throttle_feedforward + throttle_feedback
            turn_ratio = lateral_acceleration / max(
                plan["available_lateral"], 1e-9
            )
            turn_floor = (
                self.energy_throttle_floor
                + (self.energy_throttle_turn_floor - self.energy_throttle_floor)
                * np.clip(turn_ratio, 0.0, 1.0)
            )
            if turn_ratio >= self.energy_throttle_full_turn_ratio:
                turn_floor = self.throttle_max
            requested_throttle = float(max(requested_throttle, turn_floor))
            clipped = float(
                np.clip(requested_throttle, self.throttle_min, self.throttle_max)
            )
            if (
                self.throttle_min < requested_throttle < self.throttle_max
                or energy_error * (requested_throttle - clipped) < 0.0
            ):
                self.energy_arc_throttle_integral = candidate_integral
            requested_throttle = clipped
        maximum_throttle_delta = (
            float(
                self.given_parameters["rocket"]["control"][
                    "throttle_rate_limit"
                ]
            )
            * dt
        )
        requested_throttle = float(
            np.clip(
                requested_throttle,
                self.energy_arc_previous_throttle - maximum_throttle_delta,
                self.energy_arc_previous_throttle + maximum_throttle_delta,
            )
            if dt > 0.0
            else self.energy_arc_previous_throttle
        )
        requested_throttle = float(
            np.clip(requested_throttle, self.throttle_min, self.throttle_max)
        )
        self.energy_arc_previous_throttle = requested_throttle
        self.throttle_command = requested_throttle

        curvature_command = lateral_acceleration / max(speed**2, 1e-9)
        curvature_rate = (
            (lateral_acceleration - previous_lateral)
            / max(dt, 1e-9)
            / max(speed**2, 1e-9)
            if dt > 0.0
            else 0.0
        )
        self.planned_curvature = curvature_command
        self.planned_lateral_acceleration = lateral_acceleration
        self.virtual_waypoint = position + direction
        self.path_virtual_waypoint = self.virtual_waypoint.copy()
        self.energy_arc_snapshot = {
            "energy_arc_speed_reference": speed_reference,
            "energy_arc_altitude_reference": altitude_reference,
            "energy_arc_curvature_reference": plan["curvature"],
            "energy_arc_curvature_command": curvature_command,
            "energy_arc_curvature_rate": curvature_rate,
            "energy_arc_radius": plan["radius"],
            "energy_arc_length": plan["arc_length"],
            "energy_arc_turn_time": plan["horizon"],
            "energy_arc_tangential_acceleration": tangential_acceleration,
            "energy_arc_normal_acceleration": lateral_acceleration * normal,
            "energy_arc_vertical_acceleration": vertical_acceleration,
            "energy_arc_zem": zem,
            "energy_arc_zem_correction": zem_correction,
            "energy_arc_reference_jerk": route_jerk.copy(),
            "energy_arc_specific_energy": specific_energy,
            "energy_arc_reference_energy": reference_energy,
            "energy_arc_energy_error": energy_error,
            "energy_arc_throttle_feedforward": throttle_feedforward,
            "energy_arc_throttle_feedback": throttle_feedback,
            "energy_arc_requested_throttle": requested_throttle,
            "energy_arc_predicted_target": plan["predicted_target"].copy(),
            "energy_arc_target_feasible": plan["feasible"],
            "energy_arc_guidance_mode": "frenet_zem_fallback",
            "energy_arc_drag_compensation": drag_compensation.copy(),
            "required_thrust_acceleration": required_thrust,
            "available_thrust_acceleration": full_thrust,
            "trajectory_required_lateral_acceleration": lateral_acceleration,
            "trajectory_available_lateral_acceleration": plan[
                "available_lateral"
            ],
            "desired_thrust_direction": direction.copy(),
            "desired_direction_rate": np.nan,
            "trajectory_next_target_index": int(next_target_index),
            "terminal_velocity_direction_error": (
                _angle(velocity, next_direction)
                if np.isfinite(next_direction).all() and speed > 1e-9
                else np.nan
            ),
            "trajectory_feasible": plan["feasible"],
            "trajectory_thrust_projected": required_thrust > full_thrust,
            "trajectory_terminal_direction_weight": (
                self.terminal_direction_weight if successors else 0.0
            ),
            "feasibility_rejection_reason": (
                "feasible" if plan["feasible"] else "burn_time"
            ),
        }
        return self.virtual_waypoint.copy()

    def _acceleration_guidance_point(
        self, observation, position, velocity, simulation_time
    ):
        guidance_point = super()._acceleration_guidance_point(
            observation, position, velocity, simulation_time
        )
        if self.trajectory_plan is None:
            target = self._trajectory_target(observation)
            if (
                self.energy_arc_use_zem_fallback
                and target is not None
                and self._future_thrust_acceleration(simulation_time) > 1e-9
            ):
                _, target_position, target_velocity, successors = target
                return self._energy_arc_guidance(
                    position,
                    velocity,
                    target_position,
                    target_velocity,
                    successors,
                    simulation_time,
                )
            self.energy_arc_snapshot = self._empty_energy_arc_snapshot()
            return guidance_point

        plan = self.trajectory_plan
        elapsed = float(
            np.clip(
                simulation_time - plan["start_time"], 0.0, plan["horizon"]
            )
        )
        reference_position, reference_velocity, _ = self._trajectory_state(
            plan["start_position"],
            plan["start_velocity"],
            plan["acceleration"],
            plan["jerk"],
            elapsed,
        )
        _, terminal_velocity, _ = self._trajectory_state(
            plan["start_position"],
            plan["start_velocity"],
            plan["acceleration"],
            plan["jerk"],
            plan["horizon"],
        )
        speed = float(np.linalg.norm(velocity))
        reference_speed = min(
            float(np.linalg.norm(terminal_velocity)),
            self.energy_arc_cruise_speed,
        )
        specific_energy = 0.5 * speed**2 + 9.81 * float(position[2])
        reference_energy = (
            0.5 * float(np.dot(reference_velocity, reference_velocity))
            + 9.81 * float(reference_position[2])
        )
        energy_error = reference_energy - specific_energy
        dt = (
            max(simulation_time - self.previous_time, 0.0)
            if self.previous_time is not None
            else 0.0
        )
        self.energy_arc_last_plan_time = simulation_time

        required_thrust = float(
            self.trajectory_snapshot.get("required_thrust_acceleration", np.nan)
        )
        full_thrust = self._full_thrust_acceleration(simulation_time)
        throttle_feedforward = (
            required_thrust / max(full_thrust, 1e-9)
            if np.isfinite(required_thrust)
            else self.throttle_max
        )
        throttle_feedback = 0.0
        requested_throttle = self.throttle_max
        integral_before_update = self.energy_arc_throttle_integral
        if self.use_energy_throttle_pid:
            candidate_integral = float(
                np.clip(
                    self.energy_arc_throttle_integral + energy_error * dt,
                    -self.energy_throttle_integral_limit,
                    self.energy_throttle_integral_limit,
                )
            )
            throttle_feedback = (
                self.energy_throttle_kp * energy_error
                + self.energy_throttle_ki * candidate_integral
            )
            requested_throttle = throttle_feedforward + throttle_feedback
            required_lateral = float(
                self.trajectory_snapshot.get(
                    "trajectory_required_lateral_acceleration", 0.0
                )
            )
            available_lateral = max(
                float(
                    self.trajectory_snapshot.get(
                        "trajectory_available_lateral_acceleration", 0.0
                    )
                ),
                1e-9,
            )
            turn_ratio = np.clip(
                required_lateral / available_lateral, 0.0, 1.0
            )
            turn_floor = (
                self.energy_throttle_floor
                + (self.energy_throttle_turn_floor - self.energy_throttle_floor)
                * turn_ratio
            )
            requested_throttle = max(requested_throttle, turn_floor)
            clipped = float(
                np.clip(requested_throttle, self.throttle_min, self.throttle_max)
            )
            if (
                self.throttle_min < requested_throttle < self.throttle_max
                or energy_error * (requested_throttle - clipped) < 0.0
            ):
                self.energy_arc_throttle_integral = candidate_integral
            requested_throttle = clipped
        drag_compensation = self._drag_compensation(velocity)
        desired_direction = np.asarray(
            self.trajectory_snapshot.get(
                "desired_thrust_direction", self.launch_direction
            ),
            dtype=float,
        )
        current_target = (
            plan["target_position"]
            + plan["target_velocity"]
            * max(simulation_time - plan["start_time"], 0.0)
        )
        target_relative = current_target - position
        target_distance = float(np.linalg.norm(target_relative))
        terminal_direction = _unit(terminal_velocity, desired_direction)
        cross_track = target_relative - float(
            np.dot(target_relative, terminal_direction)
        ) * terminal_direction
        capture_weight = float(
            np.clip(
                1.0 - target_distance / self.energy_arc_capture_tube_distance,
                0.0,
                1.0,
            )
        )
        capture_acceleration = (
            self.energy_arc_capture_tube_kp * capture_weight * cross_track
        )
        capture_norm = float(np.linalg.norm(capture_acceleration))
        if capture_norm > self.energy_arc_capture_tube_max_acceleration:
            capture_acceleration *= (
                self.energy_arc_capture_tube_max_acceleration / capture_norm
            )
        relative_velocity = plan["target_velocity"] - velocity
        closing_speed = (
            -float(np.dot(relative_velocity, target_relative / target_distance))
            if target_distance > 1e-9
            else 0.0
        )
        terminal_zem = np.zeros(3)
        terminal_zem_correction = np.zeros(3)
        if closing_speed > 1e-6 and capture_weight > 0.0:
            zem_time = float(
                np.clip(target_distance / closing_speed, 0.25, 2.0)
            )
            terminal_zem = target_relative + relative_velocity * zem_time
            terminal_zem_correction = (
                self.energy_arc_terminal_zem_gain
                * capture_weight
                * 2.0
                * terminal_zem
                / zem_time**2
            )
            zem_correction_norm = float(
                np.linalg.norm(terminal_zem_correction)
            )
            if (
                zem_correction_norm
                > self.energy_arc_terminal_zem_max_acceleration
            ):
                terminal_zem_correction *= (
                    self.energy_arc_terminal_zem_max_acceleration
                    / zem_correction_norm
                )
        extra_acceleration = (
            drag_compensation
            + capture_acceleration
            + terminal_zem_correction
        )
        if np.linalg.norm(extra_acceleration) > 0.0 and np.isfinite(required_thrust):
            compensated_thrust = (
                required_thrust * desired_direction + extra_acceleration
            )
            compensated_required_thrust = float(
                np.linalg.norm(compensated_thrust)
            )
            compensated_feedforward = (
                compensated_required_thrust / max(full_thrust, 1e-9)
            )
            if (
                self.use_energy_throttle_pid
                and self.use_drag_throttle_feedforward
            ):
                requested_throttle += (
                    compensated_feedforward - throttle_feedforward
                )
                throttle_feedforward = compensated_feedforward
            required_thrust = compensated_required_thrust
            desired_direction = _unit(compensated_thrust, desired_direction)
            guidance_point = position + desired_direction
            self.virtual_waypoint = guidance_point.copy()
            self.path_virtual_waypoint = guidance_point.copy()
            self.trajectory_snapshot["desired_thrust_direction"] = (
                desired_direction.copy()
            )
            self.trajectory_snapshot["required_thrust_acceleration"] = (
                required_thrust
            )

        unclipped_throttle = requested_throttle
        requested_throttle = float(
            np.clip(requested_throttle, self.throttle_min, self.throttle_max)
        )
        if (
            self.use_energy_throttle_pid
            and unclipped_throttle > self.throttle_max
            and energy_error > 0.0
        ):
            self.energy_arc_throttle_integral = integral_before_update
        maximum_delta = (
            float(
                self.given_parameters["rocket"]["control"][
                    "throttle_rate_limit"
                ]
            )
            * dt
        )
        if dt > 0.0:
            requested_throttle = float(
                np.clip(
                    requested_throttle,
                    self.energy_arc_previous_throttle - maximum_delta,
                    self.energy_arc_previous_throttle + maximum_delta,
                )
            )
        requested_throttle = float(
            np.clip(requested_throttle, self.throttle_min, self.throttle_max)
        )
        self.energy_arc_previous_throttle = requested_throttle
        self.throttle_command = requested_throttle

        curvature_command = float(
            self.planned_lateral_acceleration
            / max(speed**2, self.energy_arc_min_speed**2)
        )
        curvature_reference = float(
            plan.get("energy_arc_mean_curvature", curvature_command)
        )
        arc_radius = (
            1.0 / abs(curvature_reference)
            if abs(curvature_reference) > 1e-9
            else np.inf
        )
        predicted_target = (
            plan["target_position"]
            + plan["target_velocity"]
            * max(plan["end_time"] - simulation_time, 0.0)
        )
        self.energy_arc_snapshot = {
            "energy_arc_speed_reference": reference_speed,
            "energy_arc_altitude_reference": float(reference_position[2]),
            "energy_arc_curvature_reference": curvature_reference,
            "energy_arc_curvature_command": curvature_command,
            "energy_arc_curvature_rate": np.nan,
            "energy_arc_radius": arc_radius,
            "energy_arc_length": float(plan.get("energy_arc_length", np.nan)),
            "energy_arc_turn_time": max(plan["end_time"] - simulation_time, 0.0),
            "energy_arc_tangential_acceleration": float(
                np.dot(
                    np.asarray(self.trajectory_snapshot["reference_acceleration"]),
                    _unit(reference_velocity, self.launch_direction),
                )
            ),
            "energy_arc_normal_acceleration": np.full(3, np.nan),
            "energy_arc_vertical_acceleration": float(
                np.asarray(self.trajectory_snapshot["reference_acceleration"])[2]
            ),
            "energy_arc_zem": terminal_zem.copy(),
            "energy_arc_zem_correction": terminal_zem_correction.copy(),
            "energy_arc_reference_jerk": plan["jerk"].copy(),
            "energy_arc_specific_energy": specific_energy,
            "energy_arc_reference_energy": reference_energy,
            "energy_arc_energy_error": energy_error,
            "energy_arc_throttle_feedforward": throttle_feedforward,
            "energy_arc_throttle_feedback": throttle_feedback,
            "energy_arc_requested_throttle": requested_throttle,
            "energy_arc_predicted_target": predicted_target,
            "energy_arc_target_feasible": bool(
                self.trajectory_snapshot["trajectory_feasible"]
            ),
            "energy_arc_guidance_mode": "hermite",
            "energy_arc_drag_compensation": drag_compensation.copy(),
            "energy_arc_capture_acceleration": capture_acceleration.copy(),
        }
        return guidance_point

    def _pid_command(self, desired_rate, gyro, dt, gain_scale):
        command, error = super()._pid_command(
            desired_rate, gyro, dt, gain_scale
        )
        if self.use_angular_feedforward:
            command[:2] += self.angular_feedforward_command
        limits = np.array([self.max_gimbal, self.max_gimbal, self.max_roll])
        return np.clip(command, -limits, limits), error

    def _angular_features(self, velocity, gyro):
        speed = float(np.linalg.norm(velocity))
        if speed <= 1e-6:
            return np.zeros((2, 2)), 0.0
        body_velocity = _rotate_inertial_to_body(self.attitude, velocity)
        body_direction = body_velocity / speed
        aoa_vector = np.cross(np.array([0.0, 0.0, 1.0]), body_direction)
        aoa = math.acos(float(np.clip(body_direction[2], -1.0, 1.0)))
        aero_feature = speed**2 * aoa_vector[:2]
        rate_feature = speed * np.asarray(gyro[:2], dtype=float)
        return np.column_stack((aero_feature, rate_feature)), aoa

    def _update_angular_sysid(self, row, action, dt):
        velocity = np.asarray(row["velocity"], dtype=float)
        gyro = np.asarray(row["gyro"], dtype=float)
        desired_rate = np.asarray(row["desired_rate"], dtype=float)
        feature_pair, aoa = self._angular_features(velocity, gyro)
        current_feature = {
            "aero": feature_pair[:, 0].copy(),
            "rate": feature_pair[:, 1].copy(),
            "tvc": np.asarray(action["tvc"], dtype=float).copy(),
            "gyro": gyro[:2].copy(),
            "desired_rate": desired_rate[:2].copy(),
        }
        if (
            self.use_angular_sysid
            and self.angular_previous_feature is not None
            and 1e-4 < dt < 0.1
        ):
            angular_acceleration = (
                gyro[:2] - self.angular_previous_feature["gyro"]
            ) / dt
            for axis in range(2):
                previous = self.angular_previous_feature
                phi = np.array(
                    [
                        previous["tvc"][axis],
                        previous["aero"][axis],
                        previous["rate"][axis],
                        1.0,
                    ]
                )
                covariance = self.angular_sysid_covariance[axis]
                denominator = self.angular_sysid_forgetting + float(
                    phi @ covariance @ phi
                )
                gain = covariance @ phi / max(denominator, 1e-9)
                prediction = float(self.angular_sysid_theta[axis] @ phi)
                residual = float(
                    np.clip(angular_acceleration[axis] - prediction, -20.0, 20.0)
                )
                self.angular_sysid_theta[axis] += gain * residual
                self.angular_sysid_theta[axis, 0] = float(
                    np.clip(self.angular_sysid_theta[axis, 0], 0.03, 3.0)
                )
                self.angular_sysid_theta[axis, 1:] = np.clip(
                    self.angular_sysid_theta[axis, 1:], -5.0, 5.0
                )
                self.angular_sysid_covariance[axis] = (
                    covariance - np.outer(gain, phi) @ covariance
                ) / self.angular_sysid_forgetting
                self.angular_sysid_residual[axis] = residual
            self.angular_sysid_samples += 1
            self.angular_sysid_control_energy += float(
                np.dot(
                    self.angular_previous_feature["tvc"],
                    self.angular_previous_feature["tvc"],
                )
            ) * dt
        sample_confidence = min(
            self.angular_sysid_samples / max(self.angular_sysid_min_samples, 1),
            1.0,
        )
        excitation_confidence = min(
            self.angular_sysid_control_energy
            / max(self.angular_sysid_min_control_energy, 1e-9),
            1.0,
        )
        self.angular_sysid_confidence = sample_confidence * excitation_confidence

        feedforward = np.zeros(2)
        if (
            self.use_angular_feedforward
            and self.angular_previous_feature is not None
            and dt > 1e-4
        ):
            desired_acceleration = np.clip(
                (desired_rate[:2] - self.angular_previous_feature["desired_rate"])
                / dt,
                -3.0,
                3.0,
            )
            for axis in range(2):
                theta = self.angular_sysid_theta[axis]
                aero_prediction = (
                    theta[1] * current_feature["aero"][axis]
                    + theta[2] * current_feature["rate"][axis]
                    + theta[3]
                )
                feedforward[axis] = (
                    desired_acceleration[axis] - aero_prediction
                ) / max(theta[0], 0.03)
            aoa_weight = float(
                np.clip(
                    (aoa - self.angular_feedforward_min_aoa)
                    / max(self.angular_feedforward_min_aoa, 1e-6),
                    0.0,
                    1.0,
                )
            )
            feedforward *= self.angular_sysid_confidence * aoa_weight
        self.angular_feedforward_command = np.clip(
            feedforward,
            -self.angular_feedforward_limit,
            self.angular_feedforward_limit,
        )
        self.angular_previous_feature = current_feature
        return aoa

    def _update_drag_sysid(self, row, action, dt):
        velocity = np.asarray(row["velocity"], dtype=float)
        speed = float(np.linalg.norm(velocity))
        nose = _unit(
            _rotate_body_to_inertial(
                self.attitude, np.array([0.0, 0.0, 1.0])
            ),
            self.launch_direction,
        )
        if (
            self.use_drag_sysid
            and self.drag_previous_state is not None
            and speed > 10.0
            and 1e-4 < dt < 0.1
        ):
            previous = self.drag_previous_state
            previous_speed = float(np.linalg.norm(previous["velocity"]))
            previous_direction = _unit(
                previous["velocity"], previous["nose"]
            )
            previous_aoa = _angle(previous_direction, previous["nose"])
            if previous_aoa > self.drag_sysid_max_aoa:
                self.drag_previous_state = {
                    "velocity": velocity.copy(),
                    "nose": nose.copy(),
                    "throttle": float(action["throttle"]),
                    "mass": self._scheduled_mass(float(row["time"])),
                }
                return
            measured_acceleration = (velocity - previous["velocity"]) / dt
            tangent = _unit(previous["velocity"], previous["nose"])
            previous_full_thrust = self.nominal_thrust / max(
                previous["mass"], 1e-9
            )
            predicted_without_drag = (
                previous_full_thrust
                * previous["throttle"]
                * previous["nose"]
                - np.array([0.0, 0.0, 9.81])
            )
            residual_tangent = float(
                np.dot(predicted_without_drag - measured_acceleration, tangent)
            )
            sample = float(
                np.clip(
                    residual_tangent
                    / max(previous_speed**2, 1.0),
                    0.0,
                    self.drag_coefficient_max,
                )
            )
            self.drag_coefficient_estimate += self.drag_sysid_filter_gain * (
                sample - self.drag_coefficient_estimate
            )
            self.drag_sysid_residual = residual_tangent
            self.drag_sysid_samples += 1
        self.drag_sysid_confidence = min(
            self.drag_sysid_samples / max(self.drag_sysid_min_samples, 1), 1.0
        )
        self.drag_previous_state = {
            "velocity": velocity.copy(),
            "nose": nose.copy(),
            "throttle": float(action["throttle"]),
            "mass": self._scheduled_mass(float(row["time"])),
        }

    def get_action(self, observation):
        previous_time = self.previous_time
        action = super().get_action(observation)
        row = self.telemetry[-1]
        dt = (
            max(float(row["time"]) - previous_time, 0.0)
            if previous_time is not None
            else 0.0
        )
        aoa = self._update_angular_sysid(row, action, dt)
        self._update_drag_sysid(row, action, dt)
        row.update(self.energy_arc_snapshot)
        row.update(
            {
                "gyro_tracking_error": np.asarray(row["desired_rate"])
                - np.asarray(row["gyro"]),
                "energy_arc_aoa": aoa,
                "angular_sysid_theta": self.angular_sysid_theta.copy(),
                "angular_sysid_confidence": self.angular_sysid_confidence,
                "angular_sysid_residual": self.angular_sysid_residual.copy(),
                "angular_feedforward_command": (
                    self.angular_feedforward_command.copy()
                ),
                "drag_coefficient_estimate": self.drag_coefficient_estimate,
                "drag_sysid_confidence": self.drag_sysid_confidence,
                "drag_sysid_residual": self.drag_sysid_residual,
                "energy_arc_missed_target_retargets": (
                    self.energy_arc_missed_target_retargets
                ),
            }
        )
        return action
