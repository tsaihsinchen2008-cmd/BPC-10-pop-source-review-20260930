"""Quintic, speed-bounded experiment for the energy-arc guidance agent.

This module leaves the protected energy-arc implementation untouched.  It uses
the same observation-only navigation, target locking and cascaded attitude/PID
control, but replaces its cubic/constant-acceleration references with a single
quintic segment that explicitly constrains both endpoint velocity and
acceleration.
"""

from __future__ import annotations

import numpy as np

from BalloonPoppingGymEnv.agents.guided_pid_agent import (
    _rotate_body_to_inertial,
    _rotate_inertial_to_body,
)
from BalloonPoppingGymEnv.agents.guided_pid_agent_copy import _angle, _unit
from BalloonPoppingGymEnv.agents.guided_pid_agent_energy_arc import (
    GuidedPidAgent as EnergyArcGuidedPidAgent,
)
from BalloonPoppingGymEnv.agents.scheduled_intercept_agent import (
    ScheduledInterceptAgent,
)


class GuidedPidAgent(EnergyArcGuidedPidAgent):
    """Energy-arc controller with endpoint-constrained quintic references."""

    def __init__(self, given_parameters, **kwargs):
        # A quintic is deliberately committed for longer than the old cubic
        # reference.  Replanning every observation hides tracking error and is
        # prohibitively expensive when no candidate is feasible.
        kwargs.setdefault("trajectory_replan_period", 0.50)
        super().__init__(given_parameters, **kwargs)
        self.quintic_horizon_max = float(
            kwargs.get("quintic_horizon_max", 26.0)
        )
        self.quintic_horizon_samples = int(
            kwargs.get("quintic_horizon_samples", 8)
        )
        self.quintic_failed_replan_period = float(
            kwargs.get("quintic_failed_replan_period", 0.50)
        )
        self.quintic_max_endpoint_acceleration = float(
            kwargs.get("quintic_max_endpoint_acceleration", 2.5)
        )
        self.quintic_max_terminal_deceleration = float(
            kwargs.get("quintic_max_terminal_deceleration", 3.0)
        )
        self.quintic_min_pass_speed = float(
            kwargs.get("quintic_min_pass_speed", 10.0)
        )
        self.quintic_pass_speed_samples = int(
            kwargs.get("quintic_pass_speed_samples", 3)
        )
        self.quintic_speed_repair_penalty = float(
            kwargs.get("quintic_speed_repair_penalty", 3.0)
        )
        self.quintic_velocity_outlier_threshold = float(
            kwargs.get("quintic_velocity_outlier_threshold", 6.0)
        )
        self.quintic_velocity_filter_tau = float(
            kwargs.get("quintic_velocity_filter_tau", 0.08)
        )
        self.quintic_velocity_max_acceleration = float(
            kwargs.get("quintic_velocity_max_acceleration", 25.0)
        )
        self.quintic_no_route_hold_period = float(
            kwargs.get("quintic_no_route_hold_period", 0.50)
        )
        self.quintic_capture_hold_distance = float(
            kwargs.get("quintic_capture_hold_distance", 60.0)
        )
        self.quintic_terminal_intercept_distance = float(
            kwargs.get("quintic_terminal_intercept_distance", 140.0)
        )
        self.quintic_terminal_recovery_distance = float(
            kwargs.get("quintic_terminal_recovery_distance", 90.0)
        )
        self.quintic_terminal_navigation_constant = float(
            kwargs.get("quintic_terminal_navigation_constant", 3.0)
        )
        self.quintic_terminal_zem_gain = float(
            kwargs.get("quintic_terminal_zem_gain", 1.0)
        )
        self.quintic_terminal_zem_distance = float(
            kwargs.get("quintic_terminal_zem_distance", 60.0)
        )
        self.quintic_terminal_longitudinal_limit = float(
            kwargs.get("quintic_terminal_longitudinal_limit", 3.0)
        )
        self.quintic_terminal_time_min = float(
            kwargs.get("quintic_terminal_time_min", 0.25)
        )
        self.quintic_terminal_cpa_time_min = float(
            kwargs.get("quintic_terminal_cpa_time_min", 0.08)
        )
        self.quintic_terminal_time_max = float(
            kwargs.get("quintic_terminal_time_max", 2.5)
        )
        self.quintic_terminal_actuator_lead_time = float(
            kwargs.get("quintic_terminal_actuator_lead_time", 0.40)
        )
        self.quintic_terminal_recovery_lead_time = float(
            kwargs.get("quintic_terminal_recovery_lead_time", 0.20)
        )
        self.quintic_terminal_derivative_filter_tau = float(
            kwargs.get("quintic_terminal_derivative_filter_tau", 0.08)
        )
        self.quintic_aero_force_gain = float(
            kwargs.get("quintic_aero_force_gain", 1.00)
        )
        self.quintic_aero_force_limit = float(
            kwargs.get("quintic_aero_force_limit", 5.0)
        )
        self.quintic_aero_moment_gain = float(
            kwargs.get("quintic_aero_moment_gain", 0.65)
        )
        self.quintic_aero_moment_limit = float(
            kwargs.get("quintic_aero_moment_limit", 2.5)
        )
        self.quintic_post_pop_pass_speed = float(
            kwargs.get("quintic_post_pop_pass_speed", 10.0)
        )
        # Closed-loop additions are enabled only after two confirmed pops.  The
        # already repeatable first two interceptions therefore remain a stable
        # acquisition phase while the difficult third leg gets the richer
        # model and tracking layers.
        self.quintic_closed_loop_min_pops = int(
            kwargs.get("quintic_closed_loop_min_pops", 2)
        )
        self.quintic_governor_position_soft = float(
            kwargs.get("quintic_governor_position_soft", 10.0)
        )
        self.quintic_governor_position_hard = float(
            kwargs.get("quintic_governor_position_hard", 24.0)
        )
        self.quintic_governor_velocity_soft = float(
            kwargs.get("quintic_governor_velocity_soft", 5.0)
        )
        self.quintic_governor_velocity_hard = float(
            kwargs.get("quintic_governor_velocity_hard", 11.0)
        )
        self.quintic_governor_attitude_soft = np.deg2rad(
            float(kwargs.get("quintic_governor_attitude_soft_deg", 14.0))
        )
        self.quintic_governor_attitude_hard = np.deg2rad(
            float(kwargs.get("quintic_governor_attitude_hard_deg", 32.0))
        )
        self.quintic_governor_acceleration_soft = float(
            kwargs.get("quintic_governor_acceleration_soft", 4.0)
        )
        self.quintic_governor_acceleration_hard = float(
            kwargs.get("quintic_governor_acceleration_hard", 9.0)
        )
        self.quintic_governor_min_progress = float(
            kwargs.get("quintic_governor_min_progress", 0.18)
        )
        self.quintic_governor_filter_tau = float(
            kwargs.get("quintic_governor_filter_tau", 0.18)
        )
        self.quintic_governor_lag_limit = float(
            kwargs.get("quintic_governor_lag_limit", 0.75)
        )
        self.quintic_disturbance_filter_tau = float(
            kwargs.get("quintic_disturbance_filter_tau", 0.25)
        )
        self.quintic_disturbance_limit = float(
            kwargs.get("quintic_disturbance_limit", 3.0)
        )
        self.quintic_indi_gain = float(kwargs.get("quintic_indi_gain", 0.35))
        self.quintic_indi_limit = float(kwargs.get("quintic_indi_limit", 2.0))
        self.quintic_surrogate_direction_tau = float(
            kwargs.get("quintic_surrogate_direction_tau", 0.40)
        )
        self.quintic_surrogate_acceleration_tau = float(
            kwargs.get("quintic_surrogate_acceleration_tau", 0.18)
        )
        self.quintic_surrogate_step = float(
            kwargs.get("quintic_surrogate_step", 0.08)
        )
        self.quintic_capture_funnel_radius = float(
            kwargs.get("quintic_capture_funnel_radius", 18.0)
        )
        self.quintic_planless_terminal_enabled = bool(
            kwargs.get("quintic_planless_terminal_enabled", True)
        )
        self.quintic_planless_terminal_distance = float(
            kwargs.get("quintic_planless_terminal_distance", 45.0)
        )
        self.quintic_planless_terminal_closing_speed = float(
            kwargs.get("quintic_planless_terminal_closing_speed", 3.0)
        )
        self.quintic_planless_zem_gain = float(
            kwargs.get("quintic_planless_zem_gain", 1.0)
        )
        self.quintic_planless_navigation_constant = float(
            kwargs.get("quintic_planless_navigation_constant", 3.0)
        )
        self.quintic_planless_pass_speed = float(
            kwargs.get("quintic_planless_pass_speed", 10.0)
        )
        self.quintic_planless_throttle_floor = float(
            kwargs.get("quintic_planless_throttle_floor", 0.0)
        )
        self.quintic_planless_state_prediction_lead = float(
            kwargs.get("quintic_planless_state_prediction_lead", 0.0)
        )
        self.quintic_planless_longitudinal_limit = float(
            kwargs.get("quintic_planless_longitudinal_limit", 0.0)
        )
        self.quintic_planless_longitudinal_gain = float(
            kwargs.get("quintic_planless_longitudinal_gain", 0.0)
        )
        self.quintic_planless_disturbance_gain = float(
            kwargs.get("quintic_planless_disturbance_gain", 0.0)
        )
        self.quintic_surrogate_miss_weight = float(
            kwargs.get("quintic_surrogate_miss_weight", 0.70)
        )
        self.quintic_replan_error_hold = float(
            kwargs.get("quintic_replan_error_hold", 0.20)
        )
        self.quintic_replan_position_error = float(
            kwargs.get("quintic_replan_position_error", 30.0)
        )
        self.quintic_replan_velocity_error = float(
            kwargs.get("quintic_replan_velocity_error", 13.0)
        )
        if (
            self.quintic_horizon_max <= self.intercept_time_min
            or self.quintic_horizon_samples < 2
            or self.quintic_failed_replan_period <= 0.0
            or min(
                self.quintic_max_endpoint_acceleration,
                self.quintic_max_terminal_deceleration,
                self.quintic_min_pass_speed,
            ) <= 0.0
            or self.quintic_pass_speed_samples < 1
            or self.quintic_speed_repair_penalty < 0.0
            or min(
                self.quintic_velocity_outlier_threshold,
                self.quintic_velocity_filter_tau,
                self.quintic_velocity_max_acceleration,
                self.quintic_no_route_hold_period,
                self.quintic_capture_hold_distance,
                self.quintic_terminal_intercept_distance,
                self.quintic_terminal_recovery_distance,
                self.quintic_terminal_navigation_constant,
                self.quintic_terminal_zem_gain,
                self.quintic_terminal_zem_distance,
                self.quintic_terminal_longitudinal_limit,
                self.quintic_terminal_time_min,
                self.quintic_terminal_cpa_time_min,
                self.quintic_terminal_time_max,
                self.quintic_terminal_actuator_lead_time,
                self.quintic_terminal_recovery_lead_time,
                self.quintic_terminal_derivative_filter_tau,
                self.quintic_aero_force_gain,
                self.quintic_aero_force_limit,
                self.quintic_aero_moment_gain,
                self.quintic_aero_moment_limit,
                self.quintic_post_pop_pass_speed,
                self.quintic_governor_position_soft,
                self.quintic_governor_position_hard,
                self.quintic_governor_velocity_soft,
                self.quintic_governor_velocity_hard,
                self.quintic_governor_attitude_soft,
                self.quintic_governor_attitude_hard,
                self.quintic_governor_acceleration_soft,
                self.quintic_governor_acceleration_hard,
                self.quintic_governor_min_progress,
                self.quintic_governor_filter_tau,
                self.quintic_governor_lag_limit,
                self.quintic_disturbance_filter_tau,
                self.quintic_disturbance_limit,
                self.quintic_indi_limit,
                self.quintic_surrogate_direction_tau,
                self.quintic_surrogate_acceleration_tau,
                self.quintic_surrogate_step,
                self.quintic_capture_funnel_radius,
                self.quintic_planless_terminal_distance,
                self.quintic_planless_terminal_closing_speed,
                self.quintic_planless_zem_gain,
                self.quintic_planless_navigation_constant,
                self.quintic_replan_error_hold,
                self.quintic_replan_position_error,
                self.quintic_replan_velocity_error,
            ) <= 0.0
        ):
            raise ValueError("invalid quintic feasibility-repair parameters")
        if self.quintic_terminal_time_max <= self.quintic_terminal_time_min:
            raise ValueError("terminal intercept time bounds must be ordered")
        if not 0.0 < self.quintic_governor_min_progress <= 1.0:
            raise ValueError("governor minimum progress must be in (0, 1]")
        if not 0.0 <= self.quintic_indi_gain <= 1.0:
            raise ValueError("INDI gain must be in [0, 1]")
        if not 0.0 <= self.quintic_planless_throttle_floor <= self.throttle_max:
            raise ValueError("planless throttle floor must be within control limits")
        if self.quintic_planless_state_prediction_lead < 0.0:
            raise ValueError("planless state-prediction lead cannot be negative")
        if not 0.0 < self.quintic_planless_pass_speed <= 17.0:
            raise ValueError("planless pass speed must be in (0, 17] m/s")
        if not 0.0 < self.quintic_post_pop_pass_speed <= 17.0:
            raise ValueError("post-pop pass speed must be in (0, 17] m/s")
        if self.quintic_planless_longitudinal_limit < 0.0:
            raise ValueError("planless longitudinal limit cannot be negative")
        if self.quintic_planless_disturbance_gain < 0.0:
            raise ValueError("planless disturbance gain cannot be negative")
        self.quintic_trajectory_plan_id = 0
        self._quintic_last_plan_object = None
        self.quintic_last_reference_acceleration = np.zeros(3)
        self.quintic_next_retry_time = -np.inf
        self.quintic_replan_flag = False
        self.quintic_replan_reason = "not_planned"
        self.quintic_previous_navigation_position = None
        self.quintic_previous_navigation_time = None
        self.quintic_fused_velocity = None
        self.quintic_no_route_hold_until = -np.inf
        self.quintic_route_selection_diagnostics = []
        self.quintic_direct_commit_target = None
        self.quintic_direct_commit_deadline = np.nan
        self.quintic_observed_popped_count = 0
        self.quintic_aero_force_feedforward = np.zeros(3)
        self.quintic_aero_moment_feedforward = np.zeros(2)
        self.quintic_capture_hold_active = False
        self.quintic_terminal_intercept_active = False
        self.quintic_terminal_previous_acceleration = None
        self.quintic_terminal_previous_time = None
        self.quintic_terminal_previous_target = None
        self.quintic_terminal_filtered_acceleration_derivative = np.zeros(3)
        self.quintic_governor_plan_object = None
        self.quintic_virtual_elapsed = 0.0
        self.quintic_governor_previous_time = None
        self.quintic_governor_progress_rate = 1.0
        self.quintic_governor_saturated = False
        self.quintic_disturbance_estimate = np.zeros(3)
        self.quintic_previous_predicted_acceleration = None
        self.quintic_previous_commanded_thrust = None
        self.quintic_tracking_error_since = None
        self.quintic_event_replan_count = 0
        self.quintic_event_replan_pending = False
        self.quintic_previous_throttle_output = self.throttle_command
        self.quintic_capture_previous_target = None
        self.quintic_capture_previous_distance = None
        self.quintic_capture_previous_time = None

    @staticmethod
    def _quintic_coefficients(p0, v0, a0, p1, v1, a1, horizon):
        """Return ascending-power coefficients for p, p_dot and p_ddot."""
        horizon = max(float(horizon), 1e-9)
        coefficients = np.empty((6, 3), dtype=float)
        coefficients[0] = p0
        coefficients[1] = v0
        coefficients[2] = 0.5 * a0
        position_delta = p1 - (coefficients[0] + coefficients[1] * horizon + coefficients[2] * horizon**2)
        velocity_delta = v1 - (coefficients[1] + 2.0 * coefficients[2] * horizon)
        acceleration_delta = a1 - 2.0 * coefficients[2]
        coefficients[3] = (
            10.0 * position_delta
            - 4.0 * velocity_delta * horizon
            + 0.5 * acceleration_delta * horizon**2
        ) / horizon**3
        coefficients[4] = (
            -15.0 * position_delta
            + 7.0 * velocity_delta * horizon
            - acceleration_delta * horizon**2
        ) / horizon**4
        coefficients[5] = (
            6.0 * position_delta
            - 3.0 * velocity_delta * horizon
            + 0.5 * acceleration_delta * horizon**2
        ) / horizon**5
        return coefficients

    @staticmethod
    def _trajectory_state(position, velocity, coefficients, jerk, elapsed):
        """Evaluate either the inherited cubic form or quintic coefficients."""
        coefficients = np.asarray(coefficients, dtype=float)
        if coefficients.shape != (6, 3):
            return EnergyArcGuidedPidAgent._trajectory_state(
                position, velocity, coefficients, jerk, elapsed
            )
        elapsed = float(elapsed)
        powers = np.array([1.0, elapsed, elapsed**2, elapsed**3, elapsed**4, elapsed**5])
        position_value = powers @ coefficients
        velocity_value = np.array([0.0, 1.0, 2.0 * elapsed, 3.0 * elapsed**2, 4.0 * elapsed**3, 5.0 * elapsed**4]) @ coefficients
        acceleration_value = np.array([0.0, 0.0, 2.0, 6.0 * elapsed, 12.0 * elapsed**2, 20.0 * elapsed**3]) @ coefficients
        return position_value, velocity_value, acceleration_value

    @staticmethod
    def _quintic_jerk(coefficients, elapsed):
        return (
            6.0 * coefficients[3]
            + 24.0 * coefficients[4] * elapsed
            + 60.0 * coefficients[5] * elapsed**2
        )

    @staticmethod
    def _bounded_vector(value, limit):
        value = np.asarray(value, dtype=float)
        magnitude = float(np.linalg.norm(value))
        if magnitude > limit > 0.0:
            return value * (limit / magnitude)
        return value.copy()

    def _closed_loop_surrogate(
        self, candidate, position, velocity, target_position, target_velocity,
        simulation_time,
    ):
        """Propagate a compact observation-based closed-loop tracking model.

        The simulated thrust axis starts at the measured body axis.  Its
        0.40-s response represents the combined attitude/TVC/霹靂力矩 build-up;
        the translational state then includes thrust authority, gravity and the
        measured axial/normal aerodynamic force law.
        """
        horizon = float(candidate["horizon"])
        coefficients = np.asarray(candidate["polynomial_coefficients"], dtype=float)
        model_position = np.asarray(position, dtype=float).copy()
        model_velocity = np.asarray(velocity, dtype=float).copy()
        model_acceleration = np.asarray(self.filtered_acceleration, dtype=float).copy()
        thrust_direction = _unit(
            _rotate_body_to_inertial(
                self.attitude, np.array([0.0, 0.0, 1.0])
            ),
            self.launch_direction,
        )
        gravity = np.array([0.0, 0.0, 9.81 * self.gravity_compensation])
        direction_rate_limit = self._trajectory_direction_rate_limit()
        elapsed = 0.0
        closest_approach = np.inf
        peak_direction_error = 0.0
        previous_distance = np.inf
        closing_at_funnel = False
        entered_funnel = False
        while elapsed < horizon - 1e-9:
            dt = min(self.quintic_surrogate_step, horizon - elapsed)
            reference_position, reference_velocity, reference_acceleration = (
                self._trajectory_state(
                    candidate["start_position"],
                    candidate["start_velocity"],
                    coefficients,
                    candidate["jerk"],
                    elapsed,
                )
            )
            acceleration_command = (
                reference_acceleration
                + self.trajectory_tracking_position_kp
                * (reference_position - model_position)
                + self.trajectory_tracking_velocity_kp
                * (reference_velocity - model_velocity)
            )
            requested_thrust = acceleration_command + gravity
            requested_direction = _unit(requested_thrust, thrust_direction)
            direction_error = _angle(thrust_direction, requested_direction)
            peak_direction_error = max(peak_direction_error, direction_error)
            lag_turn = direction_error * (
                1.0 - np.exp(-dt / self.quintic_surrogate_direction_tau)
            )
            allowed_turn = min(lag_turn, direction_rate_limit * dt)
            thrust_direction = self._rotate_direction_toward(
                thrust_direction, requested_direction, allowed_turn
            )
            available_thrust = self._future_thrust_acceleration(
                simulation_time + elapsed
            )
            thrust_magnitude = min(
                float(np.linalg.norm(requested_thrust)), available_thrust
            )
            speed = float(np.linalg.norm(model_velocity))
            parallel_velocity = float(
                np.dot(model_velocity, thrust_direction)
            ) * thrust_direction
            normal_velocity = model_velocity - parallel_velocity
            aerodynamic_acceleration = -speed * (
                0.0002047811190869102 * parallel_velocity
                + 0.006820778357361975 * normal_velocity
            )
            predicted_acceleration = (
                thrust_magnitude * thrust_direction
                - gravity
                + aerodynamic_acceleration
            )
            tangent = _unit(model_velocity, thrust_direction)
            tangential = float(np.dot(predicted_acceleration, tangent)) * tangent
            lateral = self._bounded_vector(
                predicted_acceleration - tangential,
                min(self.max_lateral_acceleration, available_thrust),
            )
            predicted_acceleration = tangential + lateral
            alpha = dt / (self.quintic_surrogate_acceleration_tau + dt)
            model_acceleration += alpha * (
                predicted_acceleration - model_acceleration
            )
            model_velocity += model_acceleration * dt
            model_position += model_velocity * dt
            elapsed += dt
            moving_target = target_position + target_velocity * elapsed
            distance = float(np.linalg.norm(moving_target - model_position))
            closest_approach = min(closest_approach, distance)
            if distance <= self.quintic_capture_funnel_radius:
                entered_funnel = True
                closing_at_funnel = distance <= previous_distance
            previous_distance = distance
        final_target = target_position + target_velocity * horizon
        final_relative = final_target - model_position
        final_distance = float(np.linalg.norm(final_relative))
        final_closing_speed = -float(
            np.dot(
                target_velocity - model_velocity,
                _unit(final_relative, self.launch_direction),
            )
        )
        return {
            "predicted_closest_approach": float(closest_approach),
            "predicted_terminal_miss": final_distance,
            "predicted_terminal_closing_speed": final_closing_speed,
            "predicted_peak_direction_error": peak_direction_error,
            "predicted_capture_funnel": bool(
                entered_funnel and closing_at_funnel
            ),
        }

    @staticmethod
    def _governor_axis_rate(error, soft_limit, hard_limit, minimum_rate):
        if error <= soft_limit:
            return 1.0
        if error >= hard_limit:
            return minimum_rate
        blend = (error - soft_limit) / max(hard_limit - soft_limit, 1e-9)
        return 1.0 - blend * (1.0 - minimum_rate)

    def _governed_reference(
        self, plan, position, velocity, simulation_time
    ):
        """Advance trajectory virtual time only as fast as tracking permits."""
        if plan is not self.quintic_governor_plan_object:
            self.quintic_governor_plan_object = plan
            self.quintic_virtual_elapsed = 0.0
            self.quintic_governor_previous_time = simulation_time
            self.quintic_governor_progress_rate = 1.0
            self.quintic_tracking_error_since = None
        dt = max(
            simulation_time - self.quintic_governor_previous_time, 0.0
        )
        elapsed = float(
            np.clip(self.quintic_virtual_elapsed, 0.0, plan["horizon"])
        )
        reference = self._trajectory_state(
            plan["start_position"], plan["start_velocity"],
            plan["acceleration"], plan["jerk"], elapsed,
        )
        reference_position, reference_velocity, reference_acceleration = reference
        nominal_thrust = reference_acceleration + np.array(
            [0.0, 0.0, 9.81 * self.gravity_compensation]
        )
        nominal_direction = _unit(nominal_thrust, self.launch_direction)
        body_direction = _unit(
            _rotate_body_to_inertial(
                self.attitude, np.array([0.0, 0.0, 1.0])
            ),
            self.launch_direction,
        )
        position_error = float(np.linalg.norm(reference_position - position))
        velocity_error = float(np.linalg.norm(reference_velocity - velocity))
        attitude_error = _angle(body_direction, nominal_direction)
        acceleration_error = float(
            np.linalg.norm(reference_acceleration - self.filtered_acceleration)
        )
        previous_saturated = False
        if self.telemetry:
            previous = self.telemetry[-1]
            previous_saturated = bool(
                max(abs(float(previous.get("tvc_x", 0.0))),
                    abs(float(previous.get("tvc_y", 0.0))))
                >= 0.97 * self.max_gimbal
            )
        rates = (
            self._governor_axis_rate(
                position_error,
                self.quintic_governor_position_soft,
                self.quintic_governor_position_hard,
                self.quintic_governor_min_progress,
            ),
            self._governor_axis_rate(
                velocity_error,
                self.quintic_governor_velocity_soft,
                self.quintic_governor_velocity_hard,
                self.quintic_governor_min_progress,
            ),
            self._governor_axis_rate(
                attitude_error,
                self.quintic_governor_attitude_soft,
                self.quintic_governor_attitude_hard,
                self.quintic_governor_min_progress,
            ),
            self._governor_axis_rate(
                acceleration_error,
                self.quintic_governor_acceleration_soft,
                self.quintic_governor_acceleration_hard,
                self.quintic_governor_min_progress,
            ),
        )
        requested_rate = min(rates)
        if previous_saturated:
            requested_rate = min(requested_rate, 0.20)
        if dt > 0.0:
            alpha = dt / (self.quintic_governor_filter_tau + dt)
            self.quintic_governor_progress_rate += alpha * (
                requested_rate - self.quintic_governor_progress_rate
            )
            self.quintic_virtual_elapsed = float(
                np.clip(
                    self.quintic_virtual_elapsed
                    + dt * self.quintic_governor_progress_rate,
                    0.0,
                    plan["horizon"],
                )
            )
            wall_elapsed = float(
                np.clip(
                    simulation_time - plan["start_time"],
                    0.0,
                    plan["horizon"],
                )
            )
            self.quintic_virtual_elapsed = max(
                self.quintic_virtual_elapsed,
                wall_elapsed - self.quintic_governor_lag_limit,
            )
        self.quintic_governor_previous_time = simulation_time
        self.quintic_governor_saturated = previous_saturated
        reference = self._trajectory_state(
            plan["start_position"], plan["start_velocity"],
            plan["acceleration"], plan["jerk"], self.quintic_virtual_elapsed,
        )
        return reference, {
            "quintic_virtual_elapsed": self.quintic_virtual_elapsed,
            "quintic_governor_progress_rate": self.quintic_governor_progress_rate,
            "quintic_governor_time_lag": max(
                simulation_time - plan["start_time"]
                - self.quintic_virtual_elapsed,
                0.0,
            ),
            "quintic_governor_requested_rate": requested_rate,
            "quintic_governor_position_error": position_error,
            "quintic_governor_velocity_error": velocity_error,
            "quintic_governor_attitude_error": attitude_error,
            "quintic_governor_acceleration_error": acceleration_error,
            "quintic_governor_saturated": previous_saturated,
        }

    def _endpoint_acceleration(
        self, direction, current_speed, terminal_speed, horizon
    ):
        """Use a bounded tangential endpoint acceleration, never GNSS differencing."""
        requested = (terminal_speed - current_speed) / max(horizon, 1e-9)
        tangential = float(
            np.clip(
                requested,
                -self.quintic_max_terminal_deceleration,
                self.quintic_max_endpoint_acceleration,
            )
        )
        return tangential * _unit(direction, self.launch_direction)

    def _quintic_horizons(
        self, position, velocity, target_position, terminal_speed, simulation_time
    ):
        """Search a compact, distance-based horizon range and extend it first."""
        remaining = self.quintic_horizon_max
        if np.isfinite(self.actual_launch_time):
            remaining = min(
                remaining,
                self.actual_launch_time + self.burn_time - simulation_time - 0.05,
            )
        if remaining <= self.intercept_time_min:
            return np.empty(0)
        distance = max(float(np.linalg.norm(target_position - position)), 1.0)
        speed = float(np.linalg.norm(velocity))
        nominal = distance / max(0.5 * (speed + terminal_speed), 8.0)
        lower = max(self.intercept_time_min, 0.65 * nominal)
        upper = min(remaining, max(1.35 * nominal, lower + 1.0))
        if upper < lower:
            lower = upper = remaining
        return np.unique(
            np.r_[
                np.linspace(lower, upper, self.quintic_horizon_samples),
                remaining,
            ]
        )

    def _quintic_pass_speeds(self):
        """Try the requested nonzero pass speed before explicit speed repair."""
        if self.quintic_observed_popped_count >= self.quintic_closed_loop_min_pops:
            return np.array([10.0, 11.0, 8.0, 14.0, 17.0])
        requested = self.terminal_pass_speed
        if self.quintic_observed_popped_count >= 1:
            # Preserve the established second interception while post-two
            # terminal-speed scheduling is evaluated independently.
            requested = min(requested, 20.0)
        minimum = min(requested, self.quintic_min_pass_speed)
        return np.linspace(
            requested,
            minimum,
            self.quintic_pass_speed_samples,
        )

    def _navigation_observation(self, observation):
        """Fuse public GNSS position and velocity without differencing velocity."""
        sensors = np.asarray(observation["rocket_sensors"], dtype=float)
        raw_velocity = np.full(3, np.nan)
        position_velocity = np.full(3, np.nan)
        fused_velocity = np.full(3, np.nan)
        velocity_outlier = False
        if sensors.shape != (12,) or not np.isfinite(sensors).all():
            return observation, {
                "gnss_velocity_raw": raw_velocity,
                "position_difference_velocity": position_velocity,
                "navigation_velocity_fused": fused_velocity,
                "gnss_velocity_outlier": velocity_outlier,
            }

        simulation_time = float(observation["simulation_time"])
        position = sensors[6:9].copy()
        raw_velocity = sensors[9:12].copy()
        if (
            self.quintic_previous_navigation_position is not None
            and self.quintic_previous_navigation_time is not None
        ):
            dt = simulation_time - self.quintic_previous_navigation_time
            if 1e-4 < dt <= 0.1:
                position_velocity = (
                    position - self.quintic_previous_navigation_position
                ) / dt
                velocity_outlier = bool(
                    np.linalg.norm(raw_velocity - position_velocity)
                    > self.quintic_velocity_outlier_threshold
                )
                measurement = (
                    position_velocity
                    if velocity_outlier
                    else 0.75 * raw_velocity + 0.25 * position_velocity
                )
                if self.quintic_fused_velocity is None:
                    fused_velocity = measurement.copy()
                else:
                    maximum_delta = self.quintic_velocity_max_acceleration * dt
                    delta = measurement - self.quintic_fused_velocity
                    delta_norm = float(np.linalg.norm(delta))
                    if delta_norm > maximum_delta:
                        delta *= maximum_delta / delta_norm
                    bounded_measurement = self.quintic_fused_velocity + delta
                    alpha = dt / (self.quintic_velocity_filter_tau + dt)
                    fused_velocity = (
                        (1.0 - alpha) * self.quintic_fused_velocity
                        + alpha * bounded_measurement
                    )
        if not np.isfinite(fused_velocity).all():
            fused_velocity = raw_velocity.copy()
        self.quintic_previous_navigation_position = position
        self.quintic_previous_navigation_time = simulation_time
        self.quintic_fused_velocity = fused_velocity.copy()

        control_observation = dict(observation)
        control_sensors = sensors.copy()
        control_sensors[9:12] = fused_velocity
        control_observation["rocket_sensors"] = control_sensors
        return control_observation, {
            "gnss_velocity_raw": raw_velocity,
            "position_difference_velocity": position_velocity,
            "navigation_velocity_fused": fused_velocity,
            "gnss_velocity_outlier": velocity_outlier,
        }

    def _candidate_feasibility(
        self, position, velocity, coefficients, jerk, horizon, simulation_time
    ):
        """Screen the full quintic, including deceleration and direction rate."""
        gravity = np.array([0.0, 0.0, 9.81 * self.gravity_compensation])
        sample_times = np.linspace(0.0, horizon, self.trajectory_sample_count)
        previous_direction = None
        previous_time = None
        peak_thrust_ratio = peak_lateral_ratio = peak_direction_rate = 0.0
        peak_jerk = peak_speed = 0.0
        minimum_radius = np.inf
        minimum_tangential_acceleration = np.inf
        magnitude_mismatch = 0.0
        for elapsed in sample_times:
            _, sample_velocity, sample_acceleration = self._trajectory_state(
                position, velocity, coefficients, jerk, elapsed
            )
            sample_jerk = self._quintic_jerk(coefficients, elapsed)
            peak_jerk = max(peak_jerk, float(np.linalg.norm(sample_jerk)))
            if peak_jerk > self.max_trajectory_jerk + 1e-9:
                return False, "jerk", None
            available_thrust = self._future_thrust_acceleration(simulation_time + elapsed)
            if available_thrust <= 1e-9:
                return False, "burn_time", None
            requested_thrust = sample_acceleration + gravity
            required_thrust = float(np.linalg.norm(requested_thrust))
            if required_thrust <= 1e-9:
                return False, "zero_thrust_direction", None
            thrust_ratio = required_thrust / (available_thrust * self.acceleration_feasibility_margin)
            peak_thrust_ratio = max(peak_thrust_ratio, thrust_ratio)
            magnitude_mismatch += abs(required_thrust - available_thrust)
            if thrust_ratio > 1.0 + 1e-9:
                return False, "thrust", None
            sample_speed = float(np.linalg.norm(sample_velocity))
            peak_speed = max(peak_speed, sample_speed)
            tangent = _unit(sample_velocity, self.launch_direction)
            tangential_acceleration = float(np.dot(sample_acceleration, tangent))
            minimum_tangential_acceleration = min(
                minimum_tangential_acceleration, tangential_acceleration
            )
            lateral = float(np.linalg.norm(sample_acceleration - tangential_acceleration * tangent))
            available_lateral = min(
                self.max_lateral_acceleration,
                available_thrust * self.path_authority_margin,
            ) * self.acceleration_feasibility_margin
            if available_lateral <= 1e-9 or lateral > available_lateral + 1e-9:
                return False, "lateral_acceleration", None
            peak_lateral_ratio = max(peak_lateral_ratio, lateral / available_lateral)
            if sample_speed > 1e-6:
                minimum_radius = min(minimum_radius, sample_speed**2 / available_lateral)
            direction = requested_thrust / required_thrust
            if previous_direction is not None:
                direction_rate = _angle(previous_direction, direction) / max(elapsed - previous_time, 1e-9)
                peak_direction_rate = max(peak_direction_rate, direction_rate)
                if direction_rate > self._trajectory_direction_rate_limit() + 1e-9:
                    return False, "attitude_direction_rate", None
            previous_direction, previous_time = direction, elapsed
        return True, "feasible", {
            "peak_thrust_ratio": peak_thrust_ratio,
            "peak_lateral_ratio": peak_lateral_ratio,
            "peak_direction_rate": peak_direction_rate,
            "minimum_turn_radius": minimum_radius,
            "thrust_mismatch": magnitude_mismatch / len(sample_times),
            "peak_speed": peak_speed,
            "peak_jerk": peak_jerk,
            "minimum_tangential_acceleration": minimum_tangential_acceleration,
        }

    def _trajectory_candidates(
        self, position, velocity, target_index, target_position, target_velocity,
        successors, simulation_time,
    ):
        """Repair candidates by lengthening time before rejecting the target."""
        successor_options = [(None, 0.0)]
        if successors and self.terminal_direction_weight > 0.0:
            successor_options += [
                (successor, weight)
                for successor in successors
                for weight in (0.5 * self.terminal_direction_weight,)
            ]
        for speed_repair_attempt, pass_speed in enumerate(
            self._quintic_pass_speeds()
        ):
            horizons = self._quintic_horizons(
                position,
                velocity,
                target_position,
                pass_speed,
                simulation_time,
            )
            if (
                target_index == self.quintic_direct_commit_target
                and np.isfinite(self.quintic_direct_commit_deadline)
            ):
                remaining = (
                    self.quintic_direct_commit_deadline - simulation_time
                )
                horizons = horizons[horizons <= remaining + 0.02]
                if self.intercept_time_min <= remaining:
                    horizons = np.unique(np.r_[horizons, remaining])
            for repair_attempt, horizon in enumerate(horizons):
                predicted_target = target_position + target_velocity * horizon
                for successor, direction_weight in successor_options:
                    next_index = -1
                    arrival_direction = _unit(
                        predicted_target - position, self.launch_direction
                    )
                    next_direction = arrival_direction.copy()
                    if successor is not None:
                        next_index, next_position, next_velocity = successor
                        predicted_next = next_position + next_velocity * horizon
                        next_direction = _unit(
                            predicted_next - predicted_target, arrival_direction
                        )
                    terminal_direction = _unit(
                        (1.0 - direction_weight) * arrival_direction
                        + direction_weight * next_direction,
                        arrival_direction,
                    )
                    terminal_velocity = target_velocity + pass_speed * terminal_direction
                    relative_speed = float(
                        np.linalg.norm(velocity - target_velocity)
                    )
                    terminal_acceleration = self._endpoint_acceleration(
                        terminal_direction,
                        relative_speed,
                        pass_speed,
                        horizon,
                    )
                    if self.trajectory_plan is None:
                        if (
                            self.quintic_observed_popped_count
                            >= self.quintic_closed_loop_min_pops
                        ):
                            start_acceleration = self._bounded_vector(
                                self.filtered_acceleration,
                                self.quintic_max_endpoint_acceleration,
                            )
                        else:
                            start_acceleration = self._endpoint_acceleration(
                                _unit(velocity, self.launch_direction),
                                relative_speed,
                                pass_speed,
                                horizon,
                            )
                    else:
                        start_acceleration = (
                            self.quintic_last_reference_acceleration.copy()
                        )
                    coefficients = self._quintic_coefficients(
                        position,
                        velocity,
                        start_acceleration,
                        predicted_target,
                        terminal_velocity,
                        terminal_acceleration,
                        horizon,
                    )
                    initial_jerk = self._quintic_jerk(coefficients, 0.0)
                    self.trajectory_candidate_count += 1
                    feasible, reason, metrics = self._candidate_feasibility(
                        position,
                        velocity,
                        coefficients,
                        initial_jerk,
                        horizon,
                        simulation_time,
                    )
                    if not feasible:
                        self.trajectory_rejected_count += 1
                        self.trajectory_rejection_counts[reason] += 1
                        continue
                    # Feasibility alone favours very long, high arcs.  Score the
                    # *entire* candidate so the route selector can prefer an
                    # equally feasible, lower-energy continuation.
                    sample_times = np.linspace(
                        0.0, horizon, self.trajectory_sample_count
                    )
                    speeds = []
                    altitudes = []
                    curvatures = []
                    for elapsed in sample_times:
                        sample_position, sample_velocity, sample_acceleration = (
                            self._trajectory_state(
                                position,
                                velocity,
                                coefficients,
                                initial_jerk,
                                elapsed,
                            )
                        )
                        sample_speed = float(np.linalg.norm(sample_velocity))
                        tangent = _unit(sample_velocity, self.launch_direction)
                        lateral = float(
                            np.linalg.norm(
                                sample_acceleration
                                - np.dot(sample_acceleration, tangent) * tangent
                            )
                        )
                        speeds.append(sample_speed)
                        altitudes.append(float(sample_position[2]))
                        curvatures.append(
                            lateral / max(sample_speed**2, 1.0)
                        )
                    speeds = np.asarray(speeds)
                    altitudes = np.asarray(altitudes)
                    altitude_ceiling = max(
                        float(position[2]), float(predicted_target[2])
                    ) + self.energy_arc_altitude_buffer
                    altitude_excess = np.maximum(
                        altitudes - altitude_ceiling, 0.0
                    )
                    terminal_error = _angle(
                        terminal_velocity - target_velocity, next_direction
                    )
                    score = (
                        horizon
                        + self.quintic_speed_repair_penalty
                        * speed_repair_attempt
                        + 0.2 * metrics["thrust_mismatch"]
                        + 0.2 * metrics["peak_lateral_ratio"]
                        + 0.03 * metrics["peak_jerk"]
                        + self.energy_arc_trajectory_speed_weight
                        * max(
                            metrics["peak_speed"] - self.energy_arc_cruise_speed,
                            0.0,
                        )
                        ** 2
                        + self.energy_arc_trajectory_altitude_weight
                        * float(np.mean(np.square(altitude_excess)))
                        + self.energy_arc_target_curvature_weight
                        * float(np.mean(curvatures))
                    )
                    yield {
                    "score": score, "start_time": simulation_time,
                    "end_time": simulation_time + horizon, "horizon": float(horizon),
                    "start_position": position.copy(), "start_velocity": velocity.copy(),
                    "target_index": int(target_index), "next_target_index": int(next_index),
                    "target_position": target_position.copy(), "target_velocity": target_velocity.copy(),
                    "next_direction": next_direction.copy(), "acceleration": coefficients.copy(),
                    "jerk": initial_jerk.copy(), "polynomial_coefficients": coefficients.copy(),
                    "terminal_velocity": terminal_velocity.copy(),
                    "terminal_acceleration": terminal_acceleration.copy(),
                    "start_acceleration": start_acceleration.copy(),
                    "requested_terminal_speed": float(self.terminal_pass_speed),
                    "planned_terminal_speed": float(pass_speed),
                    "terminal_direction_error": terminal_error,
                    "direction_weight": direction_weight,
                    "minimum_turn_radius": metrics["minimum_turn_radius"],
                    "peak_planned_speed": metrics["peak_speed"],
                    "energy_arc_peak_altitude": float(np.max(altitudes)),
                    "energy_arc_mean_curvature": float(np.mean(curvatures)),
                    "planned_deceleration": min(metrics["minimum_tangential_acceleration"], 0.0),
                    "quintic_repair_attempt": int(repair_attempt),
                    "quintic_speed_repair_attempt": int(speed_repair_attempt),
                }

    def _full_feasibility_target(self, observation, position, velocity, simulation_time):
        """Return the lowest-score fully sampled target, or ``None``.

        This is intentionally used only after a pop or an abandoned target.
        It checks every released balloon with exactly the same quintic
        feasibility model used to commit the following plan.
        """
        status = np.asarray(observation["balloon_status"]).reshape(-1)
        states = np.asarray(observation["balloon_states"], dtype=float)
        original_plan = self.trajectory_plan
        original_acceleration = self.quintic_last_reference_acceleration.copy()
        candidates = []
        try:
            self.trajectory_plan = None
            for target_index in np.flatnonzero(status == 1):
                target_candidates = list(
                    self._trajectory_candidates(
                        position,
                        velocity,
                        int(target_index),
                        states[target_index, :3],
                        states[target_index, 3:6],
                        [],
                        simulation_time,
                    )
                )
                if target_candidates:
                    candidates.append(
                        min(target_candidates, key=lambda item: item["score"])
                    )
        finally:
            self.trajectory_plan = original_plan
            self.quintic_last_reference_acceleration = original_acceleration
        if not candidates:
            self.quintic_route_selection_diagnostics.append(
                {
                    "time": float(simulation_time),
                    "released_target_count": int(np.count_nonzero(status == 1)),
                    "feasible_target_count": 0,
                    "selected_target": -1,
                }
            )
            return None
        speed = float(np.linalg.norm(velocity))
        available = max(
            self._available_lateral_acceleration(simulation_time), 1e-9
        )
        candidate_summary = []
        closed_loop_enabled = (
            self.quintic_observed_popped_count
            >= self.quintic_closed_loop_min_pops
        )
        for candidate in candidates:
            candidate_index = int(candidate["target_index"])
            relative = states[candidate_index, :3] - position
            distance = float(np.linalg.norm(relative))
            turn_angle = _angle(velocity, relative)
            acquisition_time = (
                speed * turn_angle / available
                + self.quintic_terminal_actuator_lead_time
            )
            if closed_loop_enabled:
                surrogate = self._closed_loop_surrogate(
                    candidate,
                    position,
                    velocity,
                    states[candidate_index, :3],
                    states[candidate_index, 3:6],
                    simulation_time,
                )
            else:
                surrogate = {
                    "predicted_closest_approach": 0.0,
                    "predicted_terminal_miss": 0.0,
                    "predicted_terminal_closing_speed": np.nan,
                    "predicted_peak_direction_error": 0.0,
                    "predicted_capture_funnel": True,
                }
            candidate.update(surrogate)
            acquisition_margin = float(
                candidate["horizon"] - acquisition_time
            )
            recoverable_capture = bool(
                surrogate["predicted_capture_funnel"]
                and acquisition_margin >= 1.5
                and turn_angle <= np.deg2rad(125.0)
            )
            candidate["acquisition_margin"] = acquisition_margin
            candidate["recoverable_capture"] = recoverable_capture
            candidate["closed_loop_score"] = float(
                candidate["score"]
                + self.quintic_surrogate_miss_weight
                * surrogate["predicted_closest_approach"]
                + 0.08 * surrogate["predicted_terminal_miss"]
                + 1.5 * surrogate["predicted_peak_direction_error"]
                + 0.50 * acquisition_time
                + 8.0 * max(1.5 - acquisition_margin, 0.0)
            )
            candidate_summary.append(
                {
                    "target_index": candidate_index,
                    "score": float(candidate["score"]),
                    "closed_loop_score": candidate["closed_loop_score"],
                    "distance": distance,
                    "turn_angle": turn_angle,
                    "acquisition_time": acquisition_time,
                    "horizon": float(candidate["horizon"]),
                    "acquisition_margin": acquisition_margin,
                    "recoverable_capture": recoverable_capture,
                    **surrogate,
                }
            )
        funnel_candidates = [
            candidate for candidate in candidates
            if candidate["recoverable_capture"]
        ]
        selection_pool = (
            funnel_candidates
            if closed_loop_enabled and funnel_candidates
            else candidates
        )
        selected = min(
            selection_pool,
            key=lambda item: item["closed_loop_score"],
        )
        candidate_summary.sort(key=lambda item: item["closed_loop_score"])
        self.quintic_route_selection_diagnostics.append(
            {
                "time": float(simulation_time),
                "released_target_count": int(np.count_nonzero(status == 1)),
                "feasible_target_count": int(len(candidates)),
                "selected_target": int(selected["target_index"]),
                "selected_score": float(selected["score"]),
                "selected_closed_loop_score": float(
                    selected["closed_loop_score"]
                ),
                "selected_horizon": float(selected["horizon"]),
                "selected_pass_speed": float(selected["planned_terminal_speed"]),
                "selected_predicted_closest_approach": float(
                    selected["predicted_closest_approach"]
                ),
                "closed_loop_selection_active": closed_loop_enabled,
                "capture_funnel_candidate_count": len(funnel_candidates),
                "candidate_summary": candidate_summary,
            }
        )
        return selected

    def _trajectory_target(self, observation):
        """Keep feasible successor direction constraints for post-pop routes."""
        target = super()._trajectory_target(observation)
        if target is None or self.fixed_waypoints is not None:
            return target
        target_index, target_position, target_velocity, successors = target
        if target_index == self.quintic_direct_commit_target:
            return target_index, target_position, target_velocity, []
        return target_index, target_position, target_velocity, successors

    def _select_target(self, observation, position, velocity, simulation_time):
        """Use full candidate feasibility for every post-first-pop retarget."""
        self.quintic_capture_hold_active = False
        if (
            self.fixed_waypoints is None
            and simulation_time < self.quintic_no_route_hold_until
        ):
            self.selected_target = None
            self.trajectory_plan = None
            return position + _unit(velocity, self.launch_direction)

        previous_target = self.selected_target
        status = np.asarray(observation["balloon_status"]).reshape(-1)
        if (
            self.fixed_waypoints is None
            and self.quintic_observed_popped_count >= 1
            and previous_target == self.quintic_direct_commit_target
            and previous_target is not None
            and status[int(previous_target)] == 1
        ):
            states = np.asarray(observation["balloon_states"], dtype=float)
            relative_position = states[int(previous_target), :3] - position
            distance = float(np.linalg.norm(relative_position))
            if distance > 1e-9:
                relative_velocity = states[int(previous_target), 3:6] - velocity
                closing_speed = -float(
                    np.dot(relative_velocity, relative_position / distance)
                )
                if distance <= self.quintic_capture_hold_distance:
                    metrics = self._target_metrics(
                        int(previous_target), states, position, velocity
                    )
                    self.quintic_capture_hold_active = True
                    self.selected_target_turn_angle = metrics[2]
                    self.selected_target_distance = metrics[3]
                    self.selected_target_required_lateral_acceleration = metrics[4]
                    self.selected_target_relative_position = relative_position
                    self.selected_target_relative_velocity = relative_velocity
                    self.raw_guidance_turn_angle = metrics[2]
                    self.virtual_waypoint = metrics[1].copy()
                    self.path_virtual_waypoint = metrics[1].copy()
                    return metrics[1]
        previously_released = (
            previous_target is not None and status[int(previous_target)] != 1
        )
        has_popped_balloon = bool(np.any(status == 2))
        guidance_point = super()._select_target(
            observation, position, velocity, simulation_time
        )
        inherited_target = self.selected_target
        retargeted = (
            previous_target is not None
            and inherited_target is not None
            and inherited_target != previous_target
        )
        if (
            self.fixed_waypoints is not None
            or not has_popped_balloon
            or not (previously_released or retargeted)
        ):
            return guidance_point

        selected = self._full_feasibility_target(
            observation, position, velocity, simulation_time
        )
        if selected is None:
            self.selected_target = None
            self.trajectory_plan = None
            self.quintic_no_route_hold_until = (
                simulation_time + self.quintic_no_route_hold_period
            )
            return position + _unit(velocity, self.launch_direction)

        target_index = int(selected["target_index"])
        if target_index != inherited_target:
            if self.target_history and self.target_history[-1] == inherited_target:
                self.target_history[-1] = target_index
            else:
                self.target_history.append(target_index)
            self.selected_target_time = simulation_time
            self.last_target_selection_time = simulation_time
        self.selected_target = target_index
        self.trajectory_plan = None
        self.trajectory_committed_successor = None
        self.trajectory_successor_source_target = None
        self.quintic_direct_commit_target = target_index
        self.quintic_direct_commit_deadline = np.nan
        states = np.asarray(observation["balloon_states"], dtype=float)
        metrics = self._target_metrics(target_index, states, position, velocity)
        self.selected_target_turn_angle = metrics[2]
        self.selected_target_distance = metrics[3]
        self.selected_target_required_lateral_acceleration = metrics[4]
        self.selected_target_relative_position = states[target_index, :3] - position
        self.selected_target_relative_velocity = states[target_index, 3:6] - velocity
        self.raw_guidance_turn_angle = metrics[2]
        self.virtual_waypoint = metrics[1].copy()
        self.path_virtual_waypoint = metrics[1].copy()
        return metrics[1]

    def _plan_trajectory(self, observation, position, velocity, simulation_time):
        """Commit only feasible plans and defer failed searches between retries."""
        self.quintic_replan_flag = False
        if self.quintic_event_replan_pending:
            self.trajectory_plan = None
            self.quintic_direct_commit_deadline = np.nan
            self.quintic_event_replan_pending = False
            self.quintic_event_replan_count += 1
            self.quintic_replan_reason = "tracking_tube_exit"
        elif (
            self.trajectory_plan is not None
            and self.quintic_observed_popped_count
            >= self.quintic_closed_loop_min_pops
            and self.trajectory_plan["target_index"] == self.selected_target
            and self.quintic_virtual_elapsed
            < self.trajectory_plan["horizon"] - 1e-6
        ):
            # Periodic replanning would hide closed-loop tracking error.  Hold
            # this segment inside its robust tube and let only an event trigger
            # replace it.  Its deadline follows virtual, not wall-clock, time.
            virtual_remaining = (
                self.trajectory_plan["horizon"]
                - self.quintic_virtual_elapsed
            )
            self.trajectory_plan["end_time"] = max(
                self.trajectory_plan["end_time"],
                simulation_time + virtual_remaining,
            )
            self.trajectory_last_plan_time = simulation_time
        if (
            self.trajectory_plan is None
            and simulation_time < self.quintic_next_retry_time
        ):
            self.quintic_replan_reason = "failed_plan_retry_deferred"
            return
        if (
            self.selected_target == self.quintic_direct_commit_target
            and np.isfinite(self.quintic_direct_commit_deadline)
            and simulation_time >= self.quintic_direct_commit_deadline
        ):
            # The first fixed-time segment has ended.  A capture-hold target
            # may now be replanned from the measured state rather than dropped.
            self.quintic_direct_commit_deadline = np.nan
        previous_plan = self.trajectory_plan
        candidates_before = self.trajectory_candidate_count
        rejected_before = self.trajectory_rejected_count
        super()._plan_trajectory(observation, position, velocity, simulation_time)
        if (
            self.trajectory_plan is not None
            and self.trajectory_plan["target_index"]
            == self.quintic_direct_commit_target
            and not np.isfinite(self.quintic_direct_commit_deadline)
        ):
            self.quintic_direct_commit_deadline = self.trajectory_plan[
                "end_time"
            ]
        if self.trajectory_plan is not self._quintic_last_plan_object:
            self._quintic_last_plan_object = self.trajectory_plan
            if self.trajectory_plan is not None:
                self.quintic_trajectory_plan_id += 1
        self.quintic_replan_flag = self.trajectory_plan is not previous_plan
        if self.trajectory_plan is None:
            self.quintic_next_retry_time = (
                simulation_time + self.quintic_failed_replan_period
            )
            self.quintic_replan_reason = (
                self.trajectory_rejection_counts.most_common(1)[0][0]
                if self.trajectory_rejected_count > rejected_before
                else "no_released_target"
            )
        elif self.quintic_replan_flag:
            self.quintic_next_retry_time = -np.inf
            self.quintic_replan_reason = "committed_feasible_plan"
        elif self.trajectory_candidate_count == candidates_before:
            self.quintic_replan_reason = "committed_plan_held"

    def _measured_aero_force_feedforward(self, velocity):
        """Invert the validated body-frame drag model inside its test range."""
        if self.quintic_observed_popped_count < 1:
            return np.zeros(3)
        speed = float(np.linalg.norm(velocity))
        if not 31.0 <= speed <= 49.0:
            return np.zeros(3)
        body_velocity = _rotate_inertial_to_body(self.attitude, velocity)
        body_direction = body_velocity / max(speed, 1e-9)
        aoa = float(np.arccos(np.clip(body_direction[2], -1.0, 1.0)))
        if aoa > np.deg2rad(45.0):
            return np.zeros(3)
        flow = -speed * body_velocity
        # Measurement-only experiment, Scenario 1, 31--49 m/s:
        # axial R^2=0.935, normal R^2=0.901.  Biases are deliberately
        # omitted: they are not aerodynamic and would be unsafe to invert.
        aerodynamic_body = np.array(
            [0.006820778357361975 * flow[0],
             0.006820778357361975 * flow[1],
             0.0002047811190869102 * flow[2]]
        )
        feedforward = -self.quintic_aero_force_gain * _rotate_body_to_inertial(
            self.attitude, aerodynamic_body
        )
        magnitude = float(np.linalg.norm(feedforward))
        if magnitude > self.quintic_aero_force_limit:
            feedforward *= self.quintic_aero_force_limit / magnitude
        return feedforward

    def _measured_aero_moment_feedforward(self, velocity, gyro):
        """Counter measured AoA/restoring moment with bounded TVC feed-forward."""
        if self.quintic_observed_popped_count < 1:
            return np.zeros(2)
        speed = float(np.linalg.norm(velocity))
        if not 31.0 <= speed <= 46.0:
            return np.zeros(2)
        body_velocity = _rotate_inertial_to_body(self.attitude, velocity)
        body_direction = body_velocity / max(speed, 1e-9)
        aoa_vector = np.cross(np.array([0.0, 0.0, 1.0]), body_direction)
        aoa = float(np.arccos(np.clip(body_direction[2], -1.0, 1.0)))
        if aoa > np.deg2rad(45.0):
            return np.zeros(2)
        aero_feature = speed**2 * aoa_vector[:2]
        damping_feature = speed * np.asarray(gyro[:2], dtype=float)
        # gyro_dot = k_tvc*tvc_deg + k_aero*feature + k_damping*feature + bias
        predicted_moment = np.array(
            [
                0.0015945957882233274 * aero_feature[0]
                - 0.009523229150627754 * damping_feature[0]
                + 0.19897580745843782,
                0.0015051771511973558 * aero_feature[1]
                - 0.0062459279506991115 * damping_feature[1]
                - 0.1648136424059918,
            ]
        )
        feedforward = -self.quintic_aero_moment_gain * predicted_moment / np.array(
            [0.39822412347805863, 0.37100703654866446]
        )
        return np.clip(
            feedforward,
            -self.quintic_aero_moment_limit,
            self.quintic_aero_moment_limit,
        )

    def _acceleration_aware_time_to_go(
        self,
        position,
        velocity,
        target_position,
        target_velocity,
        simulation_time,
        observed_closing_speed,
    ):
        """Solve a bounded observation-only closing-time quadratic."""
        position = np.asarray(position, dtype=float)
        velocity = np.asarray(velocity, dtype=float)
        target_position = np.asarray(target_position, dtype=float)
        target_velocity = np.asarray(target_velocity, dtype=float)
        relative_velocity = target_velocity - velocity
        available_thrust = self._future_thrust_acceleration(simulation_time)
        closing_acceleration = max(
            available_thrust - 9.81 * self.gravity_compensation,
            0.5,
        )
        initial_relative = target_position - position
        initial_distance = float(np.linalg.norm(initial_relative))
        initial_los = _unit(initial_relative, self.launch_direction)
        kinematic_closing = -float(np.dot(relative_velocity, initial_los))
        fused_closing = max(kinematic_closing, observed_closing_speed)
        time_to_go = initial_distance / max(fused_closing, 1.0)
        maximum_time = self.quintic_terminal_time_max
        if np.isfinite(self.actual_launch_time):
            remaining_burn = (
                self.actual_launch_time + self.burn_time - simulation_time
            )
            maximum_time = min(maximum_time, max(remaining_burn, 0.0))
        maximum_time = max(maximum_time, self.quintic_terminal_time_min)
        time_to_go = float(
            np.clip(
                time_to_go,
                self.quintic_terminal_time_min,
                maximum_time,
            )
        )
        for _ in range(3):
            predicted_target = target_position + target_velocity * time_to_go
            relative = predicted_target - position
            distance = float(np.linalg.norm(relative))
            if distance <= 1e-9:
                time_to_go = self.quintic_terminal_time_min
                break
            los = relative / distance
            kinematic_closing = -float(np.dot(relative_velocity, los))
            fused_closing = max(kinematic_closing, observed_closing_speed)
            discriminant = (
                fused_closing**2
                + 2.0 * closing_acceleration * distance
            )
            candidate = (
                (-fused_closing + np.sqrt(discriminant)) / closing_acceleration
                if discriminant >= 0.0 and closing_acceleration > 1e-9
                else distance / max(fused_closing, 1.0)
            )
            if not np.isfinite(candidate) or candidate <= 0.0:
                candidate = distance / max(fused_closing, 1.0)
            time_to_go = float(
                np.clip(
                    candidate,
                    self.quintic_terminal_time_min,
                    maximum_time,
                )
            )
        return time_to_go, closing_acceleration, kinematic_closing

    def _terminal_intercept_handoff(
        self, observation, position, velocity, simulation_time, plan
    ):
        """Replace path-normal guidance with bounded PN/ZEM near the target."""
        self.quintic_terminal_intercept_active = False
        zero = np.zeros(3)
        telemetry = {
            "quintic_terminal_intercept_active": False,
            "quintic_terminal_target_distance": np.nan,
            "quintic_terminal_activation_distance": np.nan,
            "quintic_terminal_closing_speed": np.nan,
            "quintic_terminal_time_to_go": np.nan,
            "quintic_terminal_cpa_time_to_go": np.nan,
            "quintic_terminal_closing_acceleration": np.nan,
            "quintic_terminal_tgo_kinematic_closing": np.nan,
            "quintic_terminal_zem_weight": 0.0,
            "quintic_terminal_handoff_weight": 0.0,
            "quintic_terminal_los_rate": zero.copy(),
            "quintic_terminal_pn_acceleration": zero.copy(),
            "quintic_terminal_zem": zero.copy(),
            "quintic_terminal_zem_acceleration": zero.copy(),
            "quintic_terminal_base_lateral_acceleration": zero.copy(),
            "quintic_terminal_raw_intercept_acceleration": zero.copy(),
            "quintic_terminal_acceleration_derivative": zero.copy(),
            "quintic_terminal_intercept_acceleration": zero.copy(),
            "quintic_terminal_longitudinal_acceleration": 0.0,
            "quintic_terminal_available_acceleration": 0.0,
        }
        status = np.asarray(observation["balloon_status"]).reshape(-1)
        target_index = int(plan["target_index"])
        if (
            self.quintic_observed_popped_count < 1
            or target_index < 0
            or target_index >= status.size
            or status[target_index] != 1
        ):
            self.quintic_terminal_previous_acceleration = None
            self.quintic_terminal_previous_time = None
            self.quintic_terminal_previous_target = None
            self.quintic_terminal_filtered_acceleration_derivative[:] = 0.0
            self.trajectory_snapshot.update(telemetry)
            return position + np.asarray(
                self.trajectory_snapshot["desired_thrust_direction"], dtype=float
            )

        elapsed = max(simulation_time - plan["start_time"], 0.0)
        observed_states = np.asarray(observation["balloon_states"], dtype=float)
        target_position = observed_states[target_index, :3].copy()
        relative_position = target_position - position
        distance = float(np.linalg.norm(relative_position))
        telemetry["quintic_terminal_target_distance"] = distance
        activation_distance = (
            self.quintic_terminal_recovery_distance
            if self.quintic_observed_popped_count >= 2
            else self.quintic_terminal_intercept_distance
        )
        telemetry["quintic_terminal_activation_distance"] = activation_distance
        if not 1e-9 < distance <= activation_distance:
            self.quintic_terminal_previous_acceleration = None
            self.quintic_terminal_previous_time = None
            self.quintic_terminal_previous_target = None
            self.quintic_terminal_filtered_acceleration_derivative[:] = 0.0
            self.trajectory_snapshot.update(telemetry)
            return position + np.asarray(
                self.trajectory_snapshot["desired_thrust_direction"], dtype=float
            )

        target_velocity = observed_states[target_index, 3:6].copy()
        relative_velocity = target_velocity - velocity
        state_prediction_lead = float(
            plan.get("terminal_state_prediction_lead", 0.0)
        )
        if state_prediction_lead > 0.0:
            relative_position = (
                relative_position
                + relative_velocity * state_prediction_lead
                - 0.5
                * self.filtered_acceleration
                * state_prediction_lead**2
            )
            relative_velocity = (
                relative_velocity
                - self.filtered_acceleration * state_prediction_lead
            )
            distance = float(np.linalg.norm(relative_position))
            los = _unit(relative_position, self.launch_direction)
        los = relative_position / distance
        closing_speed = -float(np.dot(relative_velocity, los))
        closing_speed = max(
            closing_speed,
            float(plan.get("terminal_observed_closing_speed", -np.inf)),
        )
        los_rate = np.cross(relative_position, relative_velocity) / max(
            distance**2, 1e-9
        )
        navigation_constant = float(
            plan.get(
                "terminal_navigation_constant",
                self.quintic_terminal_navigation_constant,
            )
        )
        zem_gain = float(
            plan.get("terminal_zem_gain", self.quintic_terminal_zem_gain)
        )
        pn_acceleration = (
            navigation_constant
            * max(closing_speed, 0.0)
            * np.cross(los_rate, los)
        )

        closing_acceleration = np.nan
        tgo_kinematic_closing = closing_speed
        cpa_time_to_go = np.nan
        if self.quintic_observed_popped_count >= self.quintic_closed_loop_min_pops:
            (
                time_to_go,
                closing_acceleration,
                tgo_kinematic_closing,
            ) = self._acceleration_aware_time_to_go(
                position,
                velocity,
                target_position,
                target_velocity,
                simulation_time,
                closing_speed,
            )
            relative_speed_squared = float(
                np.dot(relative_velocity, relative_velocity)
            )
            if relative_speed_squared > 1e-9:
                cpa_time_to_go = -float(
                    np.dot(relative_position, relative_velocity)
                ) / relative_speed_squared
                if cpa_time_to_go > 0.0:
                    cpa_time_to_go = float(
                        np.clip(
                            cpa_time_to_go,
                            self.quintic_terminal_cpa_time_min,
                            self.quintic_terminal_time_max,
                        )
                    )
                    time_to_go = min(time_to_go, cpa_time_to_go)
        else:
            time_to_go_speed = (
                closing_speed
                if closing_speed > 1e-6
                else float(np.linalg.norm(relative_velocity))
            )
            time_to_go = distance / max(time_to_go_speed, 1e-6)
            time_to_go = float(
                np.clip(
                    time_to_go,
                    self.quintic_terminal_time_min,
                    self.quintic_terminal_time_max,
                )
            )
        zem = relative_position + relative_velocity * time_to_go
        zem_acceleration = (
            zem_gain * 2.0 * zem / time_to_go**2
        )
        zem_weight = float(
            np.clip(
                1.0 - distance / activation_distance,
                0.0,
                1.0,
            )
        )
        terminal_direction = _unit(plan["terminal_velocity"], los)
        tangent = _unit(velocity, terminal_direction)
        intercept_acceleration = (
            (1.0 - zem_weight) * pn_acceleration
            + zem_weight * zem_acceleration
        )
        raw_longitudinal_acceleration = float(
            np.dot(intercept_acceleration, tangent)
        )
        longitudinal_limit = float(
            plan.get("terminal_longitudinal_limit", 0.0)
        )
        longitudinal_gain = float(
            plan.get("terminal_longitudinal_gain", 1.0)
        )
        longitudinal_acceleration = float(
            np.clip(
                longitudinal_gain * raw_longitudinal_acceleration,
                -longitudinal_limit,
                longitudinal_limit,
            )
        )
        intercept_acceleration += (
            longitudinal_acceleration - raw_longitudinal_acceleration
        ) * tangent
        raw_intercept_acceleration = intercept_acceleration.copy()
        if (
            self.quintic_terminal_previous_acceleration is not None
            and self.quintic_terminal_previous_time is not None
            and self.quintic_terminal_previous_target == target_index
        ):
            derivative_dt = simulation_time - self.quintic_terminal_previous_time
            if 1e-4 < derivative_dt <= 0.1:
                raw_derivative = (
                    raw_intercept_acceleration
                    - self.quintic_terminal_previous_acceleration
                ) / derivative_dt
                derivative_alpha = derivative_dt / (
                    self.quintic_terminal_derivative_filter_tau + derivative_dt
                )
                self.quintic_terminal_filtered_acceleration_derivative += (
                    derivative_alpha
                    * (
                        raw_derivative
                        - self.quintic_terminal_filtered_acceleration_derivative
                    )
                )
                lead_time = (
                    self.quintic_terminal_recovery_lead_time
                    if self.quintic_observed_popped_count >= 2
                    else self.quintic_terminal_actuator_lead_time
                )
                intercept_acceleration += (
                    lead_time
                    * self.quintic_terminal_filtered_acceleration_derivative
                )
        else:
            self.quintic_terminal_filtered_acceleration_derivative[:] = 0.0
        self.quintic_terminal_previous_acceleration = (
            raw_intercept_acceleration.copy()
        )
        self.quintic_terminal_previous_time = simulation_time
        self.quintic_terminal_previous_target = target_index

        desired_direction = np.asarray(
            self.trajectory_snapshot["desired_thrust_direction"], dtype=float
        )
        required = float(
            self.trajectory_snapshot["required_thrust_acceleration"]
        )
        base_thrust = required * desired_direction
        gravity = np.array([0.0, 0.0, 9.81 * self.gravity_compensation])
        drag_compensation = np.asarray(
            self.energy_arc_snapshot.get(
                "energy_arc_drag_compensation", np.zeros(3)
            ),
            dtype=float,
        )
        base_net_acceleration = base_thrust - gravity - drag_compensation
        base_lateral_acceleration = base_net_acceleration - float(
            np.dot(base_net_acceleration, tangent)
        ) * tangent
        available = self._available_lateral_acceleration(simulation_time)
        intercept_norm = float(np.linalg.norm(intercept_acceleration))
        if intercept_norm > available:
            intercept_acceleration *= available / max(intercept_norm, 1e-9)
        tangential_acceleration = float(
            np.dot(base_net_acceleration, tangent)
        ) * tangent
        terminal_thrust = (
            tangential_acceleration
            + intercept_acceleration
            + gravity
            + drag_compensation
            + np.asarray(
                plan.get(
                    "terminal_disturbance_compensation", np.zeros(3)
                ),
                dtype=float,
            )
        )
        terminal_required = float(np.linalg.norm(terminal_thrust))
        terminal_direction = _unit(terminal_thrust, desired_direction)
        full_thrust = self._full_thrust_acceleration(simulation_time)
        if full_thrust > 1e-9:
            self.throttle_command = float(
                np.clip(
                    self.throttle_command
                    + (terminal_required - required) / full_thrust,
                    self.throttle_min,
                    self.throttle_max,
                )
            )

        self.quintic_terminal_intercept_active = True
        self.planned_lateral_acceleration = float(
            np.linalg.norm(intercept_acceleration)
        )
        self.virtual_waypoint = position + terminal_direction
        self.path_virtual_waypoint = self.virtual_waypoint.copy()
        self.trajectory_snapshot["desired_thrust_direction"] = (
            terminal_direction.copy()
        )
        self.trajectory_snapshot["required_thrust_acceleration"] = (
            terminal_required
        )
        telemetry.update(
            {
                "quintic_terminal_intercept_active": True,
                "quintic_terminal_closing_speed": closing_speed,
                "quintic_terminal_time_to_go": time_to_go,
                "quintic_terminal_cpa_time_to_go": cpa_time_to_go,
                "quintic_terminal_closing_acceleration": closing_acceleration,
                "quintic_terminal_tgo_kinematic_closing": (
                    tgo_kinematic_closing
                ),
                "quintic_terminal_zem_weight": zem_weight,
                "quintic_terminal_handoff_weight": 1.0,
                "quintic_terminal_los_rate": los_rate.copy(),
                "quintic_terminal_pn_acceleration": pn_acceleration.copy(),
                "quintic_terminal_zem": zem.copy(),
                "quintic_terminal_zem_acceleration": zem_acceleration.copy(),
                "quintic_terminal_base_lateral_acceleration": (
                    base_lateral_acceleration.copy()
                ),
                "quintic_terminal_raw_intercept_acceleration": (
                    raw_intercept_acceleration.copy()
                ),
                "quintic_terminal_acceleration_derivative": (
                    self.quintic_terminal_filtered_acceleration_derivative.copy()
                ),
                "quintic_terminal_intercept_acceleration": (
                    intercept_acceleration.copy()
                ),
                "quintic_terminal_available_acceleration": available,
                "quintic_terminal_longitudinal_acceleration": (
                    longitudinal_acceleration
                ),
                "quintic_terminal_disturbance_compensation": np.asarray(
                    plan.get(
                        "terminal_disturbance_compensation", np.zeros(3)
                    ),
                    dtype=float,
                ).copy(),
            }
        )
        self.trajectory_snapshot.update(telemetry)
        return self.virtual_waypoint.copy()

    def _pid_command(self, desired_rate, gyro, dt, gain_scale):
        command, error = super()._pid_command(
            desired_rate, gyro, dt, gain_scale
        )
        command[:2] += self.quintic_aero_moment_feedforward
        limits = np.array([self.max_gimbal, self.max_gimbal, self.max_roll])
        return np.clip(command, -limits, limits), error

    def _disturbance_and_indi_correction(
        self, nominal_acceleration, simulation_time
    ):
        """Return bounded incremental acceleration feedback from observations."""
        nominal_acceleration = np.asarray(nominal_acceleration, dtype=float)
        dt = (
            max(simulation_time - self.previous_time, 0.0)
            if self.previous_time is not None
            else 0.0
        )
        freeze = self.quintic_governor_saturated
        if (
            self.quintic_previous_predicted_acceleration is not None
            and dt > 1e-6
            and not freeze
            and np.isfinite(self.filtered_acceleration).all()
        ):
            innovation = (
                self.filtered_acceleration
                - self.quintic_previous_predicted_acceleration
            )
            alpha = dt / (self.quintic_disturbance_filter_tau + dt)
            self.quintic_disturbance_estimate += alpha * (
                innovation - self.quintic_disturbance_estimate
            )
            self.quintic_disturbance_estimate = self._bounded_vector(
                self.quintic_disturbance_estimate,
                self.quintic_disturbance_limit,
            )
        incremental_error = self._bounded_vector(
            nominal_acceleration - self.filtered_acceleration,
            self.quintic_indi_limit,
        )
        indi_correction = self.quintic_indi_gain * incremental_error
        correction = indi_correction - self.quintic_disturbance_estimate
        self.quintic_previous_predicted_acceleration = (
            nominal_acceleration + correction
        )
        return correction, indi_correction

    def _rate_limited_throttle(
        self, required_thrust, simulation_time, requested_throttle=None
    ):
        """Apply one final throttle saturation/rate limit after all feed-forward."""
        full_thrust = self._full_thrust_acceleration(simulation_time)
        requested = requested_throttle
        if requested is None:
            requested = (
                required_thrust / max(full_thrust, 1e-9)
                if full_thrust > 1e-9
                else self.throttle_min
            )
        requested = float(
            np.clip(requested, self.throttle_min, self.throttle_max)
        )
        dt = (
            max(simulation_time - self.previous_time, 0.0)
            if self.previous_time is not None
            else 0.0
        )
        maximum_delta = float(
            self.given_parameters["rocket"]["control"]["throttle_rate_limit"]
        ) * dt
        if dt > 0.0:
            requested = float(
                np.clip(
                    requested,
                    self.quintic_previous_throttle_output
                    - 0.999 * maximum_delta,
                    self.quintic_previous_throttle_output
                    + 0.999 * maximum_delta,
                )
            )
        requested = float(
            np.clip(requested, self.throttle_min, self.throttle_max)
        )
        self.quintic_previous_throttle_output = requested
        self.energy_arc_previous_throttle = requested
        self.throttle_command = requested
        return requested

    def _allocation_shadow(self, simulation_time, inherited_throttle):
        """Observe final-vector/throttle ownership mismatch without changing action."""
        direction = np.asarray(
            self.trajectory_snapshot.get(
                "desired_thrust_direction", self.launch_direction
            ),
            dtype=float,
        )
        required = float(
            self.trajectory_snapshot.get("required_thrust_acceleration", np.nan)
        )
        full_thrust = self._full_thrust_acceleration(simulation_time)
        vector = required * direction
        target = (
            required / full_thrust
            if np.isfinite(required) and full_thrust > 1e-9
            else np.nan
        )
        return {
            "quintic_owner_shadow_final_thrust_vector": vector.copy(),
            "quintic_owner_shadow_required_thrust": required,
            "quintic_owner_shadow_throttle_target": target,
            "quintic_owner_shadow_inherited_throttle": float(inherited_throttle),
            "quintic_owner_shadow_commanded_throttle": float(
                self.throttle_command
            ),
            "quintic_owner_shadow_throttle_mismatch": (
                float(self.throttle_command - target)
                if np.isfinite(target)
                else np.nan
            ),
            "quintic_owner_shadow_finite": bool(
                np.isfinite(vector).all() and np.isfinite(target)
            ),
        }

    def _closed_loop_midcourse_guidance(
        self, plan, position, velocity, simulation_time
    ):
        """Track governed quintic state with disturbance/INDI compensation."""
        reference, governor = self._governed_reference(
            plan, position, velocity, simulation_time
        )
        reference_position, reference_velocity, reference_acceleration = reference
        acceleration_command = (
            reference_acceleration
            + self.trajectory_tracking_position_kp
            * (reference_position - position)
            + self.trajectory_tracking_velocity_kp
            * (reference_velocity - velocity)
        )
        speed = float(np.linalg.norm(velocity))
        tangent = _unit(velocity, self.launch_direction)
        tangential = float(np.dot(acceleration_command, tangent)) * tangent
        available_lateral = self._available_lateral_acceleration(simulation_time)
        lateral = self._bounded_vector(
            acceleration_command - tangential, available_lateral
        )
        nominal_acceleration = tangential + lateral
        correction, indi_correction = self._disturbance_and_indi_correction(
            nominal_acceleration, simulation_time
        )
        gravity = np.array([0.0, 0.0, 9.81 * self.gravity_compensation])
        drag_compensation = self._drag_compensation(velocity)
        thrust_request = (
            nominal_acceleration + correction + gravity + drag_compensation
        )
        available_thrust = self._future_thrust_acceleration(simulation_time)
        required_thrust = float(np.linalg.norm(thrust_request))
        thrust_projected = required_thrust > available_thrust > 1e-9
        if thrust_projected:
            thrust_request *= available_thrust / required_thrust
            required_thrust = available_thrust
        direction = _unit(
            thrust_request,
            self.trajectory_snapshot.get(
                "desired_thrust_direction", self.launch_direction
            ),
        )
        self.quintic_governor_saturated = bool(
            self.quintic_governor_saturated or thrust_projected
        )
        hard_error = bool(
            governor["quintic_governor_position_error"]
            > self.quintic_replan_position_error
            or governor["quintic_governor_velocity_error"]
            > self.quintic_replan_velocity_error
            or (
                governor["quintic_governor_time_lag"]
                >= 0.98 * self.quintic_governor_lag_limit
                and governor["quintic_governor_position_error"]
                > self.quintic_governor_position_soft
            )
        )
        if hard_error:
            if self.quintic_tracking_error_since is None:
                self.quintic_tracking_error_since = simulation_time
            elif (
                simulation_time - self.quintic_tracking_error_since
                >= self.quintic_replan_error_hold
            ):
                self.quintic_event_replan_pending = True
        else:
            self.quintic_tracking_error_since = None
        self.quintic_last_reference_acceleration = reference_acceleration.copy()
        self.planned_lateral_acceleration = float(np.linalg.norm(lateral))
        self.virtual_waypoint = position + direction
        self.path_virtual_waypoint = self.virtual_waypoint.copy()
        self.trajectory_snapshot.update(
            {
                "reference_position": reference_position.copy(),
                "reference_velocity": reference_velocity.copy(),
                "reference_acceleration": reference_acceleration.copy(),
                "reference_jerk": self._quintic_jerk(
                    plan["polynomial_coefficients"],
                    self.quintic_virtual_elapsed,
                ),
                "position_tracking_error": (
                    position - reference_position
                ).copy(),
                "velocity_tracking_error": (
                    velocity - reference_velocity
                ).copy(),
                "desired_thrust_direction": direction.copy(),
                "required_thrust_acceleration": required_thrust,
                "trajectory_required_lateral_acceleration": float(
                    np.linalg.norm(lateral)
                ),
                "trajectory_available_lateral_acceleration": available_lateral,
                "trajectory_thrust_projected": thrust_projected,
                "quintic_disturbance_estimate": (
                    self.quintic_disturbance_estimate.copy()
                ),
                "quintic_indi_correction": indi_correction.copy(),
                "quintic_acceleration_correction": correction.copy(),
                "quintic_event_replan_pending": (
                    self.quintic_event_replan_pending
                ),
                "quintic_event_replan_count": self.quintic_event_replan_count,
                **governor,
            }
        )
        return self.virtual_waypoint.copy()

    def _acceleration_guidance_point(
        self, observation, position, velocity, simulation_time
    ):
        guidance_point = super()._acceleration_guidance_point(
            observation, position, velocity, simulation_time
        )
        inherited_throttle = float(self.throttle_command)
        plan = self.trajectory_plan
        if plan is None or "polynomial_coefficients" not in plan:
            self.trajectory_snapshot.update(
                {
                    "trajectory_plan_id": -1,
                    "trajectory_replan_flag": self.quintic_replan_flag,
                    "trajectory_replan_reason": self.quintic_replan_reason,
                    "trajectory_next_retry_time": self.quintic_next_retry_time,
                }
            )
            status = np.asarray(observation["balloon_status"]).reshape(-1)
            target_index = (
                -1 if self.selected_target is None else int(self.selected_target)
            )
            if (
                self.quintic_observed_popped_count
                >= self.quintic_closed_loop_min_pops
                and self.quintic_planless_terminal_enabled
                and 0 <= target_index < status.size
                and status[target_index] == 1
            ):
                states = np.asarray(observation["balloon_states"], dtype=float)
                target_position = states[target_index, :3]
                target_velocity = states[target_index, 3:6]
                relative = target_position - position
                los = _unit(relative, self.launch_direction)
                distance = float(np.linalg.norm(relative))
                closing_speed = -float(
                    np.dot(target_velocity - velocity, los)
                )
                distance_closing_speed = -np.inf
                if (
                    self.quintic_capture_previous_target == target_index
                    and self.quintic_capture_previous_distance is not None
                    and self.quintic_capture_previous_time is not None
                    and simulation_time
                    > self.quintic_capture_previous_time + 1e-9
                ):
                    distance_closing_speed = (
                        self.quintic_capture_previous_distance - distance
                    ) / (
                        simulation_time - self.quintic_capture_previous_time
                    )
                self.quintic_capture_previous_target = target_index
                self.quintic_capture_previous_distance = distance
                self.quintic_capture_previous_time = simulation_time
                capture_closing_speed = max(
                    closing_speed, distance_closing_speed
                )
                if (
                    distance > self.quintic_planless_terminal_distance
                    or capture_closing_speed
                    < self.quintic_planless_terminal_closing_speed
                ):
                    return guidance_point
                energy_direction = np.asarray(
                    self.energy_arc_snapshot.get(
                        "desired_thrust_direction", self.launch_direction
                    ),
                    dtype=float,
                )
                energy_required = float(
                    self.energy_arc_snapshot.get(
                        "required_thrust_acceleration",
                        self._future_thrust_acceleration(simulation_time),
                    )
                )
                self.trajectory_snapshot.update(
                    {
                        "desired_thrust_direction": energy_direction.copy(),
                        "required_thrust_acceleration": energy_required,
                    }
                )
                capture_plan = {
                    "target_index": target_index,
                    "start_time": simulation_time,
                    "target_position": target_position.copy(),
                    "target_velocity": target_velocity.copy(),
                    "terminal_velocity": (
                        target_velocity
                        + self.quintic_planless_pass_speed * los
                    ),
                    "terminal_zem_gain": self.quintic_planless_zem_gain,
                    "terminal_navigation_constant": (
                        self.quintic_planless_navigation_constant
                    ),
                    "terminal_observed_closing_speed": capture_closing_speed,
                    "terminal_state_prediction_lead": (
                        self.quintic_planless_state_prediction_lead
                    ),
                    "terminal_longitudinal_limit": (
                        self.quintic_planless_longitudinal_limit
                    ),
                    "terminal_longitudinal_gain": (
                        self.quintic_planless_longitudinal_gain
                    ),
                    "terminal_disturbance_compensation": (
                        -self.quintic_planless_disturbance_gain
                        * self.quintic_disturbance_estimate
                    ),
                }
                guidance_point = self._terminal_intercept_handoff(
                    observation,
                    position,
                    velocity,
                    simulation_time,
                    capture_plan,
                )
                self.quintic_aero_moment_feedforward = (
                    self._measured_aero_moment_feedforward(
                        velocity, self.previous_gyro
                    )
                )
                if self.quintic_terminal_intercept_active:
                    self.throttle_command = max(
                        self.throttle_command,
                        self.quintic_planless_throttle_floor,
                    )
                    final_required = float(
                        self.trajectory_snapshot[
                            "required_thrust_acceleration"
                        ]
                    )
                    self._rate_limited_throttle(
                        final_required,
                        simulation_time,
                        requested_throttle=self.throttle_command,
                    )
                    self.energy_arc_snapshot[
                        "energy_arc_guidance_mode"
                    ] = "terminal_pn_zem_capture_funnel"
                    self.trajectory_snapshot.update(
                        {
                            "quintic_closed_loop_active": True,
                            "quintic_capture_funnel_without_plan": True,
                            "quintic_capture_funnel_closing_speed": (
                                capture_closing_speed
                            ),
                            "quintic_aero_moment_feedforward": (
                                self.quintic_aero_moment_feedforward.copy()
                            ),
                        }
                    )
                    self.trajectory_snapshot.update(
                        self._allocation_shadow(
                            simulation_time, inherited_throttle
                        )
                    )
                    return guidance_point
            return guidance_point
        elapsed = float(np.clip(
            simulation_time - plan["start_time"], 0.0, plan["horizon"]
        ))
        reference_position, reference_velocity, reference_acceleration = (
            self._trajectory_state(
                plan["start_position"], plan["start_velocity"],
                plan["acceleration"], plan["jerk"], elapsed,
            )
        )
        reference_jerk = self._quintic_jerk(plan["polynomial_coefficients"], elapsed)
        self.quintic_last_reference_acceleration = reference_acceleration.copy()
        self.trajectory_snapshot.update(
            {
                "trajectory_plan_id": self.quintic_trajectory_plan_id,
                "trajectory_start_time": float(plan["start_time"]),
                "trajectory_replan_flag": self.quintic_replan_flag,
                "trajectory_replan_reason": self.quintic_replan_reason,
                "trajectory_next_retry_time": self.quintic_next_retry_time,
                "trajectory_polynomial_coefficients": plan[
                    "polynomial_coefficients"
                ].copy(),
                "reference_position": reference_position.copy(),
                "reference_velocity": reference_velocity.copy(),
                "reference_acceleration": reference_acceleration.copy(),
                "reference_jerk": reference_jerk.copy(),
                "position_tracking_error": (position - reference_position).copy(),
                "velocity_tracking_error": (velocity - reference_velocity).copy(),
                "requested_terminal_speed": plan["requested_terminal_speed"],
                "planned_terminal_speed": plan["planned_terminal_speed"],
                "planned_terminal_velocity": plan["terminal_velocity"].copy(),
                "peak_planned_speed": plan["peak_planned_speed"],
                "planned_deceleration": plan["planned_deceleration"],
                "planned_terminal_acceleration": plan[
                    "terminal_acceleration"
                ].copy(),
                "planned_start_acceleration": plan["start_acceleration"].copy(),
                "quintic_repair_attempt": plan["quintic_repair_attempt"],
            }
        )
        closed_loop_active = bool(
            self.quintic_observed_popped_count
            >= self.quintic_closed_loop_min_pops
        )
        if closed_loop_active:
            inherited_required = float(
                self.trajectory_snapshot["required_thrust_acceleration"]
            )
            guidance_point = self._closed_loop_midcourse_guidance(
                plan, position, velocity, simulation_time
            )
            governed_required = float(
                self.trajectory_snapshot["required_thrust_acceleration"]
            )
            full_thrust = self._full_thrust_acceleration(simulation_time)
            if full_thrust > 1e-9:
                self.throttle_command += (
                    governed_required - inherited_required
                ) / full_thrust
        guidance_point = self._terminal_intercept_handoff(
            observation, position, velocity, simulation_time, plan
        )
        self.quintic_aero_force_feedforward = (
            self._measured_aero_force_feedforward(velocity)
        )
        self.quintic_aero_moment_feedforward = (
            self._measured_aero_moment_feedforward(velocity, self.previous_gyro)
        )
        if np.linalg.norm(self.quintic_aero_force_feedforward) > 0.0:
            direction = np.asarray(
                self.trajectory_snapshot["desired_thrust_direction"], dtype=float
            )
            required = float(
                self.trajectory_snapshot["required_thrust_acceleration"]
            )
            compensated_thrust = (
                required * direction + self.quintic_aero_force_feedforward
            )
            compensated_required = float(np.linalg.norm(compensated_thrust))
            compensated_direction = _unit(compensated_thrust, direction)
            self.trajectory_snapshot["desired_thrust_direction"] = (
                compensated_direction.copy()
            )
            self.trajectory_snapshot["required_thrust_acceleration"] = (
                compensated_required
            )
            full_thrust = self._full_thrust_acceleration(simulation_time)
            if full_thrust > 1e-9:
                self.throttle_command = float(
                    np.clip(
                        self.throttle_command
                        + (compensated_required - required) / full_thrust,
                        self.throttle_min,
                        self.throttle_max,
                    )
                )
            guidance_point = position + compensated_direction
        final_required = float(
            self.trajectory_snapshot.get(
                "required_thrust_acceleration", 0.0
            )
        )
        control_adjusted = closed_loop_active
        if control_adjusted:
            self._rate_limited_throttle(
                final_required,
                simulation_time,
                requested_throttle=self.throttle_command,
            )
        else:
            self.quintic_previous_throttle_output = self.throttle_command
        self.trajectory_snapshot.update(
            {
                "quintic_aero_force_feedforward": (
                    self.quintic_aero_force_feedforward.copy()
                ),
                "quintic_aero_moment_feedforward": (
                    self.quintic_aero_moment_feedforward.copy()
                ),
                "quintic_aero_feedforward_active": bool(
                    np.linalg.norm(self.quintic_aero_force_feedforward) > 0.0
                    or np.linalg.norm(self.quintic_aero_moment_feedforward) > 0.0
                ),
                "quintic_capture_hold_active": self.quintic_capture_hold_active,
                "quintic_closed_loop_active": closed_loop_active,
                "quintic_final_rate_limited_throttle": self.throttle_command,
            }
        )
        self.trajectory_snapshot.update(
            self._allocation_shadow(simulation_time, inherited_throttle)
        )
        self.energy_arc_snapshot["energy_arc_guidance_mode"] = (
            "terminal_pn_zem"
            if self.quintic_terminal_intercept_active
            else "quintic"
        )
        return guidance_point

    def get_action(self, observation):
        """Run unchanged GNC against a robust observation-only velocity view."""
        self.quintic_observed_popped_count = int(
            np.count_nonzero(
                np.asarray(observation["balloon_status"]).reshape(-1) == 2
            )
        )
        control_observation, navigation_snapshot = self._navigation_observation(
            observation
        )
        action = super().get_action(control_observation)
        self.telemetry[-1].update(navigation_snapshot)
        return action


# Keep the experimentally developed quintic controller available as an exact
# fallback.  The public GuidedPidAgent below selects the scheduled backend that
# passed the four-balloon, <=17 m/s A/B gate; callers can request the legacy
# implementation with ``use_scheduled_backend=False``.
LegacyQuinticGuidedPidAgent = GuidedPidAgent


class GuidedPidAgent(LegacyQuinticGuidedPidAgent):
    """Observation-only scheduled intercept with a reversible quintic fallback."""

    def __init__(self, given_parameters, **kwargs):
        options = dict(kwargs)
        self.use_scheduled_backend = bool(
            options.pop("use_scheduled_backend", True)
        )
        scheduled_keys = (
            "selector_altitude_weight",
            "selector_altitude_weight_post_hit",
            "selector_earliest_launch_time",
            "selector_time_budget_fraction",
            "launch_inclination_offset_deg",
            "launch_heading_offset_deg",
            "launch_min_climb_accel",
            "selector_launch_nearest_active",
            "selector_min_launch_chain",
            "selector_fallback_launch_time",
            "selector_fallback_min_launch_chain",
            "selector_post_hit_max_chain_length",
            "selector_post_hit_reward_decay",
            "selector_horizontal_turn_weight",
            "selector_climb_turn_weight",
            "selector_descent_turn_weight",
            "selector_use_directional_turn_cost",
            "selector_use_exit_state_surrogate",
            "selector_use_attitude_state_surrogate",
            "selector_use_brake_turn_surrogate",
            "selector_brake_turn_accel_fraction",
            "selector_brake_turn_decel",
            "selector_brake_turn_min_speed",
            "selector_use_closed_loop_rollout",
            "selector_closed_loop_rollout_horizon",
            "selector_closed_loop_rollout_adaptive_horizon",
            "selector_postburn_capture_time",
            "selector_use_ballistic_terminal_capture",
            "use_ballistic_successor_lookahead",
            "ballistic_successor_weight",
            "ballistic_successor_radius",
            "ballistic_successor_rank",
            "terminal_coast_lateral_bias",
            "terminal_coast_normal_bias",
            "use_terminal_attitude_hold",
            "terminal_hold_lateral_bias",
            "terminal_hold_normal_bias",
            "terminal_hold_throttle",
            "terminal_hold_bias_duration",
            "terminal_hold_bias_delay",
            "terminal_hold_release_after_bias",
            "terminal_hold_recovery_lateral_bias",
            "terminal_hold_recovery_normal_bias",
            "terminal_hold_recovery_duration",
            "terminal_hold_adaptive_projection",
            "terminal_hold_projection_gain",
            "terminal_hold_velocity_fit",
            "terminal_hold_velocity_fit_gain",
            "use_terminal_capture_guidance",
            "terminal_capture_radius",
            "terminal_capture_lookahead_weight",
            "terminal_capture_min_popped",
            "terminal_capture_successor_rank",
            "terminal_capture_throttle_scale",
            "terminal_capture_throttle_min_popped",
            "terminal_capture_lateral_bias",
            "terminal_capture_normal_bias",
            "terminal_capture_bias_delay",
            "terminal_capture_bias_duration",
            "unlimit_final_target",
            "unlimit_final_min_popped",
            "selector_prefer_longest_chain",
            "selector_use_flyby_route_bonus",
            "selector_flyby_radius_scale",
            "terminal_speed_target",
            "terminal_speed_hard_limit",
            "use_corner_speed_governor",
            "corner_speed_min",
            "corner_speed_max",
            "corner_speed_accel_fraction",
            "corner_speed_min_popped",
            "terminal_speed_brake_gain",
            "terminal_speed_post_two_brake_gain",
            "terminal_speed_brake_limit",
            "terminal_speed_hard_range",
            "terminal_speed_hard_gain",
            "lookahead_exit_speed_post_two",
            "lookahead_guidance_weight",
            "lookahead_guidance_weight_post_two",
            "dynamic_corridor_weight",
            "dynamic_corridor_radius",
            "dynamic_corridor_horizon",
            "dynamic_corridor_min_popped",
            "dynamic_corridor_one_shot",
            "dynamic_corridor_use_powered_tgo",
            "dynamic_corridor_min_lock_duration",
            "dynamic_corridor_max_popped",
            "controller_kwargs",
        )
        scheduled_options = {
            key: options.pop(key) for key in scheduled_keys if key in options
        }
        super().__init__(given_parameters, **options)
        self.scheduled_backend = (
            ScheduledInterceptAgent(given_parameters, **scheduled_options)
            if self.use_scheduled_backend
            else None
        )

    def _record_scheduled_telemetry(self, observation, action):
        backend = self.scheduled_backend
        state = np.asarray(backend.estimator.rocket_state, dtype=float)
        position = state[0:3].copy()
        velocity = state[3:6].copy()
        acceleration = state[6:9].copy()
        gyro = state[13:16].copy()

        target_index = -1
        if backend.current_target_idx < len(backend.target_idx_list):
            target_index = int(
                backend.target_idx_list[backend.current_target_idx]
            )
        relative_position = np.full(3, np.nan)
        relative_velocity = np.full(3, np.nan)
        target_distance = np.nan
        turn_angle = np.nan
        if target_index >= 0:
            target_state = np.asarray(
                observation["balloon_states"][target_index], dtype=float
            )
            relative_position = target_state[0:3] - position
            relative_velocity = target_state[3:6] - velocity
            target_distance = float(np.linalg.norm(relative_position))
            if np.linalg.norm(velocity) > 1e-9 and target_distance > 1e-9:
                turn_angle = _angle(velocity, relative_position)

        launch_attitude = backend.launch_inclination_heading
        if launch_attitude is not None:
            self.launch_attitude = np.asarray(launch_attitude, dtype=float)
        if backend.launch_time is not None:
            self.actual_launch_time = float(backend.launch_time)
        if target_index >= 0 and (
            not self.target_history or self.target_history[-1] != target_index
        ):
            self.target_history.append(target_index)
        self.target_index = target_index

        t_since_launch = (
            max(
                float(observation["simulation_time"]) - backend.launch_time,
                0.0,
            )
            if backend.launch_time is not None
            else 0.0
        )
        available_lateral = float(
            backend.navigator.vehicle.max_lateral_accel(t_since_launch)
        )
        tvc = np.asarray(action["tvc"], dtype=float)
        popped_count = int(
            np.count_nonzero(
                np.asarray(observation["balloon_status"]).reshape(-1) == 2
            )
        )
        self.telemetry.append(
            {
                "time": float(observation["simulation_time"]),
                "position": position,
                "velocity": velocity,
                "acceleration": acceleration,
                "gyro": gyro,
                "desired_rate": np.zeros(3),
                "attitude_error": np.zeros(3),
                "required_lateral_acceleration": np.nan,
                "available_lateral_acceleration": available_lateral,
                "planned_lateral_acceleration": np.nan,
                "raw_guidance_turn_angle": turn_angle,
                "planned_guidance_turn_angle": turn_angle,
                "target_turn_angle": turn_angle,
                "target_index": target_index,
                "target_distance": target_distance,
                "target_relative_position": relative_position,
                "target_relative_velocity": relative_velocity,
                "waypoint_distance": np.nan,
                "waypoints_reached_count": popped_count,
                "launch_command": bool(action["launch"]),
                "tvc_x": float(tvc[0]),
                "tvc_y": float(tvc[1]),
                "roll": float(action["roll"]),
                "throttle": float(action["throttle"]),
                "scheduled_terminal_speed_target": (
                    backend.terminal_speed_target
                ),
                "scheduled_terminal_speed_hard_limit": (
                    backend.terminal_speed_hard_limit
                ),
                "scheduled_t_go": backend.navigator.t_go,
                "scheduled_zem_miss": backend.navigator.zem_miss,
                "scheduled_acceleration_saturated": (
                    backend.navigator.saturated
                ),
                "scheduled_speed_braking": backend.navigator.braking,
                "scheduled_tilt_limited": backend.navigator.tilt_limited,
            }
        )

    def get_action(self, observation):
        if self.scheduled_backend is None:
            return super().get_action(observation)
        action = self.scheduled_backend.get_action(observation)
        self._record_scheduled_telemetry(observation, action)
        return action
