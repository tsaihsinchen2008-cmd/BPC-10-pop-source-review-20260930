"""Nine-hit observation-only profile, validated on scenario 1 / seed 14."""

from BalloonPoppingGymEnv.agents.guided_pid_agent_eight_balloon import (
    GuidedPidAgent as _EightBalloonAgent,
)


class GuidedPidAgent(_EightBalloonAgent):
    def __init__(self, given_parameters, **kwargs):
        settings = {
            "selector_earliest_launch_time": 15.04,
            "terminal_capture_radius": 60.0,
            "terminal_capture_throttle_scale": 1.0,
            "terminal_capture_throttle_min_popped": 8,
            "terminal_capture_lateral_bias": 0.12,
            "terminal_capture_normal_bias": 0.24,
            "terminal_capture_bias_delay": 0.0,
            "terminal_capture_bias_duration": 1.0,
        }
        settings.update(kwargs)
        super().__init__(given_parameters, **settings)
