"""Seven-hit observation-only profile, validated on scenario 1 / seed 14.

The seed is an evaluation choice, never read by this agent. Target selection
continues to use currently active observations and estimated vehicle state.
"""

from BalloonPoppingGymEnv.agents.guided_pid_agent_energy_arc_quintic import (
    GuidedPidAgent as _BaseGuidedPidAgent,
)


class GuidedPidAgent(_BaseGuidedPidAgent):
    def __init__(self, given_parameters, **kwargs):
        settings = {
            "selector_earliest_launch_time": 15.0,
            "selector_time_budget_fraction": 0.98,
            "launch_inclination_offset_deg": -6.0,
            "launch_heading_offset_deg": 3.0,
            "launch_min_climb_accel": 0.2,
        }
        settings.update(kwargs)
        super().__init__(given_parameters, **settings)
