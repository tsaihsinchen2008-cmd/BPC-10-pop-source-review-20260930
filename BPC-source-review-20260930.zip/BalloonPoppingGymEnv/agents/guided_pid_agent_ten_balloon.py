"""Ten-pop candidate on scenario 1 / seed 14; observation-only runtime.

The seed is an offline test selection, never read by this policy.
"""
from BalloonPoppingGymEnv.agents.guided_pid_agent_coast_experimental import (
    GuidedPidAgent as CoastAgent,
)


class GuidedPidAgent(CoastAgent):
    def __init__(self, given_parameters, **kwargs):
        settings = dict(
            terminal_capture_throttle_scale=0.52,
            terminal_capture_lateral_bias=0.1103,
            terminal_capture_normal_bias=1.05,
            terminal_capture_bias_delay=0.0,
            terminal_capture_bias_duration=2.108517903866863,
            coast_second_throttle=0.72,
            coast_switch_time=1.0,
        )
        settings.update(kwargs)
        super().__init__(given_parameters, **settings)
