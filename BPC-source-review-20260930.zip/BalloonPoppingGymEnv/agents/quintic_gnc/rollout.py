"""Observation-only short-horizon closed-loop rollout for target screening."""

from __future__ import annotations

import copy

import numpy as np

from BalloonPoppingGymEnv.agents.quintic_gnc.schema import Schema
from BalloonPoppingGymEnv.agents.quintic_gnc.vehicle import GRAVITY, Vehicle


class ClosedLoopRollout:
    def __init__(
        self,
        given_parameters,
        horizon: float = 1.5,
        dt: float = 0.05,
        adaptive_horizon: bool = False,
        max_horizon: float = 6.0,
    ):
        self.vehicle = Vehicle(given_parameters)
        self.horizon = float(horizon)
        self.dt = float(dt)
        self.adaptive_horizon = bool(adaptive_horizon)
        self.max_horizon = float(max_horizon)
        balloon = given_parameters[Schema.Given.Section.BALLOON]
        self.balloon_radius = float(balloon[Schema.Given.Balloon.RADIUS])
        rocket = given_parameters[Schema.Given.Section.ROCKET]
        body = rocket[Schema.Given.Rocket.ROCKET_BODY]
        radius = float(body[Schema.Given.RocketBody.RADIUS])
        drag_coefficient = float(body[Schema.Given.RocketBody.POWER_ON_DRAG])
        self.drag_area_coefficient = 0.5 * 1.225 * drag_coefficient * np.pi * radius**2
        self.rate_time_constant = self.vehicle.gimbal_slew_time()
        self.attitude_time_constant = 2.0 * self.rate_time_constant

    @staticmethod
    def _rotate(direction: np.ndarray, angular_velocity: np.ndarray, dt: float):
        rate = float(np.linalg.norm(angular_velocity))
        if rate < 1e-9:
            return direction
        axis = angular_velocity / rate
        angle = rate * dt
        rotated = (
            direction * np.cos(angle)
            + np.cross(axis, direction) * np.sin(angle)
            + axis * np.dot(axis, direction) * (1.0 - np.cos(angle))
        )
        return rotated / max(float(np.linalg.norm(rotated)), 1e-9)

    def evaluate(
        self,
        navigator,
        rocket_state: np.ndarray,
        body_direction: np.ndarray,
        angular_velocity: np.ndarray,
        target_state: np.ndarray,
        next_target_state: np.ndarray | None,
        t_since_launch: float,
        lookahead_weight: float,
    ) -> dict:
        nav = copy.deepcopy(navigator)
        nav.reset()
        state = np.asarray(rocket_state, dtype=float).copy()
        body = np.asarray(body_direction, dtype=float).copy()
        body /= max(float(np.linalg.norm(body)), 1e-9)
        omega = np.asarray(angular_velocity, dtype=float).copy()
        target = np.asarray(target_state, dtype=float).copy()
        following = (
            None
            if next_target_state is None
            else np.asarray(next_target_state, dtype=float).copy()
        )

        initial_relative_position = target[:3] - state[:3]
        initial_relative_velocity = target[3:6] - state[3:6]
        initial_distance = float(np.linalg.norm(initial_relative_position))
        evaluation_horizon = self.horizon
        if self.adaptive_horizon:
            predicted_t_go = nav._estimate_t_go(
                initial_relative_position,
                initial_relative_velocity,
                t_since_launch,
            )
            evaluation_horizon = float(
                np.clip(
                    predicted_t_go + 0.5,
                    self.horizon,
                    self.max_horizon,
                )
            )
        closest_distance = initial_distance
        saturated_steps = 0
        steps = max(int(np.ceil(evaluation_horizon / self.dt)), 1)
        for step in range(steps):
            elapsed = step * self.dt
            target_now = target.copy()
            target_now[:3] += target[3:6] * elapsed
            following_now = None
            if following is not None:
                following_now = following.copy()
                following_now[:3] += following[3:6] * elapsed

            thrust_direction, throttle = nav.compute(
                target_now,
                state,
                t_since_launch + elapsed,
                next_target_state=following_now,
                lookahead_weight=lookahead_weight,
            )
            if thrust_direction is None or throttle is None:
                break

            thrust_direction = np.asarray(thrust_direction, dtype=float)
            turn_axis = np.cross(body, thrust_direction)
            sin_error = float(np.linalg.norm(turn_axis))
            error = float(
                np.arctan2(
                    sin_error,
                    np.clip(np.dot(body, thrust_direction), -1.0, 1.0),
                )
            )
            if sin_error > 1e-9:
                turn_axis /= sin_error

            angular_accel_limit = max(
                self.vehicle.max_angular_accel(t_since_launch + elapsed), 1e-9
            )
            max_rate = 0.8 * angular_accel_limit * self.rate_time_constant
            desired_omega = turn_axis * min(
                error / max(self.attitude_time_constant, 1e-9), max_rate
            )
            omega_dot = (desired_omega - omega) / max(self.rate_time_constant, 1e-9)
            omega_dot_norm = float(np.linalg.norm(omega_dot))
            if omega_dot_norm > angular_accel_limit:
                omega_dot *= angular_accel_limit / omega_dot_norm
                saturated_steps += 1
            omega += omega_dot * self.dt
            body = self._rotate(body, omega, self.dt)

            speed = float(np.linalg.norm(state[3:6]))
            mass = self.vehicle.mass(t_since_launch + elapsed)
            drag = (
                -self.drag_area_coefficient * speed * state[3:6] / max(mass, 1e-9)
            )
            acceleration = (
                body
                * self.vehicle.max_accel(t_since_launch + elapsed)
                * float(throttle)
                + np.array([0.0, 0.0, -GRAVITY])
                + drag
            )
            state[:3] += state[3:6] * self.dt + 0.5 * acceleration * self.dt**2
            state[3:6] += acceleration * self.dt
            closest_distance = min(
                closest_distance,
                float(np.linalg.norm(target_now[:3] - state[:3])),
            )

        target_final = target[:3] + target[3:6] * evaluation_horizon
        relative_position = target_final - state[:3]
        final_distance = float(np.linalg.norm(relative_position))
        relative_velocity = state[3:6] - target[3:6]
        closing_speed = float(
            np.dot(relative_velocity, relative_position)
            / max(final_distance, 1e-9)
        )
        if self.adaptive_horizon:
            # All candidates are now propagated to their own expected
            # intercept.  Rank the quantity the vehicle must actually satisfy:
            # absolute miss measured in balloon radii.  The small terminal and
            # saturation terms break ties without allowing a nearby-but-
            # receding target or an infeasible attitude transient to win.
            relative_speed = float(np.linalg.norm(state[3:6] - target[3:6]))
            normalized_closing = float(
                np.clip(closing_speed / max(relative_speed, 1.0), -1.0, 1.0)
            )
            risk = (
                closest_distance / max(self.balloon_radius, 1e-9)
                + 0.1 * final_distance / max(initial_distance, 1e-9)
                - 0.05 * normalized_closing
                + 0.5 * saturated_steps / steps
            )
        else:
            risk = (
                closest_distance / max(initial_distance, 1e-9)
                + final_distance / max(initial_distance, 1e-9)
                - closing_speed / max(float(np.linalg.norm(state[3:6])), 1.0)
                + saturated_steps / steps
            )
        return {
            "risk": float(risk),
            "initial_distance": initial_distance,
            "closest_distance": closest_distance,
            "final_distance": final_distance,
            "closing_speed": closing_speed,
            "saturation_fraction": saturated_steps / steps,
            "evaluation_horizon": evaluation_horizon,
            "predicted_position": state[:3].copy(),
            "predicted_velocity": state[3:6].copy(),
            "predicted_body_direction": body.copy(),
            "predicted_angular_velocity": omega.copy(),
        }
