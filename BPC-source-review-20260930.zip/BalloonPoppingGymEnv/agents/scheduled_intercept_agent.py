import logging

import numpy as np

from BalloonPoppingGymEnv.agents.base_agent import BaseAgent
from BalloonPoppingGymEnv.agents.quintic_gnc.controller import Controller
from BalloonPoppingGymEnv.agents.quintic_gnc.estimator import Estimator
from BalloonPoppingGymEnv.agents.quintic_gnc.navigator import Navigator
from BalloonPoppingGymEnv.agents.quintic_gnc.rollout import ClosedLoopRollout
from BalloonPoppingGymEnv.agents.quintic_gnc.selector import Selector
from BalloonPoppingGymEnv.agents.quintic_gnc.schema import Schema

IDLE_ACTION = {
    "launch": False,
    "launch_inclination_heading": [90.0, 0.0],
    "tvc": [0.0, 0.0],
    "roll": 0.0,
    "throttle": 0.0,
}


def _rotate_body_vector_to_world(quaternion, vector) -> np.ndarray:
    """Rotate a body-frame vector with the estimator's body-to-world quaternion."""
    quaternion = np.asarray(quaternion, dtype=float)
    quaternion /= max(float(np.linalg.norm(quaternion)), 1e-9)
    vector = np.asarray(vector, dtype=float)
    scalar = float(quaternion[0])
    xyz = quaternion[1:4]
    return (
        vector
        + 2.0 * scalar * np.cross(xyz, vector)
        + 2.0 * np.cross(xyz, np.cross(xyz, vector))
    )


class ScheduledInterceptAgent(BaseAgent):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.logger = logging.getLogger(__name__)
        self.launch_inclination_offset_deg = float(
            kwargs.get("launch_inclination_offset_deg", 0.0)
        )
        self.launch_heading_offset_deg = float(
            kwargs.get("launch_heading_offset_deg", 0.0)
        )
        self.launch_min_climb_accel = float(kwargs.get("launch_min_climb_accel", 1.0))
        if not np.isfinite(self.launch_min_climb_accel) or self.launch_min_climb_accel <= 0:
            raise ValueError("launch_min_climb_accel must be finite and positive")
        if not all(np.isfinite(value) and abs(value) <= 15.0 for value in (
            self.launch_inclination_offset_deg, self.launch_heading_offset_deg
        )):
            raise ValueError("launch offsets must be finite and within +/-15 degrees")

        # Initialize GNC components
        self.estimator = Estimator(self.given_parameters)
        self.selector = Selector(self.given_parameters)
        self.selector.time_budget_fraction = float(
            kwargs.get("selector_time_budget_fraction", self.selector.time_budget_fraction)
        )
        if not 0.0 < self.selector.time_budget_fraction <= 1.0:
            raise ValueError("selector_time_budget_fraction must be in (0, 1]")
        self.selector.altitude_weight = float(
            kwargs.get("selector_altitude_weight", 0.0)
        )
        post_hit_altitude_weight = kwargs.get("selector_altitude_weight_post_hit")
        self.selector_altitude_weight_post_hit = (
            None
            if post_hit_altitude_weight is None
            else float(post_hit_altitude_weight)
        )
        self.selector.horizontal_turn_weight = float(
            kwargs.get("selector_horizontal_turn_weight", 20.0)
        )
        self.selector.climb_turn_weight = float(
            kwargs.get("selector_climb_turn_weight", 20.0)
        )
        self.selector.descent_turn_weight = float(
            kwargs.get("selector_descent_turn_weight", 20.0)
        )
        self.selector.use_directional_turn_cost = bool(
            kwargs.get("selector_use_directional_turn_cost", False)
        )
        self.selector.use_exit_state_surrogate = bool(
            kwargs.get("selector_use_exit_state_surrogate", False)
        )
        self.selector.use_attitude_state_surrogate = bool(
            kwargs.get("selector_use_attitude_state_surrogate", False)
        )
        self.selector.use_brake_turn_surrogate = bool(
            kwargs.get("selector_use_brake_turn_surrogate", False)
        )
        self.selector.brake_turn_accel_fraction = float(
            kwargs.get("selector_brake_turn_accel_fraction", 0.4)
        )
        self.selector.brake_turn_decel = float(
            kwargs.get("selector_brake_turn_decel", 4.0)
        )
        self.selector.brake_turn_min_speed = float(
            kwargs.get("selector_brake_turn_min_speed", 4.0)
        )
        self.use_closed_loop_rollout_selection = bool(
            kwargs.get("selector_use_closed_loop_rollout", False)
        )
        self.closed_loop_rollout_horizon = float(
            kwargs.get("selector_closed_loop_rollout_horizon", 1.5)
        )
        self.closed_loop_rollout_adaptive_horizon = bool(
            kwargs.get("selector_closed_loop_rollout_adaptive_horizon", False)
        )
        self.postburn_capture_time = float(
            kwargs.get("selector_postburn_capture_time", 0.0)
        )
        self.use_ballistic_terminal_capture = bool(
            kwargs.get("selector_use_ballistic_terminal_capture", False)
        )
        if self.postburn_capture_time < 0.0:
            raise ValueError("selector_postburn_capture_time must not be negative")
        self.selector.prefer_longest_chain = bool(
            kwargs.get("selector_prefer_longest_chain", False)
        )
        self.selector.use_flyby_route_bonus = bool(
            kwargs.get("selector_use_flyby_route_bonus", False)
        )
        self.selector.flyby_radius_scale = float(
            kwargs.get("selector_flyby_radius_scale", 1.0)
        )
        if self.selector.flyby_radius_scale <= 0.0:
            raise ValueError("selector_flyby_radius_scale must be positive")
        self.selector.earliest_launch_time = float(
            kwargs.get(
                "selector_earliest_launch_time",
                self.selector.earliest_launch_time,
            )
        )
        self.selector.launch_nearest_active = bool(
            kwargs.get("selector_launch_nearest_active", False)
        )
        self.selector.min_launch_chain = int(
            kwargs.get("selector_min_launch_chain", self.selector.min_launch_chain)
        )
        fallback_launch_time = kwargs.get("selector_fallback_launch_time")
        self.selector.fallback_launch_time = (
            None if fallback_launch_time is None else float(fallback_launch_time)
        )
        self.selector.fallback_min_launch_chain = int(
            kwargs.get(
                "selector_fallback_min_launch_chain",
                self.selector.fallback_min_launch_chain,
            )
        )
        post_hit_max_chain_length = kwargs.get(
            "selector_post_hit_max_chain_length"
        )
        self.selector_post_hit_max_chain_length = (
            None
            if post_hit_max_chain_length is None
            else int(post_hit_max_chain_length)
        )
        post_hit_reward_decay = kwargs.get("selector_post_hit_reward_decay")
        self.selector_post_hit_reward_decay = (
            None
            if post_hit_reward_decay is None
            else float(post_hit_reward_decay)
        )
        if min(
            self.selector.altitude_weight,
            self.selector.horizontal_turn_weight,
            self.selector.climb_turn_weight,
            self.selector.descent_turn_weight,
        ) < 0.0:
            raise ValueError("selector cost weights must be non-negative")
        if (
            self.selector_altitude_weight_post_hit is not None
            and self.selector_altitude_weight_post_hit < 0.0
        ):
            raise ValueError("selector_altitude_weight_post_hit must be non-negative")
        if not 0.0 <= self.selector.earliest_launch_time <= self.selector.latest_launch_time:
            raise ValueError(
                "selector_earliest_launch_time must be between 0 and latest launch time"
            )
        if self.selector.min_launch_chain < 1:
            raise ValueError("selector_min_launch_chain must be at least one")
        if (
            self.selector.fallback_launch_time is not None
            and not self.selector.earliest_launch_time
            <= self.selector.fallback_launch_time
            <= self.selector.latest_launch_time
        ):
            raise ValueError("selector_fallback_launch_time is outside launch bounds")
        if self.selector.fallback_min_launch_chain < 1:
            raise ValueError("selector_fallback_min_launch_chain must be at least one")
        if (
            self.selector_post_hit_max_chain_length is not None
            and self.selector_post_hit_max_chain_length < 1
        ):
            raise ValueError(
                "selector_post_hit_max_chain_length must be at least one"
            )
        if (
            self.selector_post_hit_reward_decay is not None
            and not 0.0 <= self.selector_post_hit_reward_decay <= 1.0
        ):
            raise ValueError(
                "selector_post_hit_reward_decay must be between zero and one"
            )
        if not (
            0.0 < self.selector.brake_turn_accel_fraction <= 1.0
            and self.selector.brake_turn_decel > 0.0
            and self.selector.brake_turn_min_speed > 0.0
        ):
            raise ValueError("brake-to-turn selector parameters are inconsistent")
        self.navigator = Navigator(self.given_parameters)
        self.closed_loop_rollout = (
            ClosedLoopRollout(
                self.given_parameters,
                horizon=self.closed_loop_rollout_horizon,
                adaptive_horizon=self.closed_loop_rollout_adaptive_horizon,
            )
            if self.use_closed_loop_rollout_selection
            else None
        )
        # The route model retains its validated 15 m/s budget, while guidance
        # actively schedules three-dimensional deceleration toward 8 m/s.
        # This keeps route selection feasible without forcing the vehicle to
        # carry the planning speed through the capture point.
        terminal_speed_target = float(kwargs.get("terminal_speed_target", 8.0))
        terminal_speed_hard_limit = float(
            kwargs.get("terminal_speed_hard_limit", 17.0)
        )
        if not 0.0 < terminal_speed_target <= terminal_speed_hard_limit <= 17.0:
            raise ValueError(
                "terminal speeds must satisfy 0 < target <= hard limit <= 17 m/s"
            )
        self.terminal_speed_target = terminal_speed_target
        self.terminal_speed_hard_limit = terminal_speed_hard_limit
        self.use_corner_speed_governor = bool(
            kwargs.get("use_corner_speed_governor", False)
        )
        self.corner_speed_min = float(kwargs.get("corner_speed_min", 6.0))
        self.corner_speed_max = float(kwargs.get("corner_speed_max", 17.0))
        self.corner_speed_accel_fraction = float(
            kwargs.get("corner_speed_accel_fraction", 0.4)
        )
        self.corner_speed_min_popped = int(
            kwargs.get("corner_speed_min_popped", 1)
        )
        self.corner_speed_target = terminal_speed_target
        self.corner_speed_trace = []
        if not (
            0.0 < self.corner_speed_min <= self.corner_speed_max <= 17.0
            and 0.0 < self.corner_speed_accel_fraction <= 1.0
            and self.corner_speed_min_popped >= 0
        ):
            raise ValueError("corner speed governor parameters are inconsistent")
        self.navigator.total_speed_target = terminal_speed_target
        self.terminal_speed_brake_gain = float(
            kwargs.get("terminal_speed_brake_gain", 1.5)
        )
        post_two_gain = kwargs.get("terminal_speed_post_two_brake_gain")
        self.terminal_speed_post_two_brake_gain = (
            None if post_two_gain is None else float(post_two_gain)
        )
        self.navigator.total_speed_brake_gain = self.terminal_speed_brake_gain
        self.navigator.total_speed_brake_limit = float(
            kwargs.get("terminal_speed_brake_limit", 6.0)
        )
        self.navigator.total_speed_hard_limit = terminal_speed_hard_limit
        self.navigator.total_speed_hard_range = float(
            kwargs.get("terminal_speed_hard_range", 40.0)
        )
        self.navigator.total_speed_hard_gain = float(
            kwargs.get("terminal_speed_hard_gain", 0.0)
        )
        post_two_exit_speed = kwargs.get("lookahead_exit_speed_post_two")
        self.lookahead_exit_speed_post_two = (
            None
            if post_two_exit_speed is None
            else float(post_two_exit_speed)
        )
        if (
            self.terminal_speed_brake_gain <= 0.0
            or self.navigator.total_speed_brake_limit <= 0.0
            or self.navigator.total_speed_hard_range <= 0.0
            or self.navigator.total_speed_hard_gain < 0.0
            or (
                self.terminal_speed_post_two_brake_gain is not None
                and self.terminal_speed_post_two_brake_gain <= 0.0
            )
            or (
                self.lookahead_exit_speed_post_two is not None
                and self.lookahead_exit_speed_post_two <= 0.0
            )
        ):
            raise ValueError("terminal speed governor gains must be positive")
        controller_kwargs = {"slew_aware": True}
        controller_kwargs.update(dict(kwargs.get("controller_kwargs", {})))
        self.controller = Controller(self.given_parameters, **controller_kwargs)

        self.lookahead_guidance_weight = float(
            kwargs.get("lookahead_guidance_weight", 0.1)
        )
        self.lookahead_guidance_weight_base = self.lookahead_guidance_weight
        post_two_lookahead_weight = kwargs.get(
            "lookahead_guidance_weight_post_two", 0.1
        )
        self.lookahead_guidance_weight_post_two = (
            None
            if post_two_lookahead_weight is None
            else float(post_two_lookahead_weight)
        )
        if not 0.0 <= self.lookahead_guidance_weight <= 1.0:
            raise ValueError("lookahead_guidance_weight must be between 0 and 1")
        if (
            self.lookahead_guidance_weight_post_two is not None
            and not 0.0 <= self.lookahead_guidance_weight_post_two <= 1.0
        ):
            raise ValueError(
                "lookahead_guidance_weight_post_two must be between 0 and 1"
            )

        corridor_targets = kwargs.get("corridor_targets", {})
        self.corridor_targets = {
            int(committed): int(flyby)
            for committed, flyby in dict(corridor_targets).items()
        }
        self.corridor_guidance_weight = float(
            kwargs.get("corridor_guidance_weight", 0.0)
        )
        if not 0.0 <= self.corridor_guidance_weight <= 1.0:
            raise ValueError("corridor_guidance_weight must be between 0 and 1")
        self.corridor_guidance_horizon = float(
            kwargs.get("corridor_guidance_horizon", 0.0)
        )
        if self.corridor_guidance_horizon < 0.0:
            raise ValueError("corridor_guidance_horizon must not be negative")
        if any(
            committed == flyby for committed, flyby in self.corridor_targets.items()
        ):
            raise ValueError("a corridor target must differ from its committed target")
        self.dynamic_corridor_weight = float(
            kwargs.get("dynamic_corridor_weight", 0.0)
        )
        self.dynamic_corridor_radius = float(
            kwargs.get("dynamic_corridor_radius", 15.0)
        )
        self.dynamic_corridor_horizon = float(
            kwargs.get("dynamic_corridor_horizon", 5.0)
        )
        self.dynamic_corridor_min_popped = int(
            kwargs.get("dynamic_corridor_min_popped", 0)
        )
        self.dynamic_corridor_one_shot = bool(
            kwargs.get("dynamic_corridor_one_shot", False)
        )
        self.dynamic_corridor_use_powered_tgo = bool(
            kwargs.get("dynamic_corridor_use_powered_tgo", False)
        )
        self.dynamic_corridor_min_lock_duration = float(
            kwargs.get("dynamic_corridor_min_lock_duration", 0.0)
        )
        dynamic_corridor_max_popped = kwargs.get("dynamic_corridor_max_popped")
        self.dynamic_corridor_max_popped = (
            None
            if dynamic_corridor_max_popped is None
            else int(dynamic_corridor_max_popped)
        )
        self.use_ballistic_successor_lookahead = bool(
            kwargs.get("use_ballistic_successor_lookahead", False)
        )
        self.ballistic_successor_weight = float(
            kwargs.get("ballistic_successor_weight", 0.01)
        )
        self.ballistic_successor_radius = float(
            kwargs.get("ballistic_successor_radius", 5.0)
        )
        self.ballistic_successor_rank = int(
            kwargs.get("ballistic_successor_rank", 1)
        )
        self.terminal_coast_lateral_bias = float(
            kwargs.get("terminal_coast_lateral_bias", 0.0)
        )
        self.terminal_coast_normal_bias = float(
            kwargs.get("terminal_coast_normal_bias", 0.0)
        )
        self.use_terminal_attitude_hold = bool(
            kwargs.get("use_terminal_attitude_hold", False)
        )
        self.use_terminal_capture_guidance = bool(
            kwargs.get("use_terminal_capture_guidance", False)
        )
        self.terminal_capture_radius = float(
            kwargs.get("terminal_capture_radius", 10.0)
        )
        self.terminal_capture_lookahead_weight = float(
            kwargs.get("terminal_capture_lookahead_weight", 0.1)
        )
        self.terminal_capture_min_popped = int(
            kwargs.get("terminal_capture_min_popped", 0)
        )
        self.terminal_capture_successor_rank = int(
            kwargs.get("terminal_capture_successor_rank", 1)
        )
        self.terminal_capture_throttle_scale = float(
            kwargs.get("terminal_capture_throttle_scale", 1.0)
        )
        self.terminal_capture_throttle_min_popped = int(
            kwargs.get("terminal_capture_throttle_min_popped", 8)
        )
        self.terminal_capture_lateral_bias = float(
            kwargs.get("terminal_capture_lateral_bias", 0.0)
        )
        self.terminal_capture_normal_bias = float(
            kwargs.get("terminal_capture_normal_bias", 0.0)
        )
        self.terminal_capture_bias_delay = float(kwargs.get("terminal_capture_bias_delay", 0.0))
        self.terminal_capture_bias_duration = float(
            kwargs.get("terminal_capture_bias_duration", float("inf"))
        )
        if not np.isfinite(self.terminal_capture_bias_delay) or self.terminal_capture_bias_delay < 0:
            raise ValueError("terminal_capture_bias_delay must be finite and nonnegative")
        if not self.terminal_capture_bias_duration > 0:
            raise ValueError("terminal_capture_bias_duration must be positive")
        self._terminal_capture_bias_start = None
        if not all(np.isfinite(value) and abs(value) <= 0.5 for value in (
            self.terminal_capture_lateral_bias, self.terminal_capture_normal_bias
        )):
            raise ValueError("terminal capture direction biases must be within +/-0.5")
        if not 0.0 <= self.terminal_capture_throttle_scale <= 1.0:
            raise ValueError("terminal_capture_throttle_scale must be in [0, 1]")
        if self.terminal_capture_throttle_min_popped < 0:
            raise ValueError("terminal_capture_throttle_min_popped must not be negative")
        if self.terminal_capture_successor_rank < 1:
            raise ValueError("terminal_capture_successor_rank must be positive")
        self.unlimit_final_target = bool(kwargs.get("unlimit_final_target", False))
        self.unlimit_final_min_popped = int(kwargs.get("unlimit_final_min_popped", 0))
        if self.unlimit_final_min_popped < 0:
            raise ValueError("unlimit_final_min_popped must not be negative")
        self.terminal_hold_lateral_bias = float(
            kwargs.get("terminal_hold_lateral_bias", 0.0)
        )
        self.terminal_hold_normal_bias = float(
            kwargs.get("terminal_hold_normal_bias", 0.0)
        )
        self.terminal_hold_throttle = float(
            kwargs.get("terminal_hold_throttle", self.controller.vehicle.throttle_min)
        )
        self.terminal_hold_bias_duration = float(
            kwargs.get("terminal_hold_bias_duration", np.inf)
        )
        self.terminal_hold_bias_delay = float(
            kwargs.get("terminal_hold_bias_delay", 0.0)
        )
        self.terminal_hold_release_after_bias = bool(
            kwargs.get("terminal_hold_release_after_bias", False)
        )
        self.terminal_hold_recovery_lateral_bias = float(
            kwargs.get("terminal_hold_recovery_lateral_bias", 0.0)
        )
        self.terminal_hold_recovery_normal_bias = float(
            kwargs.get("terminal_hold_recovery_normal_bias", 0.0)
        )
        self.terminal_hold_recovery_duration = float(
            kwargs.get("terminal_hold_recovery_duration", 0.0)
        )
        self.terminal_hold_adaptive_projection = bool(
            kwargs.get("terminal_hold_adaptive_projection", False)
        )
        self.terminal_hold_projection_gain = float(
            kwargs.get("terminal_hold_projection_gain", 0.2)
        )
        self.terminal_hold_velocity_fit = bool(
            kwargs.get("terminal_hold_velocity_fit", False)
        )
        self.terminal_hold_velocity_fit_gain = float(
            kwargs.get("terminal_hold_velocity_fit_gain", 0.2)
        )
        if not (
            self.controller.vehicle.throttle_min
            <= self.terminal_hold_throttle
            <= self.controller.vehicle.throttle_max
        ):
            raise ValueError("terminal_hold_throttle is outside actuator limits")
        if self.terminal_capture_radius <= 0.0:
            raise ValueError("terminal_capture_radius must be positive")
        if not 0.0 <= self.terminal_capture_lookahead_weight <= 1.0:
            raise ValueError("terminal_capture_lookahead_weight must be between 0 and 1")
        if self.terminal_capture_min_popped < 0:
            raise ValueError("terminal_capture_min_popped must not be negative")
        if not 0.0 <= self.ballistic_successor_weight <= 1.0:
            raise ValueError("ballistic_successor_weight must be between 0 and 1")
        if self.ballistic_successor_radius <= 0.0:
            raise ValueError("ballistic_successor_radius must be positive")
        if self.ballistic_successor_rank < 1:
            raise ValueError("ballistic_successor_rank must be at least one")
        if not 0.0 <= self.dynamic_corridor_weight <= 1.0:
            raise ValueError("dynamic_corridor_weight must be between 0 and 1")
        if self.dynamic_corridor_radius <= 0.0 or self.dynamic_corridor_horizon <= 0.0:
            raise ValueError("dynamic corridor radius and horizon must be positive")
        if self.dynamic_corridor_min_lock_duration < 0.0:
            raise ValueError("dynamic corridor minimum lock duration must not be negative")
        if self.dynamic_corridor_min_popped < 0:
            raise ValueError("dynamic_corridor_min_popped must not be negative")
        if (
            self.dynamic_corridor_max_popped is not None
            and self.dynamic_corridor_max_popped < self.dynamic_corridor_min_popped
        ):
            raise ValueError("dynamic corridor popped-count bounds are inconsistent")

        fixed_targets = kwargs.get("fixed_target_list")
        fixed_launch_time = kwargs.get("fixed_launch_time")
        if (fixed_targets is None) != (fixed_launch_time is None):
            raise ValueError(
                "fixed_target_list and fixed_launch_time must be provided together"
            )
        self.fixed_target_list = None
        self.fixed_launch_time = None
        if fixed_targets is not None:
            route = tuple(int(target) for target in fixed_targets)
            if not route:
                raise ValueError("fixed_target_list must not be empty")
            if any(target < 0 for target in route):
                raise ValueError("fixed target indices must be non-negative")
            if len(set(route)) != len(route):
                raise ValueError("fixed_target_list must not contain duplicates")
            if float(fixed_launch_time) < 0.0:
                raise ValueError("fixed_launch_time must be non-negative")
            self.fixed_target_list = route
            self.fixed_launch_time = float(fixed_launch_time)

        self.target_visualizer = None

        # Rebuilding the chain after every hit measures worse, and retesting it
        # on the beam search -- which has none of the axis search's filtering
        # that first explained the loss -- gave the same answer: 3.92 against
        # 4.29, worse on 8 of 24 seeds and better on none.
        #
        # It does what it was meant to: misses beyond 5 m fall from 14 to 2,
        # because replanning drops a last target it can now see is out of reach.
        # That turns out to be the whole problem. A miss at the end of the chain
        # is free -- the burn left over has no other use -- so giving up on one
        # only forfeits the times it would have connected. Over-planning costs
        # nothing and under-planning costs balloons, which is also why every
        # attempt to make the planner more ambitious came out exactly neutral:
        # the current setting already sits on that boundary.
        self.replan_after_hit = False

        # Once a target has actually popped, the measured exit velocity is more
        # reliable than the launch-time chain's predicted heading. Select the
        # next target from that state. This never abandons an active target: it
        # runs only after `_current_target` has confirmed the previous one popped.
        # With the selector's dual turn model, five fixed scenario-1 pool samples
        # raised the mean score from 4.2 to 4.6 and reduced approach-away events
        # from 4.0 to 2.0 per run.
        self.reselect_after_hit = True
        if self.fixed_target_list is not None:
            self.replan_after_hit = False
            self.reselect_after_hit = False

        self.should_launch = False
        self.launch_inclination_heading = None
        self.launch_time = None
        self.target_idx_list = []
        self.current_target_idx = 0
        self.leg_diagnostics = []
        self.rollout_decisions = []
        self.ballistic_capture_decisions = []
        self.dynamic_corridor_decisions = []
        self._last_dynamic_corridor = None
        self._dynamic_corridor_lock = None
        self._dynamic_corridor_consumed_for = None
        self.ballistic_successor_decisions = []
        self._last_ballistic_successor = None
        self._engagement_prediction = None
        self.flyby_plan_history = []
        self.terminal_hold_direction = None
        self.terminal_hold_base_direction = None
        self.terminal_hold_recovery_direction = None
        self.terminal_hold_start_time = None
        self.terminal_hold_target = None
        self.terminal_hold_decisions = []
        self.terminal_capture_target = None
        self.terminal_capture_decisions = []

    def reset(self) -> None:
        self._terminal_capture_bias_start = None
        self.estimator.reset()
        self.selector.reset()
        self.navigator.reset()
        self.controller.reset()

        self.should_launch = False
        self.launch_inclination_heading = None
        self.launch_time = None
        self.target_idx_list = []
        self.current_target_idx = 0
        self.leg_diagnostics.clear()
        self.rollout_decisions.clear()
        self.ballistic_capture_decisions.clear()
        self.dynamic_corridor_decisions.clear()
        self._last_dynamic_corridor = None
        self._dynamic_corridor_lock = None
        self._dynamic_corridor_consumed_for = None
        self.ballistic_successor_decisions.clear()
        self._last_ballistic_successor = None
        self._engagement_prediction = None
        self.flyby_plan_history.clear()
        self.terminal_hold_direction = None
        self.terminal_hold_base_direction = None
        self.terminal_hold_recovery_direction = None
        self.terminal_hold_start_time = None
        self.terminal_hold_target = None
        self.terminal_hold_decisions.clear()
        self.terminal_capture_target = None
        self.terminal_capture_decisions.clear()
        self.corner_speed_target = self.terminal_speed_target
        self.corner_speed_trace.clear()
        if self.target_visualizer is not None:
            self.target_visualizer.reset()

    def get_action(self, observation: dict) -> dict:
        simulation_time = float(observation[Schema.Observation.SIMULATION_TIME])
        just_launched = False

        # Not launch
        if not self.should_launch:
            if self.fixed_target_list is not None:
                self.should_launch = self._fixed_route_is_ready(observation)
            else:
                self.should_launch = self.selector.should_launch(observation)

            # Still not launch
            if not self.should_launch:
                self._update_target_visualizer(observation)
                return dict(IDLE_ACTION)

            # Run only once after should_launch become true. The selector
            # already searched a chain while deciding to go, so reuse it.
            balloon_states = self.selector.active_states(observation)
            if self.fixed_target_list is not None:
                self.target_idx_list = list(self.fixed_target_list)
            else:
                self.target_idx_list = (
                    self.selector.pending_targets
                    or self.selector.plan_chain(balloon_states)
                )

            # No feasible target set: stay on the pad rather than launching blind.
            if not self.target_idx_list:
                self.should_launch = False
                self._update_target_visualizer(observation)
                return dict(IDLE_ACTION)

            self.launch_time = simulation_time
            just_launched = True

            # Aim the rail at the first target. With a thrust-to-weight ratio
            # near 1.2 the rocket cannot turn hard in flight, so this is the
            # most powerful input available.
            first_target_state = balloon_states[self.target_idx_list[0]]
            self.launch_inclination_heading = self.navigator.get_launch_attitude(
                first_target_state
            )
            if self.launch_inclination_offset_deg or self.launch_heading_offset_deg:
                minimum = self.navigator.vehicle.min_climb_inclination(
                    0.0, self.launch_min_climb_accel
                )
                self.launch_inclination_heading[0] = np.clip(
                    self.launch_inclination_heading[0]
                    + self.launch_inclination_offset_deg, minimum, 90.0
                )
                self.launch_inclination_heading[1] = (
                    self.launch_inclination_heading[1]
                    + self.launch_heading_offset_deg
                ) % 360.0
            self.estimator.set_launch_attitude(self.launch_inclination_heading)

        t_since_launch = simulation_time - self.launch_time
        rocket_state = self.estimator.estimate_rocket(observation)
        self._record_completed_engagement(observation, rocket_state, simulation_time)

        previous_target_position = self.current_target_idx
        balloon_idx = self._current_target(observation)
        target_completed = self.current_target_idx > previous_target_position

        if self.reselect_after_hit and target_completed:
            # Launch selection must retain enough energy to leave the pad, but
            # public high-score replays show a distinct low-altitude chaining
            # phase after the first capture.  Applying this observation-derived
            # preference only to post-hit replans preserves launch feasibility
            # without hard-coding a balloon, time, route, or coordinate.
            if self.selector_altitude_weight_post_hit is not None:
                self.selector.altitude_weight = self.selector_altitude_weight_post_hit
            if self.selector_post_hit_max_chain_length is not None:
                self.selector.max_chain_length = (
                    self.selector_post_hit_max_chain_length
                )
            if self.selector_post_hit_reward_decay is not None:
                self.selector.target_reward_decay = (
                    self.selector_post_hit_reward_decay
                )
            self._replan_from_here(observation, rocket_state, t_since_launch)
            balloon_idx = self._current_target(observation)

        # A target just retired. The plan's remaining legs were priced from a
        # snapshot that is now seconds stale and the error grows down the chain,
        # so rebuild the tail -- but leave the balloon the rocket is already
        # committed to alone. Replanning from scratch at the moment of a hit
        # throws away an approach the guidance has already shaped for, and
        # measured 0.29 balloons worse; the accumulated error lives at the end
        # of the chain, not the front.
        if (
            self.replan_after_hit
            and self.current_target_idx > 0
            and balloon_idx is not None
        ):
            self._replan_tail(observation, rocket_state, t_since_launch, balloon_idx)

        # Chain flown to the end. Any burn still left is worth another chain, and
        # planning here costs nothing that was already committed -- unlike
        # replanning mid-approach, there is no target being flown at to abandon.
        if (
            self.fixed_target_list is None
            and balloon_idx is None
            and self.selector.remaining_budget(t_since_launch) > 0.0
        ):
            self._replan_from_here(observation, rocket_state, t_since_launch)
            balloon_idx = self._current_target(observation)

        if balloon_idx is None:
            # Nothing reachable left; stop steering.
            self._update_target_visualizer(observation)
            popped_count = int(
                np.count_nonzero(
                    np.asarray(
                        observation[Schema.Observation.BALLOON_STATUS]
                    ).reshape(-1)
                    == 2
                )
            )
            if (
                self.use_terminal_capture_guidance
                and popped_count >= self.terminal_capture_min_popped
            ):
                terminal_action = self._terminal_capture_action(
                    observation, rocket_state, t_since_launch
                )
                if terminal_action is not None:
                    return terminal_action
            if self.use_terminal_attitude_hold:
                self._acquire_terminal_attitude_hold(
                    observation, rocket_state, t_since_launch
                )
            if self.terminal_hold_direction is None:
                tvc, roll, throttle = self.controller.compute(
                    rocket_state, None, None, t_since_launch
                )
            else:
                tvc, roll, throttle = self.controller.compute(
                    rocket_state,
                    self._terminal_hold_command_direction(t_since_launch),
                    self.terminal_hold_throttle,
                    t_since_launch,
                )
            return {
                "launch": True,
                "launch_inclination_heading": self.launch_inclination_heading,
                "tvc": tvc,
                "roll": roll,
                "throttle": throttle,
            }

        # On the launch step the public environment constructs the flight but
        # intentionally ignores actuator fields.  Do not advance our actuator
        # memories on a command the plant never receives.  The next observation
        # starts both sides from TVC=0 and throttle=1.
        if just_launched:
            return {
                "launch": True,
                "launch_inclination_heading": self.launch_inclination_heading,
                "tvc": [0.0, 0.0],
                "roll": 0.0,
                "throttle": self.controller.vehicle.throttle_max,
            }

        # Current target state, not a lead one: the guidance law does its own
        # extrapolation over its time-to-go, so leading here would double it.
        target_state = self.estimator.estimate_target(observation, balloon_idx)
        popped_count = int(
            np.count_nonzero(
                np.asarray(
                    observation[Schema.Observation.BALLOON_STATUS]
                ).reshape(-1)
                == 2
            )
        )
        self.navigator.total_speed_brake_gain = (
            self.terminal_speed_post_two_brake_gain
            if (
                popped_count >= 2
                and self.terminal_speed_post_two_brake_gain is not None
            )
            else self.terminal_speed_brake_gain
        )
        if self.lookahead_exit_speed_post_two is not None:
            self.navigator.lookahead_exit_speed = (
                self.lookahead_exit_speed_post_two
                if popped_count >= 2
                else np.nan
            )
        self.lookahead_guidance_weight = (
            self.lookahead_guidance_weight_post_two
            if (
                popped_count >= 2
                and self.lookahead_guidance_weight_post_two is not None
            )
            else self.lookahead_guidance_weight_base
        )
        next_target_state = None
        guidance_lookahead_weight = self.lookahead_guidance_weight
        next_position = self.current_target_idx + 1
        if next_position < len(self.target_idx_list):
            next_idx = self.target_idx_list[next_position]
            if not self.selector.check_target_popped(next_idx, observation):
                next_target_state = self.estimator.estimate_target(
                    observation, next_idx
                )
        elif self.use_ballistic_successor_lookahead:
            successor = self._ballistic_successor_candidate(
                observation, rocket_state, balloon_idx, target_state
            )
            if successor is not None:
                next_target_state = self.estimator.estimate_target(
                    observation, successor["target"]
                )
                guidance_lookahead_weight = self.ballistic_successor_weight
                if successor["target"] != self._last_ballistic_successor:
                    self.ballistic_successor_decisions.append(
                        {
                            "time_since_launch": float(t_since_launch),
                            **successor,
                        }
                    )
            self._last_ballistic_successor = (
                None if successor is None else successor["target"]
            )
        self.navigator.total_speed_target = self.terminal_speed_target
        self.corner_speed_target = self.terminal_speed_target
        if (
            self.use_corner_speed_governor
            and popped_count >= self.corner_speed_min_popped
            and next_target_state is not None
        ):
            self.corner_speed_target = self._corner_terminal_speed(
                target_state,
                next_target_state,
                rocket_state,
                t_since_launch,
            )
            self.navigator.total_speed_target = self.corner_speed_target
        corridor_target_state = None
        corridor_weight = self.corridor_guidance_weight
        corridor_horizon = self.corridor_guidance_horizon
        corridor_time_to_go = None
        corridor_capture_radius = None
        corridor_idx = self.corridor_targets.get(balloon_idx)
        if corridor_idx is not None and not self.selector.check_target_popped(
            corridor_idx, observation
        ):
            corridor_target_state = self.estimator.estimate_target(
                observation, corridor_idx
            )
        elif (
            self.dynamic_corridor_weight > 0.0
            and popped_count >= self.dynamic_corridor_min_popped
            and (
                self.dynamic_corridor_max_popped is None
                or popped_count <= self.dynamic_corridor_max_popped
            )
        ):
            # A one-shot corridor may keep its existing lock; it only blocks
            # selecting a *new* flyby after that lock expires.  Checking the
            # consumed marker before the lock used to reduce the command to a
            # single 10 ms sample, making the configured weight effectively
            # inert.
            dynamic = self._locked_dynamic_corridor(
                observation, simulation_time, balloon_idx
            )
            if dynamic is None and not (
                self.dynamic_corridor_one_shot
                and self._dynamic_corridor_consumed_for == balloon_idx
            ):
                dynamic = self._dynamic_corridor_candidate(
                    observation, rocket_state, balloon_idx
                )
                if dynamic is not None:
                    self._dynamic_corridor_lock = {
                        **dynamic,
                        "expires_at": simulation_time
                        + max(
                            dynamic["predicted_time"],
                            self.dynamic_corridor_min_lock_duration,
                        ),
                    }
                    if self.dynamic_corridor_one_shot:
                        self._dynamic_corridor_consumed_for = balloon_idx
            if dynamic is not None:
                corridor_idx = dynamic["target"]
                corridor_target_state = self.estimator.estimate_target(
                    observation, corridor_idx
                )
                corridor_weight = self.dynamic_corridor_weight
                corridor_horizon = self.dynamic_corridor_horizon
                corridor_time_to_go = dynamic["predicted_time"]
                corridor_capture_radius = self.dynamic_corridor_radius
                if self.dynamic_corridor_use_powered_tgo:
                    # The selected coast pass need not occur at the same time
                    # under thrust. Re-estimate capture timing from observations
                    # each cycle while retaining the selected target identity.
                    corridor_time_to_go = self.navigator._estimate_t_go(
                        corridor_target_state[:3] - rocket_state[:3],
                        corridor_target_state[3:6] - rocket_state[3:6],
                        t_since_launch,
                    )
                    # The selector already bounded proximity. Powered-time ZEM
                    # can be larger; vehicle acceleration limits bound its action.
                    corridor_capture_radius = float("inf")
                if corridor_idx != self._last_dynamic_corridor:
                    self.dynamic_corridor_decisions.append(
                        {
                            "time_since_launch": float(t_since_launch),
                            **dynamic,
                        }
                    )
            self._last_dynamic_corridor = corridor_idx
        self._start_engagement_prediction(
            balloon_idx,
            target_state,
            rocket_state,
            simulation_time,
            t_since_launch,
        )
        self._update_target_visualizer(observation, balloon_idx)

        thrust_dir, desired_throttle = self.navigator.compute(
            target_state,
            rocket_state,
            t_since_launch,
            next_target_state=next_target_state,
            lookahead_weight=guidance_lookahead_weight,
            corridor_target_state=corridor_target_state,
            corridor_weight=corridor_weight,
            corridor_horizon=corridor_horizon,
            corridor_time_to_go=corridor_time_to_go,
            corridor_capture_radius=corridor_capture_radius,
            manage_speed=not (
                self.unlimit_final_target
                and popped_count >= self.unlimit_final_min_popped
                and self.current_target_idx + 1 >= len(self.target_idx_list)
            ),
        )
        thrust_dir = self._apply_terminal_coast_bias(
            thrust_dir,
            rocket_state,
            t_since_launch,
            next_target_state,
        )
        tvc, roll, throttle = self.controller.compute(
            rocket_state, thrust_dir, desired_throttle, t_since_launch
        )

        return {
            "launch": True,
            "launch_inclination_heading": self.launch_inclination_heading,
            "tvc": tvc,
            "roll": roll,
            "throttle": throttle,
        }

    def _corner_terminal_speed(
        self,
        target_state: np.ndarray,
        next_target_state: np.ndarray,
        rocket_state: np.ndarray,
        t_since_launch: float,
    ) -> float:
        """Speed that leaves enough path length to rotate into the next leg.

        For an approximately constant lateral acceleration, turning through
        ``theta`` at speed ``v`` consumes arc length ``v**2 * theta / a``.
        Solving that relation for speed supplies a continuous alternative to a
        fixed hover target.  All inputs are current observations or vehicle
        parameters supplied to the agent.
        """
        velocity = np.asarray(rocket_state[3:6], dtype=float)
        outgoing = np.asarray(next_target_state[:3], dtype=float) - np.asarray(
            target_state[:3], dtype=float
        )
        speed = float(np.linalg.norm(velocity))
        distance = float(np.linalg.norm(outgoing))
        if speed < 1e-9 or distance < 1e-9:
            return self.terminal_speed_target

        turn = float(
            np.arccos(
                np.clip(np.dot(velocity, outgoing) / (speed * distance), -1.0, 1.0)
            )
        )
        effective_turn = max(turn, np.radians(15.0))
        lateral_accel = self.selector.vehicle.max_lateral_accel(t_since_launch)
        target = np.sqrt(
            self.corner_speed_accel_fraction
            * max(lateral_accel, self.selector.vehicle.min_transit_accel)
            * distance
            / effective_turn
        )
        target = float(np.clip(target, self.corner_speed_min, self.corner_speed_max))
        if (
            not self.corner_speed_trace
            or abs(target - self.corner_speed_trace[-1]["target_speed"]) >= 0.25
        ):
            self.corner_speed_trace.append(
                {
                    "time_since_launch": float(t_since_launch),
                    "target_speed": target,
                    "turn_deg": float(np.degrees(turn)),
                    "next_leg_distance": distance,
                    "lateral_accel": float(lateral_accel),
                }
            )
        return target

    def _terminal_capture_action(
        self, observation: dict, rocket_state: np.ndarray, t_since_launch: float
    ) -> dict | None:
        """Use the last powered seconds to shape an unlimited-speed flyby chain."""
        states = self.selector.active_states(observation)
        candidates = self._ballistic_capture_candidates(
            states, rocket_state, horizon=6.0, radius=self.terminal_capture_radius
        )
        active_targets = {candidate["target"] for candidate in candidates}
        if self.terminal_capture_target not in active_targets:
            self.terminal_capture_target = (
                candidates[0]["target"] if candidates else None
            )
            if candidates:
                self.terminal_capture_decisions.append(
                    {
                        "t_since_launch": float(t_since_launch),
                        "selected": self.terminal_capture_target,
                        "candidates": candidates,
                    }
                )
        if self.terminal_capture_target is None:
            return None

        target_state = self.estimator.estimate_target(
            observation, self.terminal_capture_target
        )
        next_state = None
        successor_index = 0
        for candidate in candidates:
            if candidate["target"] != self.terminal_capture_target:
                successor_index += 1
                if successor_index != self.terminal_capture_successor_rank:
                    continue
                next_state = self.estimator.estimate_target(
                    observation, candidate["target"]
                )
                break
        thrust_dir, desired_throttle = self.navigator.compute(
            target_state,
            rocket_state,
            t_since_launch,
            next_target_state=next_state,
            lookahead_weight=self.terminal_capture_lookahead_weight,
            manage_speed=False,
        )
        popped_count = int(np.count_nonzero(
            np.asarray(observation[Schema.Observation.BALLOON_STATUS]) == 2
        ))
        if (
            desired_throttle is not None
            and popped_count >= self.terminal_capture_throttle_min_popped
        ):
            desired_throttle *= self.terminal_capture_throttle_scale
            if self._terminal_capture_bias_start is None:
                self._terminal_capture_bias_start = t_since_launch
            bias_elapsed = t_since_launch - self._terminal_capture_bias_start
            bias_active = (
                self.terminal_capture_bias_delay <= bias_elapsed
                < self.terminal_capture_bias_delay + self.terminal_capture_bias_duration
            )
            if bias_active and thrust_dir is not None and (
                self.terminal_capture_lateral_bias or self.terminal_capture_normal_bias
            ):
                velocity = np.asarray(rocket_state[3:6], dtype=float)
                direction = velocity / max(float(np.linalg.norm(velocity)), 1e-9)
                lateral = np.cross(direction, np.array([0.0, 0.0, 1.0]))
                lateral_norm = float(np.linalg.norm(lateral))
                if lateral_norm > 1e-9:
                    lateral /= lateral_norm
                    normal = np.cross(lateral, direction)
                    thrust_dir = (
                        thrust_dir + self.terminal_capture_lateral_bias * lateral
                        + self.terminal_capture_normal_bias * normal
                    )
                    thrust_dir /= max(float(np.linalg.norm(thrust_dir)), 1e-9)
        tvc, roll, throttle = self.controller.compute(
            rocket_state, thrust_dir, desired_throttle, t_since_launch
        )
        return {
            "launch": True,
            "launch_inclination_heading": self.launch_inclination_heading,
            "tvc": tvc,
            "roll": roll,
            "throttle": throttle,
        }

    def _locked_dynamic_corridor(
        self, observation: dict, simulation_time: float, committed: int
    ) -> dict | None:
        """Keep a selected flyby long enough for the attitude loop to respond."""
        lock = self._dynamic_corridor_lock
        if lock is None:
            return None
        target = int(lock["target"])
        remaining = float(lock["expires_at"] - simulation_time)
        if (
            remaining <= 0.05
            or target == committed
            or self.selector.check_target_popped(target, observation)
        ):
            self._dynamic_corridor_lock = None
            return None
        return {
            "target": target,
            "predicted_distance": float(lock["predicted_distance"]),
            "predicted_time": remaining,
        }

    def _acquire_terminal_attitude_hold(
        self,
        observation: dict,
        rocket_state: np.ndarray,
        t_since_launch: float,
    ) -> None:
        """Freeze a low-throttle attitude when the coast path captures a balloon."""
        if self.terminal_hold_direction is not None:
            return
        candidate = self._ballistic_capture_candidate(
            self.selector.active_states(observation), rocket_state, horizon=6.0
        )
        if candidate is None:
            return

        body = _rotate_body_vector_to_world(
            rocket_state[9:13], np.array([0.0, 0.0, 1.0])
        )
        self.terminal_hold_base_direction = body / max(
            float(np.linalg.norm(body)), 1e-9
        )
        self.terminal_hold_start_time = float(t_since_launch)
        velocity = np.asarray(rocket_state[3:6], dtype=float)
        speed = float(np.linalg.norm(velocity))
        desired = body.copy()
        adaptive_secondary = None
        if self.terminal_hold_velocity_fit:
            corridor = self._ballistic_capture_candidates(
                self.selector.active_states(observation),
                rocket_state,
                horizon=6.0,
                radius=self.terminal_capture_radius,
            )
            chronological = sorted(
                corridor, key=lambda item: item["predicted_time"]
            )[:3]
            denominator = sum(
                item["predicted_time"] ** 2 for item in chronological
            )
            if denominator > 1e-9:
                delta_velocity = sum(
                    item["predicted_time"]
                    * np.asarray(item["miss_vector"], dtype=float)
                    for item in chronological
                ) / denominator
                delta_norm = float(np.linalg.norm(delta_velocity))
                if delta_norm > 1e-9:
                    desired += (
                        self.terminal_hold_velocity_fit_gain
                        * delta_velocity
                        / delta_norm
                    )
        if self.terminal_hold_adaptive_projection:
            corridor = self._ballistic_capture_candidates(
                self.selector.active_states(observation),
                rocket_state,
                horizon=6.0,
                radius=self.terminal_capture_radius,
            )
            later = [
                item
                for item in corridor
                if item["target"] != candidate["target"]
                and item["predicted_time"] > candidate["predicted_time"]
            ]
            if later:
                adaptive_secondary = min(
                    later, key=lambda item: item["predicted_time"]
                )
                first_miss = np.asarray(candidate["miss_vector"], dtype=float)
                second_miss = np.asarray(
                    adaptive_secondary["miss_vector"], dtype=float
                )
                correction = second_miss - first_miss * (
                    float(np.dot(second_miss, first_miss))
                    / max(float(np.dot(first_miss, first_miss)), 1e-9)
                )
                correction_norm = float(np.linalg.norm(correction))
                if correction_norm > 1e-9:
                    desired += (
                        self.terminal_hold_projection_gain
                        * correction
                        / correction_norm
                    )
        if speed > 1e-9:
            velocity_hat = velocity / speed
            lateral = np.cross(velocity_hat, np.array([0.0, 0.0, 1.0]))
            lateral_norm = float(np.linalg.norm(lateral))
            if lateral_norm > 1e-9:
                lateral /= lateral_norm
                normal = np.cross(lateral, velocity_hat)
                desired += self.terminal_hold_lateral_bias * lateral
                desired += self.terminal_hold_normal_bias * normal
                recovery = self.terminal_hold_base_direction.copy()
                recovery += self.terminal_hold_recovery_lateral_bias * lateral
                recovery += self.terminal_hold_recovery_normal_bias * normal
                self.terminal_hold_recovery_direction = recovery / max(
                    float(np.linalg.norm(recovery)), 1e-9
                )
        self.terminal_hold_direction = desired / max(
            float(np.linalg.norm(desired)), 1e-9
        )
        self.terminal_hold_target = candidate["target"]
        self.terminal_hold_decisions.append(
            {
                "t_since_launch": float(t_since_launch),
                **candidate,
                "direction": self.terminal_hold_direction.tolist(),
                "adaptive_secondary": adaptive_secondary,
            }
        )

    def _terminal_hold_command_direction(
        self, t_since_launch: float
    ) -> np.ndarray | None:
        """Apply the exit-shaping bias only for its configured pulse window."""
        elapsed = (
            t_since_launch - self.terminal_hold_start_time
            if self.terminal_hold_start_time is not None
            else 0.0
        )
        if elapsed < self.terminal_hold_bias_delay:
            return None if self.terminal_hold_release_after_bias else (
                self.terminal_hold_base_direction
            )
        pulse_elapsed = elapsed - self.terminal_hold_bias_delay
        if (
            self.terminal_hold_base_direction is not None
            and self.terminal_hold_start_time is not None
            and pulse_elapsed >= self.terminal_hold_bias_duration
        ):
            if (
                self.terminal_hold_recovery_direction is not None
                and pulse_elapsed < self.terminal_hold_bias_duration
                + self.terminal_hold_recovery_duration
            ):
                return self.terminal_hold_recovery_direction
            if self.terminal_hold_release_after_bias:
                return None
            return self.terminal_hold_base_direction
        return self.terminal_hold_direction

    def _apply_terminal_coast_bias(
        self,
        thrust_direction: np.ndarray | None,
        rocket_state: np.ndarray,
        t_since_launch: float,
        next_target_state: np.ndarray | None,
    ) -> np.ndarray | None:
        """Apply an experimental local-frame attitude bias before the final coast."""
        if (
            thrust_direction is None
            or next_target_state is not None
            or self.current_target_idx + 1 < len(self.target_idx_list)
            or self.selector.remaining_budget(t_since_launch) > 3.5
            or (
                abs(self.terminal_coast_lateral_bias) < 1e-12
                and abs(self.terminal_coast_normal_bias) < 1e-12
            )
        ):
            return thrust_direction

        velocity = np.asarray(rocket_state[3:6], dtype=float)
        speed = float(np.linalg.norm(velocity))
        if speed < 1e-9:
            return thrust_direction
        velocity_hat = velocity / speed
        lateral = np.cross(velocity_hat, np.array([0.0, 0.0, 1.0]))
        lateral_norm = float(np.linalg.norm(lateral))
        if lateral_norm < 1e-9:
            return thrust_direction
        lateral /= lateral_norm
        normal = np.cross(lateral, velocity_hat)
        biased = (
            np.asarray(thrust_direction, dtype=float)
            + self.terminal_coast_lateral_bias * lateral
            + self.terminal_coast_normal_bias * normal
        )
        return biased / max(float(np.linalg.norm(biased)), 1e-9)

    def _dynamic_corridor_candidate(
        self, observation: dict, rocket_state: np.ndarray, committed: int
    ) -> dict | None:
        """Select an uncommitted active balloon near the current velocity corridor."""
        states = self.selector.active_states(observation)
        position = np.asarray(rocket_state[0:3], dtype=float)
        velocity = np.asarray(rocket_state[3:6], dtype=float)
        best = None
        times = np.linspace(0.05, self.dynamic_corridor_horizon, 100)
        rocket_path = (
            position[None, :]
            + times[:, None] * velocity[None, :]
            + 0.5 * times[:, None] ** 2 * np.array([0.0, 0.0, -9.81])
        )
        for target in np.flatnonzero(~np.isnan(states[:, 0])):
            if int(target) == committed:
                continue
            target_path = (
                states[target, :3][None, :]
                + times[:, None] * states[target, 3:6][None, :]
            )
            distances = np.linalg.norm(target_path - rocket_path, axis=1)
            closest_index = int(np.argmin(distances))
            closest_time = float(times[closest_index])
            if closest_time < 0.3:
                continue
            miss = float(distances[closest_index])
            if miss > self.dynamic_corridor_radius:
                continue
            candidate = {
                "target": int(target),
                "predicted_distance": miss,
                "predicted_time": float(closest_time),
            }
            if best is None or miss < best["predicted_distance"]:
                best = candidate
        return best

    def _ballistic_successor_candidate(
        self,
        observation: dict,
        rocket_state: np.ndarray,
        committed: int,
        committed_state: np.ndarray,
    ) -> dict | None:
        """Find a coast successor only after the committed target's closest pass."""
        position = np.asarray(rocket_state[0:3], dtype=float)
        velocity = np.asarray(rocket_state[3:6], dtype=float)
        target_relative_position = committed_state[:3] - position
        target_relative_velocity = committed_state[3:6] - velocity
        relative_speed_sq = float(
            np.dot(target_relative_velocity, target_relative_velocity)
        )
        if relative_speed_sq < 1e-9:
            return None
        committed_time = -float(
            np.dot(target_relative_position, target_relative_velocity)
        ) / relative_speed_sq
        if not 0.3 <= committed_time <= 2.5:
            return None

        times = np.linspace(committed_time + 0.3, committed_time + 6.0, 115)
        rocket_path = (
            position[None, :]
            + times[:, None] * velocity[None, :]
            + 0.5 * times[:, None] ** 2 * np.array([0.0, 0.0, -9.81])
        )
        states = self.selector.active_states(observation)
        planned = set(self.target_idx_list[self.current_target_idx :])
        candidates = []
        for target in np.flatnonzero(~np.isnan(states[:, 0])):
            if int(target) == committed or int(target) in planned:
                continue
            target_path = (
                states[target, :3][None, :]
                + times[:, None] * states[target, 3:6][None, :]
            )
            distances = np.linalg.norm(target_path - rocket_path, axis=1)
            closest_index = int(np.argmin(distances))
            candidate = {
                "target": int(target),
                "predicted_distance": float(distances[closest_index]),
                "predicted_time": float(times[closest_index]),
                "committed_time": float(committed_time),
            }
            candidates.append(candidate)
        candidates.sort(key=lambda candidate: candidate["predicted_distance"])
        rank = self.ballistic_successor_rank - 1
        if rank >= len(candidates):
            return None
        selected = candidates[rank]
        if selected["predicted_distance"] > self.ballistic_successor_radius:
            return None
        return selected

    def _fixed_route_is_ready(self, observation: dict) -> bool:
        """Whether a configured route can launch without targeting the ground."""
        if self.fixed_target_list is None:
            return False

        simulation_time = float(observation[Schema.Observation.SIMULATION_TIME])
        if simulation_time < self.fixed_launch_time:
            return False

        status = np.asarray(
            observation[Schema.Observation.BALLOON_STATUS], dtype=int
        ).reshape(-1)
        if any(target >= len(status) for target in self.fixed_target_list):
            raise ValueError(
                f"fixed_target_list contains an index outside 0..{len(status) - 1}"
            )

        # A fixed sequence must be fully observable when committed. Otherwise
        # guidance would steer towards a balloon's rail position before release.
        return all(status[target] == 1 for target in self.fixed_target_list)

    def _update_target_visualizer(
        self, observation: dict, current_target: int | None = None
    ) -> None:
        """Refresh the optional selector view without changing agent decisions."""
        if self.target_visualizer is None:
            return
        self.target_visualizer.update(
            observation,
            planned_targets=self.target_idx_list[self.current_target_idx :],
            current_target=current_target,
        )

    def _replan_from_here(
        self, observation: dict, rocket_state, t_since_launch: float
    ) -> None:
        """Start a fresh chain from the rocket's current state."""
        rocket_vel = rocket_state[3:6]
        speed = float(np.linalg.norm(rocket_vel))
        body_direction = None
        angular_velocity = None
        if (
            self.selector.use_attitude_state_surrogate
            or self.use_closed_loop_rollout_selection
        ):
            body_direction = _rotate_body_vector_to_world(
                rocket_state[9:13], np.array([0.0, 0.0, 1.0])
            )
            angular_velocity = _rotate_body_vector_to_world(
                rocket_state[9:13], rocket_state[13:16]
            )

        active_states = self.selector.active_states(observation)
        remaining_budget = self.selector.remaining_budget(t_since_launch)
        terminal_glide = (
            self.postburn_capture_time
            if (
                self.postburn_capture_time > 0.0
                and 0.0 < remaining_budget <= self.postburn_capture_time + 1.0
            )
            else 0.0
        )
        planning_kwargs = dict(
            origin=rocket_state[0:3],
            incoming_dir=rocket_vel / speed if speed > 1.0 else None,
            incoming_velocity=(
                rocket_vel
                if (
                    (
                        self.selector.use_exit_state_surrogate
                        or self.selector.use_brake_turn_surrogate
                    )
                    and speed > 1.0
                )
                else None
            ),
            body_direction=body_direction,
            angular_velocity=angular_velocity,
            time_budget=remaining_budget + terminal_glide,
            t_since_launch=t_since_launch,
        )
        chain = None
        if self.use_closed_loop_rollout_selection:
            candidates = self.selector.candidate_chains(
                active_states,
                limit_per_model=6,
                **planning_kwargs,
            )
            if candidates:
                max_length = max(len(candidate) for candidate in candidates)
                candidate_scores = []
                for rank, candidate in enumerate(candidates):
                    if len(candidate) != max_length:
                        continue
                    first = candidate[0]
                    following = candidate[1] if len(candidate) > 1 else None
                    result = self.closed_loop_rollout.evaluate(
                        self.navigator,
                        rocket_state,
                        body_direction,
                        angular_velocity,
                        active_states[first],
                        None if following is None else active_states[following],
                        t_since_launch,
                        self.lookahead_guidance_weight,
                    )
                    candidate_scores.append(
                        (float(result["risk"]), rank, candidate, result)
                    )

                if candidate_scores:
                    candidate_scores.sort(key=lambda item: (item[0], item[1]))
                    chain = list(candidate_scores[0][2])
                    self.rollout_decisions.append(
                        {
                            "t_since_launch": float(t_since_launch),
                            "max_chain_length": int(max_length),
                            "selected_route": chain,
                            "candidates": [
                                {
                                    "route": list(candidate),
                                    "risk": float(result["risk"]),
                                    "closest_distance": float(
                                        result["closest_distance"]
                                    ),
                                    "final_distance": float(result["final_distance"]),
                                    "closing_speed": float(result["closing_speed"]),
                                    "saturation_fraction": float(
                                        result["saturation_fraction"]
                                    ),
                                    "evaluation_horizon": float(
                                        result["evaluation_horizon"]
                                    ),
                                }
                                for _, _, candidate, result in candidate_scores
                            ],
                        }
                    )
        else:
            chain = self.selector.plan_chain(active_states, **planning_kwargs)
        if not chain and self.use_ballistic_terminal_capture:
            candidate = self._ballistic_capture_candidate(
                active_states, rocket_state, horizon=6.0
            )
            if candidate is not None:
                chain = [candidate["target"]]
                self.ballistic_capture_decisions.append(
                    {
                        "t_since_launch": float(t_since_launch),
                        **candidate,
                    }
                )
        if chain:
            self.target_idx_list = chain
            self.current_target_idx = 0
            if self.selector.last_flyby_prediction is not None:
                self.flyby_plan_history.append(
                    {
                        "t_since_launch": float(t_since_launch),
                        **self.selector.last_flyby_prediction,
                    }
                )

    def _ballistic_capture_candidate(
        self, balloon_states: np.ndarray, rocket_state: np.ndarray, horizon: float
    ) -> dict | None:
        """Find an active balloon already inside the unsteered coast corridor."""
        balloon_radius = float(
            self.given_parameters[Schema.Given.Section.BALLOON][
                Schema.Given.Balloon.RADIUS
            ]
        )
        candidates = self._ballistic_capture_candidates(
            balloon_states, rocket_state, horizon, balloon_radius
        )
        return candidates[0] if candidates else None

    def _ballistic_capture_candidates(
        self,
        balloon_states: np.ndarray,
        rocket_state: np.ndarray,
        horizon: float,
        radius: float,
    ) -> list[dict]:
        """Rank active balloons near the observation-only ballistic corridor."""
        times = np.linspace(0.05, horizon, int(np.ceil(horizon / 0.05)))
        rocket_position = np.asarray(rocket_state[0:3], dtype=float)
        rocket_velocity = np.asarray(rocket_state[3:6], dtype=float)
        rocket_path = (
            rocket_position[None, :]
            + times[:, None] * rocket_velocity[None, :]
            + 0.5 * times[:, None] ** 2 * np.array([0.0, 0.0, -9.81])
        )
        candidates = []
        for target in np.flatnonzero(~np.isnan(balloon_states[:, 0])):
            target_path = (
                balloon_states[target, :3][None, :]
                + times[:, None] * balloon_states[target, 3:6][None, :]
            )
            distances = np.linalg.norm(target_path - rocket_path, axis=1)
            closest_index = int(np.argmin(distances))
            result = {
                "target": int(target),
                "predicted_distance": float(distances[closest_index]),
                "predicted_time": float(times[closest_index]),
                "miss_vector": (
                    target_path[closest_index] - rocket_path[closest_index]
                ).tolist(),
            }
            if result["predicted_distance"] <= radius:
                candidates.append(result)
        candidates.sort(key=lambda item: item["predicted_distance"])
        return candidates

    def _replan_tail(
        self, observation: dict, rocket_state, t_since_launch: float, committed: int
    ) -> None:
        """Rebuild the chain beyond the balloon the rocket is already flying at."""
        states = self.selector.active_states(observation)

        arrival_time, arrival_pos, arrival_dir = self.selector.predict_arrival(
            states[committed], rocket_state[0:3], rocket_state[3:6], t_since_launch
        )

        chain_start = t_since_launch + arrival_time
        budget = self.selector.remaining_budget(chain_start)
        if budget <= 0.0:
            return

        # Roll the field forward to the moment the tail actually begins, and take
        # the committed balloon out of the running.
        tail_states = states.copy()
        tail_states[:, :3] += tail_states[:, 3:6] * arrival_time
        tail_states[committed] = np.nan

        tail = self.selector.plan_chain(
            tail_states,
            origin=arrival_pos,
            incoming_dir=arrival_dir,
            time_budget=budget,
            t_since_launch=chain_start,
        )

        self.target_idx_list = [committed] + list(tail or [])
        self.current_target_idx = 0

    def _start_engagement_prediction(
        self,
        balloon_idx: int,
        target_state: np.ndarray,
        rocket_state: np.ndarray,
        simulation_time: float,
        t_since_launch: float,
    ) -> None:
        """Snapshot the selector's prediction when a new target is engaged."""
        if (
            self._engagement_prediction is not None
            and self._engagement_prediction["target"] == balloon_idx
        ):
            return

        duration, position, velocity = self.selector.predict_arrival_state(
            target_state,
            rocket_state[0:3],
            rocket_state[3:6],
            t_since_launch,
        )
        leg = np.asarray(position, dtype=float) - np.asarray(
            rocket_state[0:3], dtype=float
        )
        distance = float(np.linalg.norm(leg))
        incoming_velocity = np.asarray(rocket_state[3:6], dtype=float)
        incoming_speed = float(np.linalg.norm(incoming_velocity))
        if distance > 1e-9 and incoming_speed > 1e-9:
            turn_deg = float(
                np.degrees(
                    np.arccos(
                        np.clip(
                            np.dot(incoming_velocity, leg)
                            / (incoming_speed * distance),
                            -1.0,
                            1.0,
                        )
                    )
                )
            )
        else:
            turn_deg = 0.0
        self._engagement_prediction = {
            "target": int(balloon_idx),
            "start_time": float(simulation_time),
            "duration": float(duration),
            "position": np.asarray(position, dtype=float),
            "velocity": np.asarray(velocity, dtype=float),
            "distance": distance,
            "turn_deg": turn_deg,
            "climb_sin": float(leg[2] / distance) if distance > 1e-9 else 0.0,
            "incoming_speed": incoming_speed,
            "t_since_launch": float(t_since_launch),
            "target_state_snapshot": np.asarray(target_state, dtype=float).tolist(),
            "rocket_state_snapshot": np.asarray(rocket_state, dtype=float).tolist(),
        }

    def _record_completed_engagement(
        self,
        observation: dict,
        rocket_state: np.ndarray,
        simulation_time: float,
    ) -> None:
        """Compare a completed leg with the prediction that selected it."""
        prediction = self._engagement_prediction
        if prediction is None:
            return

        status = np.asarray(
            observation[Schema.Observation.BALLOON_STATUS], dtype=int
        ).reshape(-1)
        target = prediction["target"]
        if target >= len(status) or status[target] != 2:
            return

        predicted_velocity = prediction["velocity"]
        actual_velocity = np.asarray(rocket_state[3:6], dtype=float)
        predicted_speed = float(np.linalg.norm(predicted_velocity))
        actual_speed = float(np.linalg.norm(actual_velocity))
        if predicted_speed > 1e-9 and actual_speed > 1e-9:
            direction_error = float(
                np.degrees(
                    np.arccos(
                        np.clip(
                            np.dot(predicted_velocity, actual_velocity)
                            / (predicted_speed * actual_speed),
                            -1.0,
                            1.0,
                        )
                    )
                )
            )
        else:
            direction_error = np.nan

        actual_duration = float(simulation_time - prediction["start_time"])
        diagnostic = {
            "target": target,
            "predicted_duration": prediction["duration"],
            "actual_duration": actual_duration,
            "predicted_speed": predicted_speed,
            "actual_speed": actual_speed,
            "direction_error_deg": direction_error,
            "position_error": float(
                np.linalg.norm(
                    np.asarray(rocket_state[0:3], dtype=float) - prediction["position"]
                )
            ),
            "distance": prediction.get("distance", np.nan),
            "turn_deg": prediction.get("turn_deg", np.nan),
            "climb_sin": prediction.get("climb_sin", np.nan),
            "incoming_speed": prediction.get("incoming_speed", np.nan),
            "t_since_launch": prediction.get("t_since_launch", np.nan),
            "target_state_snapshot": prediction.get("target_state_snapshot"),
            "rocket_state_snapshot": prediction.get("rocket_state_snapshot"),
        }
        self.leg_diagnostics.append(diagnostic)
        self.logger.info(
            "Target %d leg: dt %.2f predicted / %.2f actual s; "
            "exit speed %.2f / %.2f m/s; direction error %.1f deg; "
            "position error %.2f m",
            target,
            diagnostic["predicted_duration"],
            diagnostic["actual_duration"],
            diagnostic["predicted_speed"],
            diagnostic["actual_speed"],
            diagnostic["direction_error_deg"],
            diagnostic["position_error"],
        )
        self._engagement_prediction = None

    def _current_target(self, observation: dict) -> int | None:
        """Index of the target being engaged, skipping any already popped."""
        while self.current_target_idx < len(self.target_idx_list):
            balloon_idx = self.target_idx_list[self.current_target_idx]
            if not self.selector.check_target_popped(balloon_idx, observation):
                return balloon_idx
            self.current_target_idx += 1
        return None
