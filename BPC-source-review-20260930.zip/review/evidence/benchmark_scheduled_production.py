"""Public-interface benchmark for the production scheduled backend."""

from __future__ import annotations

import argparse
import json
import csv
from pathlib import Path

import numpy as np

from BalloonPoppingGymEnv.agents.guided_pid_agent_energy_arc_quintic import (
    GuidedPidAgent,
)
from BalloonPoppingGymEnv.envs.balloon_world import BalloonPoppingEnv
from BalloonPoppingGymEnv.evaluation.evaluate import load_scenario_parameters


parser = argparse.ArgumentParser()
parser.add_argument("--seed", type=int, default=0)
parser.add_argument("--verify-seven-profile", action="store_true")
parser.add_argument("--verify-eight-profile", action="store_true")
parser.add_argument("--verify-nine-profile", action="store_true")
parser.add_argument("--verify-ten-profile", action="store_true")
parser.add_argument("--late-chain-profile", action="store_true")
parser.add_argument("--reachability-profile", action="store_true")
parser.add_argument("--coast-profile", action="store_true")
parser.add_argument("--nine-overrides", type=json.loads, default={},
                    help="Experimental constructor overrides for the nine profile")
parser.add_argument("--launch-inclination-offset-deg", type=float, default=0.0)
parser.add_argument("--launch-heading-offset-deg", type=float, default=0.0)
parser.add_argument("--launch-min-climb-accel", type=float, default=1.0)
parser.add_argument("--selector-altitude-weight", type=float, default=0.0)
parser.add_argument("--selector-altitude-weight-post-hit", type=float)
parser.add_argument("--selector-time-budget-fraction", type=float, default=0.95)
parser.add_argument("--selector-earliest-launch-time", type=float, default=10.0)
parser.add_argument("--selector-launch-nearest-active", action="store_true")
parser.add_argument("--selector-min-launch-chain", type=int, default=5)
parser.add_argument("--selector-fallback-launch-time", type=float)
parser.add_argument("--selector-fallback-min-launch-chain", type=int, default=4)
parser.add_argument("--selector-post-hit-max-chain-length", type=int)
parser.add_argument("--selector-post-hit-reward-decay", type=float)
parser.add_argument("--selector-horizontal-turn-weight", type=float, default=20.0)
parser.add_argument("--selector-climb-turn-weight", type=float, default=20.0)
parser.add_argument("--selector-descent-turn-weight", type=float, default=20.0)
parser.add_argument("--selector-use-directional-turn-cost", action="store_true")
parser.add_argument("--selector-use-exit-state-surrogate", action="store_true")
parser.add_argument("--selector-use-attitude-state-surrogate", action="store_true")
parser.add_argument("--selector-use-brake-turn-surrogate", action="store_true")
parser.add_argument("--selector-brake-turn-accel-fraction", type=float, default=0.4)
parser.add_argument("--selector-brake-turn-decel", type=float, default=4.0)
parser.add_argument("--selector-brake-turn-min-speed", type=float, default=4.0)
parser.add_argument("--selector-use-closed-loop-rollout", action="store_true")
parser.add_argument("--selector-closed-loop-rollout-horizon", type=float, default=1.5)
parser.add_argument(
    "--selector-closed-loop-rollout-adaptive-horizon", action="store_true"
)
parser.add_argument("--selector-postburn-capture-time", type=float, default=0.0)
parser.add_argument("--selector-use-ballistic-terminal-capture", action="store_true")
parser.add_argument("--use-ballistic-successor-lookahead", action="store_true")
parser.add_argument("--ballistic-successor-weight", type=float, default=0.01)
parser.add_argument("--ballistic-successor-radius", type=float, default=5.0)
parser.add_argument("--ballistic-successor-rank", type=int, default=1)
parser.add_argument("--terminal-coast-lateral-bias", type=float, default=0.0)
parser.add_argument("--terminal-coast-normal-bias", type=float, default=0.0)
parser.add_argument("--use-terminal-attitude-hold", action="store_true")
parser.add_argument("--terminal-hold-lateral-bias", type=float, default=0.0)
parser.add_argument("--terminal-hold-normal-bias", type=float, default=0.0)
parser.add_argument("--terminal-hold-throttle", type=float, default=0.0)
parser.add_argument("--terminal-hold-bias-duration", type=float, default=float("inf"))
parser.add_argument("--terminal-hold-bias-delay", type=float, default=0.0)
parser.add_argument("--terminal-hold-release-after-bias", action="store_true")
parser.add_argument("--terminal-hold-recovery-lateral-bias", type=float, default=0.0)
parser.add_argument("--terminal-hold-recovery-normal-bias", type=float, default=0.0)
parser.add_argument("--terminal-hold-recovery-duration", type=float, default=0.0)
parser.add_argument("--terminal-hold-adaptive-projection", action="store_true")
parser.add_argument("--terminal-hold-projection-gain", type=float, default=0.2)
parser.add_argument("--terminal-hold-velocity-fit", action="store_true")
parser.add_argument("--terminal-hold-velocity-fit-gain", type=float, default=0.2)
parser.add_argument("--use-terminal-capture-guidance", action="store_true")
parser.add_argument("--terminal-capture-radius", type=float, default=10.0)
parser.add_argument("--terminal-capture-lookahead-weight", type=float, default=0.1)
parser.add_argument("--terminal-capture-min-popped", type=int, default=0)
parser.add_argument("--terminal-capture-successor-rank", type=int, default=1)
parser.add_argument("--terminal-capture-throttle-scale", type=float, default=1.0)
parser.add_argument("--terminal-capture-throttle-min-popped", type=int, default=8)
parser.add_argument("--terminal-capture-lateral-bias", type=float, default=0.0)
parser.add_argument("--terminal-capture-normal-bias", type=float, default=0.0)
parser.add_argument("--terminal-capture-bias-delay", type=float, default=0.0)
parser.add_argument("--terminal-capture-bias-duration", type=float, default=float("inf"))
parser.add_argument("--unlimit-final-target", action="store_true")
parser.add_argument("--unlimit-final-min-popped", type=int, default=0)
parser.add_argument("--selector-prefer-longest-chain", action="store_true")
parser.add_argument("--selector-use-flyby-route-bonus", action="store_true")
parser.add_argument("--selector-flyby-radius-scale", type=float, default=1.0)
parser.add_argument("--terminal-speed-target", type=float, default=8.0)
parser.add_argument("--use-corner-speed-governor", action="store_true")
parser.add_argument("--corner-speed-min", type=float, default=6.0)
parser.add_argument("--corner-speed-max", type=float, default=17.0)
parser.add_argument("--corner-speed-accel-fraction", type=float, default=0.4)
parser.add_argument("--corner-speed-min-popped", type=int, default=1)
parser.add_argument("--terminal-speed-brake-gain", type=float, default=1.5)
parser.add_argument("--terminal-speed-post-two-brake-gain", type=float)
parser.add_argument("--terminal-speed-brake-limit", type=float, default=6.0)
parser.add_argument("--lookahead-guidance-weight", type=float, default=0.1)
parser.add_argument(
    "--lookahead-guidance-weight-post-two", type=float, default=0.1
)
parser.add_argument("--lookahead-exit-speed", type=float)
parser.add_argument("--lookahead-exit-speed-post-two", type=float)
parser.add_argument("--terminal-speed-hard-range", type=float, default=40.0)
parser.add_argument("--terminal-speed-hard-gain", type=float, default=0.0)
parser.add_argument("--dynamic-corridor-weight", type=float, default=0.0)
parser.add_argument("--dynamic-corridor-radius", type=float, default=15.0)
parser.add_argument("--dynamic-corridor-horizon", type=float, default=5.0)
parser.add_argument("--dynamic-corridor-min-popped", type=int, default=0)
parser.add_argument("--dynamic-corridor-one-shot", action="store_true")
parser.add_argument("--dynamic-corridor-use-powered-tgo", action="store_true")
parser.add_argument("--dynamic-corridor-min-lock-duration", type=float, default=0.0)
parser.add_argument("--dynamic-corridor-max-popped", type=int)
parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
args = parser.parse_args()
args.output_dir.mkdir(parents=True, exist_ok=True)

scenario_parameters, given_parameters = load_scenario_parameters(1)
scenario_parameters["scenario"]["random_seed"] = args.seed
env = BalloonPoppingEnv(render_mode=None, parameters=scenario_parameters)
agent_kwargs = dict(
    launch_inclination_offset_deg=args.launch_inclination_offset_deg,
    launch_heading_offset_deg=args.launch_heading_offset_deg,
    launch_min_climb_accel=args.launch_min_climb_accel,
    selector_time_budget_fraction=args.selector_time_budget_fraction,
    selector_altitude_weight=args.selector_altitude_weight,
    selector_altitude_weight_post_hit=args.selector_altitude_weight_post_hit,
    selector_earliest_launch_time=args.selector_earliest_launch_time,
    selector_launch_nearest_active=args.selector_launch_nearest_active,
    selector_min_launch_chain=args.selector_min_launch_chain,
    selector_fallback_launch_time=args.selector_fallback_launch_time,
    selector_fallback_min_launch_chain=args.selector_fallback_min_launch_chain,
    selector_post_hit_max_chain_length=(
        args.selector_post_hit_max_chain_length
    ),
    selector_post_hit_reward_decay=args.selector_post_hit_reward_decay,
    selector_horizontal_turn_weight=args.selector_horizontal_turn_weight,
    selector_climb_turn_weight=args.selector_climb_turn_weight,
    selector_descent_turn_weight=args.selector_descent_turn_weight,
    selector_use_directional_turn_cost=args.selector_use_directional_turn_cost,
    selector_use_exit_state_surrogate=args.selector_use_exit_state_surrogate,
    selector_use_attitude_state_surrogate=(
        args.selector_use_attitude_state_surrogate
    ),
    selector_use_brake_turn_surrogate=args.selector_use_brake_turn_surrogate,
    selector_brake_turn_accel_fraction=(
        args.selector_brake_turn_accel_fraction
    ),
    selector_brake_turn_decel=args.selector_brake_turn_decel,
    selector_brake_turn_min_speed=args.selector_brake_turn_min_speed,
    selector_use_closed_loop_rollout=args.selector_use_closed_loop_rollout,
    selector_closed_loop_rollout_horizon=(
        args.selector_closed_loop_rollout_horizon
    ),
    selector_closed_loop_rollout_adaptive_horizon=(
        args.selector_closed_loop_rollout_adaptive_horizon
    ),
    selector_postburn_capture_time=args.selector_postburn_capture_time,
    selector_use_ballistic_terminal_capture=(
        args.selector_use_ballistic_terminal_capture
    ),
    use_ballistic_successor_lookahead=args.use_ballistic_successor_lookahead,
    ballistic_successor_weight=args.ballistic_successor_weight,
    ballistic_successor_radius=args.ballistic_successor_radius,
    ballistic_successor_rank=args.ballistic_successor_rank,
    terminal_coast_lateral_bias=args.terminal_coast_lateral_bias,
    terminal_coast_normal_bias=args.terminal_coast_normal_bias,
    use_terminal_attitude_hold=args.use_terminal_attitude_hold,
    terminal_hold_lateral_bias=args.terminal_hold_lateral_bias,
    terminal_hold_normal_bias=args.terminal_hold_normal_bias,
    terminal_hold_throttle=args.terminal_hold_throttle,
    terminal_hold_bias_duration=args.terminal_hold_bias_duration,
    terminal_hold_bias_delay=args.terminal_hold_bias_delay,
    terminal_hold_release_after_bias=args.terminal_hold_release_after_bias,
    terminal_hold_recovery_lateral_bias=(
        args.terminal_hold_recovery_lateral_bias
    ),
    terminal_hold_recovery_normal_bias=args.terminal_hold_recovery_normal_bias,
    terminal_hold_recovery_duration=args.terminal_hold_recovery_duration,
    terminal_hold_adaptive_projection=args.terminal_hold_adaptive_projection,
    terminal_hold_projection_gain=args.terminal_hold_projection_gain,
    terminal_hold_velocity_fit=args.terminal_hold_velocity_fit,
    terminal_hold_velocity_fit_gain=args.terminal_hold_velocity_fit_gain,
    use_terminal_capture_guidance=args.use_terminal_capture_guidance,
    terminal_capture_radius=args.terminal_capture_radius,
    terminal_capture_lookahead_weight=args.terminal_capture_lookahead_weight,
    terminal_capture_min_popped=args.terminal_capture_min_popped,
    terminal_capture_successor_rank=args.terminal_capture_successor_rank,
    terminal_capture_throttle_scale=args.terminal_capture_throttle_scale,
    terminal_capture_throttle_min_popped=args.terminal_capture_throttle_min_popped,
    terminal_capture_lateral_bias=args.terminal_capture_lateral_bias,
    terminal_capture_normal_bias=args.terminal_capture_normal_bias,
    terminal_capture_bias_delay=args.terminal_capture_bias_delay,
    terminal_capture_bias_duration=args.terminal_capture_bias_duration,
    unlimit_final_target=args.unlimit_final_target,
    unlimit_final_min_popped=args.unlimit_final_min_popped,
    selector_prefer_longest_chain=args.selector_prefer_longest_chain,
    selector_use_flyby_route_bonus=args.selector_use_flyby_route_bonus,
    selector_flyby_radius_scale=args.selector_flyby_radius_scale,
    terminal_speed_target=args.terminal_speed_target,
    use_corner_speed_governor=args.use_corner_speed_governor,
    corner_speed_min=args.corner_speed_min,
    corner_speed_max=args.corner_speed_max,
    corner_speed_accel_fraction=args.corner_speed_accel_fraction,
    corner_speed_min_popped=args.corner_speed_min_popped,
    terminal_speed_brake_gain=args.terminal_speed_brake_gain,
    terminal_speed_post_two_brake_gain=(
        args.terminal_speed_post_two_brake_gain
    ),
    terminal_speed_brake_limit=args.terminal_speed_brake_limit,
    terminal_speed_hard_range=args.terminal_speed_hard_range,
    terminal_speed_hard_gain=args.terminal_speed_hard_gain,
    lookahead_exit_speed_post_two=args.lookahead_exit_speed_post_two,
    lookahead_guidance_weight=args.lookahead_guidance_weight,
    lookahead_guidance_weight_post_two=(
        args.lookahead_guidance_weight_post_two
    ),
    dynamic_corridor_weight=args.dynamic_corridor_weight,
    dynamic_corridor_radius=args.dynamic_corridor_radius,
    dynamic_corridor_horizon=args.dynamic_corridor_horizon,
    dynamic_corridor_min_popped=args.dynamic_corridor_min_popped,
    dynamic_corridor_one_shot=args.dynamic_corridor_one_shot,
    dynamic_corridor_use_powered_tgo=args.dynamic_corridor_use_powered_tgo,
    dynamic_corridor_min_lock_duration=(
        args.dynamic_corridor_min_lock_duration
    ),
    dynamic_corridor_max_popped=args.dynamic_corridor_max_popped,
)
if args.verify_ten_profile:
    from BalloonPoppingGymEnv.agents.guided_pid_agent_ten_balloon import GuidedPidAgent as TenBalloonAgent
    agent = TenBalloonAgent(given_parameters, **args.nine_overrides)
elif args.coast_profile:
    from BalloonPoppingGymEnv.agents.guided_pid_agent_coast_experimental import GuidedPidAgent as CoastAgent
    agent = CoastAgent(given_parameters, **args.nine_overrides)
elif args.reachability_profile:
    from BalloonPoppingGymEnv.agents.guided_pid_agent_reachability_experimental import GuidedPidAgent as ReachableAgent
    agent = ReachableAgent(given_parameters, **args.nine_overrides)
elif args.late_chain_profile:
    from BalloonPoppingGymEnv.agents.guided_pid_agent_late_chain_experimental import GuidedPidAgent as LateChainAgent
    agent = LateChainAgent(given_parameters, **args.nine_overrides)
elif args.verify_nine_profile:
    from BalloonPoppingGymEnv.agents.guided_pid_agent_nine_balloon import (
        GuidedPidAgent as NineBalloonAgent,
    )
    agent = NineBalloonAgent(given_parameters, **args.nine_overrides)
elif args.verify_eight_profile:
    from BalloonPoppingGymEnv.agents.guided_pid_agent_eight_balloon import (
        GuidedPidAgent as EightBalloonAgent,
    )
    agent = EightBalloonAgent(given_parameters)
elif args.verify_seven_profile:
    from BalloonPoppingGymEnv.agents.guided_pid_agent_seven_balloon import (
        GuidedPidAgent as SevenBalloonAgent,
    )
    agent = SevenBalloonAgent(given_parameters)
else:
    agent = GuidedPidAgent(given_parameters, **agent_kwargs)
backend = agent.scheduled_backend
if args.lookahead_exit_speed is not None:
    backend.navigator.lookahead_exit_speed = args.lookahead_exit_speed
observation, info = env.reset(seed=scenario_parameters["scenario"]["random_seed"])
previous_count = int(info["popped_count"])
previous_status = np.asarray(observation["balloon_status"], dtype=int).copy()
events = []
closest = {}
all_active_closest = {}
all_active_closest_time = {}
all_active_closest_vector = {}
post_three_closest = {}
post_three_closest_time = {}
dynamic_corridor_trace = []
previous_dynamic_corridor = None
speed_min = np.inf
speed_max = 0.0
altitude_min = np.inf
altitude_max = -np.inf
terminated = truncated = False

while not (terminated or truncated):
    target_index = None
    if backend.current_target_idx < len(backend.target_idx_list):
        target_index = int(
            backend.target_idx_list[backend.current_target_idx]
        )

    action = agent.get_action(observation)
    current_dynamic_corridor = backend._last_dynamic_corridor
    if current_dynamic_corridor != previous_dynamic_corridor:
        dynamic_corridor_trace.append(
            {
                "time": float(observation["simulation_time"]),
                "target": current_dynamic_corridor,
            }
        )
        previous_dynamic_corridor = current_dynamic_corridor
    observation, _, terminated, truncated, info = env.step(action)

    sensors = np.asarray(observation["rocket_sensors"], dtype=float)
    position = sensors[6:9]
    velocity = sensors[9:12]
    speed = float(np.linalg.norm(velocity))
    speed_min = min(speed_min, speed)
    speed_max = max(speed_max, speed)
    altitude_min = min(altitude_min, float(position[2]))
    altitude_max = max(altitude_max, float(position[2]))

    observed_states = np.asarray(observation["balloon_states"], dtype=float)
    observed_status = np.asarray(observation["balloon_status"], dtype=int)
    for candidate in np.flatnonzero(observed_status == 1):
        candidate_distance = float(
            np.linalg.norm(observed_states[candidate, :3] - position)
        )
        key = str(int(candidate))
        if candidate_distance < all_active_closest.get(key, np.inf):
            all_active_closest[key] = candidate_distance
            all_active_closest_time[key] = float(observation["simulation_time"])
            all_active_closest_vector[key] = (
                observed_states[candidate, :3] - position
            ).tolist()
        if int(info["popped_count"]) >= 3 and candidate_distance < post_three_closest.get(
            key, np.inf
        ):
            post_three_closest[key] = candidate_distance
            post_three_closest_time[key] = float(observation["simulation_time"])

    if target_index is not None:
        target_position = np.asarray(
            observation["balloon_states"][target_index][0:3], dtype=float
        )
        distance = float(np.linalg.norm(target_position - position))
        key = str(target_index)
        closest[key] = min(closest.get(key, np.inf), distance)

    current_count = int(info["popped_count"])
    if current_count > previous_count:
        current_status = np.asarray(observation["balloon_status"], dtype=int)
        newly_popped = np.flatnonzero(
            (previous_status != 2) & (current_status == 2)
        ).astype(int).tolist()
        balloon_states = np.asarray(observation["balloon_states"], dtype=float)
        ballistic_candidates = []
        for candidate in np.flatnonzero(current_status == 1):
            times = np.linspace(0.05, 6.0, 120)
            rocket_path = (
                position[None, :]
                + times[:, None] * velocity[None, :]
                + 0.5 * times[:, None] ** 2 * np.array([0.0, 0.0, -9.81])
            )
            target_path = (
                balloon_states[candidate, :3][None, :]
                + times[:, None] * balloon_states[candidate, 3:6][None, :]
            )
            distances = np.linalg.norm(target_path - rocket_path, axis=1)
            closest_index = int(np.argmin(distances))
            miss_vector = target_path[closest_index] - rocket_path[closest_index]
            ballistic_candidates.append(
                {
                    "target": int(candidate),
                    "distance": float(distances[closest_index]),
                    "time": float(times[closest_index]),
                    "speed": float(
                        np.linalg.norm(
                            velocity
                            + np.array([0.0, 0.0, -9.81])
                            * times[closest_index]
                        )
                    ),
                    "miss_vector": miss_vector.tolist(),
                }
            )
        ballistic_candidates.sort(key=lambda candidate: candidate["distance"])
        target_velocity = (
            np.asarray(
                observation["balloon_states"][target_index][3:6], dtype=float
            )
            if target_index is not None
            else np.full(3, np.nan)
        )
        events.append(
            {
                "time": float(observation["simulation_time"]),
                "count": current_count,
                "target_index": target_index,
                "popped_indices": newly_popped,
                "ballistic_candidates": ballistic_candidates[:10],
                "speed": speed,
                "rocket_position": position.tolist(),
                "rocket_velocity": velocity.tolist(),
                "target_position": (
                    np.asarray(
                        observation["balloon_states"][target_index][0:3],
                        dtype=float,
                    ).tolist()
                    if target_index is not None
                    else np.full(3, np.nan).tolist()
                ),
                "target_velocity": target_velocity.tolist(),
                "target_altitude": (
                    float(observation["balloon_states"][target_index][2])
                    if target_index is not None
                    else float("nan")
                ),
                "relative_speed": float(
                    np.linalg.norm(velocity - target_velocity)
                ),
                "throttle": float(action["throttle"]),
                "tvc": np.asarray(action["tvc"], dtype=float).tolist(),
            }
        )
        previous_count = current_count
        previous_status = current_status.copy()

result = {
    "acquire_history": getattr(backend, "acquire_history", []),
    "experimental_config": getattr(agent, "experimental_config", None),
    "benchmark_arguments": {
        key: str(value) if isinstance(value, Path) else value
        for key, value in vars(args).items()
    },
    "seed": args.seed,
    "popped_balloons": int(info["popped_count"]),
    "events": events,
    "closest_distance_by_target": closest,
    "closest_distance_by_active_balloon": all_active_closest,
    "closest_time_by_active_balloon": all_active_closest_time,
    "closest_vector_by_active_balloon": all_active_closest_vector,
    "post_three_closest_distance": post_three_closest,
    "post_three_closest_time": post_three_closest_time,
    "speed_min": float(speed_min),
    "speed_max": float(speed_max),
    "altitude_min": float(altitude_min),
    "altitude_max": float(altitude_max),
    "selector_altitude_weight": backend.selector.altitude_weight,
    "selector_altitude_weight_post_hit": (
        backend.selector_altitude_weight_post_hit
    ),
    "selector_horizontal_turn_weight": backend.selector.horizontal_turn_weight,
    "selector_climb_turn_weight": backend.selector.climb_turn_weight,
    "selector_descent_turn_weight": backend.selector.descent_turn_weight,
    "selector_use_directional_turn_cost": (
        backend.selector.use_directional_turn_cost
    ),
    "selector_use_exit_state_surrogate": (
        backend.selector.use_exit_state_surrogate
    ),
    "selector_use_attitude_state_surrogate": (
        backend.selector.use_attitude_state_surrogate
    ),
    "selector_use_brake_turn_surrogate": (
        backend.selector.use_brake_turn_surrogate
    ),
    "selector_brake_turn_accel_fraction": (
        backend.selector.brake_turn_accel_fraction
    ),
    "selector_brake_turn_decel": backend.selector.brake_turn_decel,
    "selector_brake_turn_min_speed": backend.selector.brake_turn_min_speed,
    "selector_experimental_ranking_history": (
        backend.selector.experimental_ranking_history
    ),
    "selector_use_closed_loop_rollout": (
        backend.use_closed_loop_rollout_selection
    ),
    "selector_postburn_capture_time": backend.postburn_capture_time,
    "selector_use_ballistic_terminal_capture": (
        backend.use_ballistic_terminal_capture
    ),
    "selector_prefer_longest_chain": backend.selector.prefer_longest_chain,
    "launch_time": backend.launch_time,
    "effective_selector_time_budget_fraction": backend.selector.time_budget_fraction,
    "launch_inclination_heading": (
        None if backend.launch_inclination_heading is None
        else np.asarray(backend.launch_inclination_heading).tolist()
    ),
    "selector_launch_nearest_active": backend.selector.launch_nearest_active,
    "selector_post_hit_max_chain_length": (
        backend.selector_post_hit_max_chain_length
    ),
    "selector_post_hit_reward_decay": backend.selector_post_hit_reward_decay,
    "terminal_speed_target": backend.terminal_speed_target,
    "use_corner_speed_governor": backend.use_corner_speed_governor,
    "corner_speed_trace": backend.corner_speed_trace,
    "terminal_speed_hard_limit": backend.terminal_speed_hard_limit,
    "fixed_target_list": backend.fixed_target_list,
    "corridor_targets": backend.corridor_targets,
    "lookahead_guidance_weight": backend.lookahead_guidance_weight,
    "final_target_list": backend.target_idx_list,
    "current_target_position": backend.current_target_idx,
    "leg_diagnostics": backend.leg_diagnostics,
    "rollout_decisions": backend.rollout_decisions,
    "ballistic_capture_decisions": backend.ballistic_capture_decisions,
    "dynamic_corridor_decisions": backend.dynamic_corridor_decisions,
    "dynamic_corridor_trace": dynamic_corridor_trace,
    "dynamic_corridor_one_shot": backend.dynamic_corridor_one_shot,
    "dynamic_corridor_min_lock_duration": (
        backend.dynamic_corridor_min_lock_duration
    ),
    "ballistic_successor_decisions": backend.ballistic_successor_decisions,
    "flyby_plan_history": backend.flyby_plan_history,
    "terminal_coast_lateral_bias": backend.terminal_coast_lateral_bias,
    "terminal_coast_normal_bias": backend.terminal_coast_normal_bias,
    "terminal_hold_decisions": backend.terminal_hold_decisions,
    "terminal_capture_decisions": backend.terminal_capture_decisions,
    "terminal_capture_min_popped": backend.terminal_capture_min_popped,
    "unlimit_final_target": backend.unlimit_final_target,
}

output_path = args.output_dir / "result.json"
output_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
csv_path = args.output_dir / "events.csv"
with csv_path.open("w", newline="", encoding="utf-8") as stream:
    writer = csv.DictWriter(
        stream,
        fieldnames=(
            "time",
            "count",
            "target_index",
            "popped_indices",
            "ballistic_candidates",
            "speed",
            "rocket_position",
            "rocket_velocity",
            "target_position",
            "target_velocity",
            "target_altitude",
            "relative_speed",
            "throttle",
            "tvc",
        ),
    )
    writer.writeheader()
    writer.writerows(events)
print(f"Popped balloons: {result['popped_balloons']}")
print(json.dumps(result, indent=2))
print(f"RESULT_JSON={output_path}")
print(f"EVENT_CSV={csv_path}")
