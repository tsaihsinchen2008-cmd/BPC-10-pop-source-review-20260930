import unittest
from types import SimpleNamespace
from unittest.mock import patch
from BalloonPoppingGymEnv.agents.guided_pid_agent_coast_experimental import GuidedPidAgent, Nine

class SplitTests(unittest.TestCase):
    def test_observed_count_timing_and_restart(self):
        agent=object.__new__(GuidedPidAgent)
        agent._coast_second_throttle=.7
        agent._coast_first_throttle=.5
        agent._coast_switch_time=1.
        agent._coast_start=None
        agent._coast_previous_time=None
        agent.scheduled_backend=SimpleNamespace(terminal_capture_throttle_scale=.5)
        with patch.object(Nine,'get_action',return_value={'sentinel':True}) as parent:
            for time,count,expected in ((40,7,.5),(43,8,.5),(43.99,8,.5),(44,8,.7),(0,0,.5)):
                result=agent.get_action({'simulation_time':time,'balloon_status':[2]*count+[1]})
                self.assertEqual(agent.scheduled_backend.terminal_capture_throttle_scale,expected)
                self.assertTrue(result['sentinel'])
            self.assertEqual(parent.call_count,5)

if __name__=='__main__': unittest.main()
